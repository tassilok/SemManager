execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'') = 0
	insert into semtbl_Attribute VALUES(''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'',''db_postfix'',''065e644e-c7df-4007-8672-aa5414131c78'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''0d2c794d-281d-44ff-9767-eb8549d4ad16'') = 0
	insert into semtbl_Attribute VALUES(''0d2c794d-281d-44ff-9767-eb8549d4ad16'',''Message'',''64530b52-d96c-4df1-86fe-183f44513450'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''4e173916-e8d7-4640-8ef1-965b74371124'') = 0
	insert into semtbl_Attribute VALUES(''4e173916-e8d7-4640-8ef1-965b74371124'',''Codepage'',''3a4f5b7b-da75-4980-933e-fbc33cc51439'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''581597d8-dde6-4779-9ef0-37d29d0a67a2'') = 0
	insert into semtbl_Attribute VALUES(''581597d8-dde6-4779-9ef0-37d29d0a67a2'',''LCID'',''3a4f5b7b-da75-4980-933e-fbc33cc51439'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''04048642-e81e-4026-841a-fb377a02dbc5'') = 0
	insert into semtbl_Attribute VALUES(''04048642-e81e-4026-841a-fb377a02dbc5'',''Short'',''065e644e-c7df-4007-8672-aa5414131c78'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''65df1500-ffa8-4980-9c31-a5caae4a9104'')=0
	insert into semtbl_RelationType VALUES(''65df1500-ffa8-4980-9c31-a5caae4a9104'',''describes'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''cd32af17-bab3-49da-857b-60c5ac809e4e'')=0
	insert into semtbl_RelationType VALUES(''cd32af17-bab3-49da-857b-60c5ac809e4e'',''is defined by'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''d91da85b-793c-431c-9724-8ddc1ace170e'')=0
	insert into semtbl_RelationType VALUES(''d91da85b-793c-431c-9724-8ddc1ace170e'',''Standard'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	insert into semtbl_RelationType VALUES(''e9711603-47db-44d8-a476-fe88290639a4'',''contains'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''413e9c02-9380-4f17-8806-5bd9881b8f89'')=0
	insert into semtbl_RelationType VALUES(''413e9c02-9380-4f17-8806-5bd9881b8f89'',''alternative for'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''1700a8b9-5f32-44ec-8687-1c5ddb84e109'')=0
	insert into semtbl_RelationType VALUES(''1700a8b9-5f32-44ec-8687-1c5ddb84e109'',''is described by'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''5c893080-9e8c-4fe2-97aa-87878d38ac4a'')=0
	insert into semtbl_RelationType VALUES(''5c893080-9e8c-4fe2-97aa-87878d38ac4a'',''offered by'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''7dfcb2ed-c91f-4dbe-b455-9ee834002325'')=0
	insert into semtbl_RelationType VALUES(''7dfcb2ed-c91f-4dbe-b455-9ee834002325'',''is written in'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	insert into semtbl_RelationType VALUES(''e07469d9-766c-443e-8526-6d9c684f944f'',''belongs to'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''dd5a24ec-e2bd-47c2-9761-d4a7db114aed'')=0
	insert into semtbl_RelationType VALUES(''dd5a24ec-e2bd-47c2-9761-d4a7db114aed'',''additional'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''b18b99bf-08fa-48cf-ba51-765c0bf5a7b7'')=0
	insert into semtbl_RelationType VALUES(''b18b99bf-08fa-48cf-ba51-765c0bf5a7b7'',''offers'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''4c432601-f11e-4554-884b-1f1606ae2c9c'')=0
	insert into semtbl_RelationType VALUES(''4c432601-f11e-4554-884b-1f1606ae2c9c'',''Input-Message'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''90d860c7-784c-477c-957a-c6c5a0a71b22'')=0
	insert into semtbl_RelationType VALUES(''90d860c7-784c-477c-957a-c6c5a0a71b22'',''User-Message'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''7b476bc9-88db-423d-bb90-e72d38963f1c'')=0
	insert into semtbl_RelationType VALUES(''7b476bc9-88db-423d-bb90-e72d38963f1c'',''Error-Message'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''fafc1464-815f-4596-9737-bcbc96bd744a'')=0
	insert into semtbl_RelationType VALUES(''fafc1464-815f-4596-9737-bcbc96bd744a'',''needs'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''408db9f1-ae42-4807-b656-729270646f0a'')=0
	insert into semtbl_RelationType VALUES(''408db9f1-ae42-4807-b656-729270646f0a'',''is subordinated'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type=''49fdcd27-e105-4770-941d-7485dcad08c1'') = 0
	insert into semtbl_Type (GUID_Type,Name_Type) VALUES(''49fdcd27-e105-4770-941d-7485dcad08c1'',''Root'')'
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='73e32abf-e577-4d31-9a46-bc07e9e15de3') = 0
	insert into semtbl_Type VALUES('73e32abf-e577-4d31-9a46-bc07e9e15de3','Software-Management','49fdcd27-e105-4770-941d-7485dcad08c1')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='71415eeb-ce46-4b2c-b0a2-f72116b55438') = 0
	insert into semtbl_Type VALUES('71415eeb-ce46-4b2c-b0a2-f72116b55438','Software-Development','73e32abf-e577-4d31-9a46-bc07e9e15de3')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='c6c9bcb8-0ac9-4713-9417-eeec1453026c') = 0
	insert into semtbl_Type VALUES('c6c9bcb8-0ac9-4713-9417-eeec1453026c','Development-Config','71415eeb-ce46-4b2c-b0a2-f72116b55438')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='13c09f11-175c-4eef-bc8a-0fd8e86d557f') = 0
	insert into semtbl_Type VALUES('13c09f11-175c-4eef-bc8a-0fd8e86d557f','Development-ConfigItem','c6c9bcb8-0ac9-4713-9417-eeec1453026c')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='160b2c7d-1f3c-4608-b8b4-08ace24bc629') = 0
	insert into semtbl_Type VALUES('160b2c7d-1f3c-4608-b8b4-08ace24bc629','GUI-Items','71415eeb-ce46-4b2c-b0a2-f72116b55438')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='3181a694-0ce1-44cc-a16c-6c19d2b6b5d9') = 0
	insert into semtbl_Type VALUES('3181a694-0ce1-44cc-a16c-6c19d2b6b5d9','GUI-Entires','160b2c7d-1f3c-4608-b8b4-08ace24bc629')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='7a81bf47-2519-4db7-ae54-d1eb416c46af') = 0
	insert into semtbl_Type VALUES('7a81bf47-2519-4db7-ae54-d1eb416c46af','GUI-Caption','160b2c7d-1f3c-4608-b8b4-08ace24bc629')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='98005f0d-3bd1-4a6e-af92-2f704071ea29') = 0
	insert into semtbl_Type VALUES('98005f0d-3bd1-4a6e-af92-2f704071ea29','Messages','71415eeb-ce46-4b2c-b0a2-f72116b55438')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='61579228-8a42-4c60-adb5-41a47c8dacbb') = 0
	insert into semtbl_Type VALUES('61579228-8a42-4c60-adb5-41a47c8dacbb','ToolTip-Messages','98005f0d-3bd1-4a6e-af92-2f704071ea29')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='665dd88b-792e-4256-a27a-68ee1e10ece6') = 0
	insert into semtbl_Type VALUES('665dd88b-792e-4256-a27a-68ee1e10ece6','System','49fdcd27-e105-4770-941d-7485dcad08c1')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='b5224e7f-7d0d-4bee-bf8e-b9a0eeba5747') = 0
	insert into semtbl_Type VALUES('b5224e7f-7d0d-4bee-bf8e-b9a0eeba5747','Module-Management','665dd88b-792e-4256-a27a-68ee1e10ece6')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='aa616051-e521-4fac-abdb-cbba6f8c6e73') = 0
	insert into semtbl_Type VALUES('aa616051-e521-4fac-abdb-cbba6f8c6e73','Module','b5224e7f-7d0d-4bee-bf8e-b9a0eeba5747')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='5a95c5ab-a5ef-47d5-a878-e8a7efcf79a9') = 0
	insert into semtbl_Type VALUES('5a95c5ab-a5ef-47d5-a878-e8a7efcf79a9','Localizing-Module','aa616051-e521-4fac-abdb-cbba6f8c6e73')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='7d0178e2-9c04-4485-b81c-6d79253c6f64') = 0
	insert into semtbl_Type VALUES('7d0178e2-9c04-4485-b81c-6d79253c6f64','Localization-Management','49fdcd27-e105-4770-941d-7485dcad08c1')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='ac0c99a0-d73d-4dc7-a789-3528a76822de') = 0
	insert into semtbl_Type VALUES('ac0c99a0-d73d-4dc7-a789-3528a76822de','Localized Names','7d0178e2-9c04-4485-b81c-6d79253c6f64')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='e79ff4de-2e39-4101-b5a1-0055c40f41cd') = 0
	insert into semtbl_Type VALUES('e79ff4de-2e39-4101-b5a1-0055c40f41cd','Language','7d0178e2-9c04-4485-b81c-6d79253c6f64')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='3d62cd71-88e2-4e3d-8a5d-9601da17da1d') = 0
	insert into semtbl_Type VALUES('3d62cd71-88e2-4e3d-8a5d-9601da17da1d','Localized Description','7d0178e2-9c04-4485-b81c-6d79253c6f64')
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'') = 0
	insert into semtbl_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''Localizing-Manager'',''c6c9bcb8-0ac9-4713-9417-eeec1453026c'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''76bee339-e97c-4d61-9f1b-337d47af96ac'') = 0
	insert into semtbl_Token VALUES(''76bee339-e97c-4d61-9f1b-337d47af96ac'',''Localizing-Manager'',''71415eeb-ce46-4b2c-b0a2-f72116b55438'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''6a1f040b-3477-47c6-8718-0050bddebddd'') = 0
	insert into semtbl_Token VALUES(''6a1f040b-3477-47c6-8718-0050bddebddd'',''Type_GUI_Entires'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''34393d78-0f7c-40a0-a194-088fcc517b14'') = 0
	insert into semtbl_Token VALUES(''34393d78-0f7c-40a0-a194-088fcc517b14'',''Type_Localizing_Module'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''1d7fefa9-2304-450d-9a4a-0a3c4be58ccc'') = 0
	insert into semtbl_Token VALUES(''1d7fefa9-2304-450d-9a4a-0a3c4be58ccc'',''type_SoftwareDevelopment'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''99ca8ff9-2940-493a-a276-0bcbd8a9f227'') = 0
	insert into semtbl_Token VALUES(''99ca8ff9-2940-493a-a276-0bcbd8a9f227'',''Type_Module'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''5f151ab3-63fd-41d1-b582-1a5c59966ac9'') = 0
	insert into semtbl_Token VALUES(''5f151ab3-63fd-41d1-b582-1a5c59966ac9'',''RelationType_describes'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''bb22c77c-d2d3-4dc1-990d-27bafdbb35a4'') = 0
	insert into semtbl_Token VALUES(''bb22c77c-d2d3-4dc1-990d-27bafdbb35a4'',''Type_GUI_Caption'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''ecca8471-4f62-44a8-934f-2d107685c4ec'') = 0
	insert into semtbl_Token VALUES(''ecca8471-4f62-44a8-934f-2d107685c4ec'',''RelationType_is_defined_by'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''fb69b5e3-2b0a-47ad-8424-4692c2e83175'') = 0
	insert into semtbl_Token VALUES(''fb69b5e3-2b0a-47ad-8424-4692c2e83175'',''RelationType_Standard'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''f270a55b-1e57-4594-a6ff-62f42e60157a'') = 0
	insert into semtbl_Token VALUES(''f270a55b-1e57-4594-a6ff-62f42e60157a'',''Type_Localized_Names'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''6c966e3c-c737-4af1-9970-68c8323679bc'') = 0
	insert into semtbl_Token VALUES(''6c966e3c-c737-4af1-9970-68c8323679bc'',''RelationType_contains'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'') = 0
	insert into semtbl_Token VALUES(''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'',''attribute_dbPostfix'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''7cf624f0-86a2-46d7-ab81-6caa34c1175a'') = 0
	insert into semtbl_Token VALUES(''7cf624f0-86a2-46d7-ab81-6caa34c1175a'',''RelationType_alternative_for'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''15820ab1-0945-4e72-9792-6dd480e73954'') = 0
	insert into semtbl_Token VALUES(''15820ab1-0945-4e72-9792-6dd480e73954'',''RelationType_isDescribedBy'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''5a93b671-9910-47b7-9844-6fc59a2b8c95'') = 0
	insert into semtbl_Token VALUES(''5a93b671-9910-47b7-9844-6fc59a2b8c95'',''Attribute_Message'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''5d5b5653-830b-47b4-b9e1-741c58ec7d97'') = 0
	insert into semtbl_Token VALUES(''5d5b5653-830b-47b4-b9e1-741c58ec7d97'',''Type_ToolTip_Messages'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''f2cde058-614e-41cb-96eb-78bbcf285171'') = 0
	insert into semtbl_Token VALUES(''f2cde058-614e-41cb-96eb-78bbcf285171'',''RelationType_offered_by'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''983de3aa-2a11-4fd1-8ba6-8848929ede62'') = 0
	insert into semtbl_Token VALUES(''983de3aa-2a11-4fd1-8ba6-8848929ede62'',''RelationType_isWrittenIn'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''87eb4dc0-bdae-4c49-bf3c-a70ea7a6a4d6'') = 0
	insert into semtbl_Token VALUES(''87eb4dc0-bdae-4c49-bf3c-a70ea7a6a4d6'',''Type_Language'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''3186cc5e-023b-4edc-b6c7-a89919320839'') = 0
	insert into semtbl_Token VALUES(''3186cc5e-023b-4edc-b6c7-a89919320839'',''RelationType_belongsTo'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''5eb07eaf-d049-440a-a22a-c402d569f775'') = 0
	insert into semtbl_Token VALUES(''5eb07eaf-d049-440a-a22a-c402d569f775'',''Attribute_Codepage'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''e5268521-7038-464e-99f1-cebd83004cc2'') = 0
	insert into semtbl_Token VALUES(''e5268521-7038-464e-99f1-cebd83004cc2'',''RelationType_additional'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''36eb44c2-eb95-43a7-b187-d403c1a8983a'') = 0
	insert into semtbl_Token VALUES(''36eb44c2-eb95-43a7-b187-d403c1a8983a'',''type_LocalizedDescription'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''22faaa6d-8fbe-4b5a-8856-dec1fbcb5959'') = 0
	insert into semtbl_Token VALUES(''22faaa6d-8fbe-4b5a-8856-dec1fbcb5959'',''RelationType_offers'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''2e5e5bd9-f210-4920-98ae-1c3d550a3770'') = 0
	insert into semtbl_Token VALUES(''2e5e5bd9-f210-4920-98ae-1c3d550a3770'',''Localizing-Manager'',''aa616051-e521-4fac-abdb-cbba6f8c6e73'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''d9950407-b4b0-4fdb-899d-bb94095cb207'') = 0
	insert into semtbl_Token VALUES(''d9950407-b4b0-4fdb-899d-bb94095cb207'',''Base-Config'',''5a95c5ab-a5ef-47d5-a878-e8a7efcf79a9'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''6a1f040b-3477-47c6-8718-0050bddebddd'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''6a1f040b-3477-47c6-8718-0050bddebddd'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''34393d78-0f7c-40a0-a194-088fcc517b14'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''34393d78-0f7c-40a0-a194-088fcc517b14'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''1d7fefa9-2304-450d-9a4a-0a3c4be58ccc'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''1d7fefa9-2304-450d-9a4a-0a3c4be58ccc'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''99ca8ff9-2940-493a-a276-0bcbd8a9f227'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''99ca8ff9-2940-493a-a276-0bcbd8a9f227'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''5f151ab3-63fd-41d1-b582-1a5c59966ac9'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''5f151ab3-63fd-41d1-b582-1a5c59966ac9'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''bb22c77c-d2d3-4dc1-990d-27bafdbb35a4'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''bb22c77c-d2d3-4dc1-990d-27bafdbb35a4'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''ecca8471-4f62-44a8-934f-2d107685c4ec'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''ecca8471-4f62-44a8-934f-2d107685c4ec'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''fb69b5e3-2b0a-47ad-8424-4692c2e83175'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''fb69b5e3-2b0a-47ad-8424-4692c2e83175'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''f270a55b-1e57-4594-a6ff-62f42e60157a'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''f270a55b-1e57-4594-a6ff-62f42e60157a'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''6c966e3c-c737-4af1-9970-68c8323679bc'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''6c966e3c-c737-4af1-9970-68c8323679bc'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''7cf624f0-86a2-46d7-ab81-6caa34c1175a'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''7cf624f0-86a2-46d7-ab81-6caa34c1175a'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''15820ab1-0945-4e72-9792-6dd480e73954'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''15820ab1-0945-4e72-9792-6dd480e73954'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''5a93b671-9910-47b7-9844-6fc59a2b8c95'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''5a93b671-9910-47b7-9844-6fc59a2b8c95'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''5d5b5653-830b-47b4-b9e1-741c58ec7d97'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''5d5b5653-830b-47b4-b9e1-741c58ec7d97'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''f2cde058-614e-41cb-96eb-78bbcf285171'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''f2cde058-614e-41cb-96eb-78bbcf285171'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''983de3aa-2a11-4fd1-8ba6-8848929ede62'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''983de3aa-2a11-4fd1-8ba6-8848929ede62'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''87eb4dc0-bdae-4c49-bf3c-a70ea7a6a4d6'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''87eb4dc0-bdae-4c49-bf3c-a70ea7a6a4d6'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''3186cc5e-023b-4edc-b6c7-a89919320839'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''3186cc5e-023b-4edc-b6c7-a89919320839'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''5eb07eaf-d049-440a-a22a-c402d569f775'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''5eb07eaf-d049-440a-a22a-c402d569f775'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''e5268521-7038-464e-99f1-cebd83004cc2'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''e5268521-7038-464e-99f1-cebd83004cc2'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''36eb44c2-eb95-43a7-b187-d403c1a8983a'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''36eb44c2-eb95-43a7-b187-d403c1a8983a'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_Token_Right=''22faaa6d-8fbe-4b5a-8856-dec1fbcb5959'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''22faaa6d-8fbe-4b5a-8856-dec1fbcb5959'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''76bee339-e97c-4d61-9f1b-337d47af96ac'' AND GUID_Token_Right=''5883cd14-8be8-4e4d-9e0b-59dd8945196a'' AND GUID_RelationType=''fafc1464-815f-4596-9737-bcbc96bd744a'')=0
	INSERT INTO semtbl_Token_Token VALUES(''76bee339-e97c-4d61-9f1b-337d47af96ac'',''5883cd14-8be8-4e4d-9e0b-59dd8945196a'',''fafc1464-815f-4596-9737-bcbc96bd744a'',1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''2e5e5bd9-f210-4920-98ae-1c3d550a3770'' AND GUID_Token_Right=''76bee339-e97c-4d61-9f1b-337d47af96ac'' AND GUID_RelationType=''5c893080-9e8c-4fe2-97aa-87878d38ac4a'')=0
	INSERT INTO semtbl_Token_Token VALUES(''2e5e5bd9-f210-4920-98ae-1c3d550a3770'',''76bee339-e97c-4d61-9f1b-337d47af96ac'',''5c893080-9e8c-4fe2-97aa-87878d38ac4a'',1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''d9950407-b4b0-4fdb-899d-bb94095cb207'' AND GUID_Token_Right=''2e5e5bd9-f210-4920-98ae-1c3d550a3770'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_Token VALUES(''d9950407-b4b0-4fdb-899d-bb94095cb207'',''2e5e5bd9-f210-4920-98ae-1c3d550a3770'',''e07469d9-766c-443e-8526-6d9c684f944f'',1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Attribute=''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'',0,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_Attribute=''581597d8-dde6-4779-9ef0-37d29d0a67a2'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''581597d8-dde6-4779-9ef0-37d29d0a67a2'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_Attribute=''4e173916-e8d7-4640-8ef1-965b74371124'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''4e173916-e8d7-4640-8ef1-965b74371124'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_Attribute=''04048642-e81e-4026-841a-fb377a02dbc5'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''04048642-e81e-4026-841a-fb377a02dbc5'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''3d62cd71-88e2-4e3d-8a5d-9601da17da1d'' AND GUID_Attribute=''0d2c794d-281d-44ff-9767-eb8549d4ad16'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''3d62cd71-88e2-4e3d-8a5d-9601da17da1d'',''0d2c794d-281d-44ff-9767-eb8549d4ad16'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''ac0c99a0-d73d-4dc7-a789-3528a76822de'' AND GUID_Type_Right=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_RelationType=''7dfcb2ed-c91f-4dbe-b455-9ee834002325'')=0
	INSERT INTO semtbl_Type_Type VALUES(''ac0c99a0-d73d-4dc7-a789-3528a76822de'',''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''7dfcb2ed-c91f-4dbe-b455-9ee834002325'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''61579228-8a42-4c60-adb5-41a47c8dacbb'' AND GUID_Type_Right=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_RelationType=''7dfcb2ed-c91f-4dbe-b455-9ee834002325'')=0
	INSERT INTO semtbl_Type_Type VALUES(''61579228-8a42-4c60-adb5-41a47c8dacbb'',''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''7dfcb2ed-c91f-4dbe-b455-9ee834002325'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3181a694-0ce1-44cc-a16c-6c19d2b6b5d9'' AND GUID_Type_Right=''61579228-8a42-4c60-adb5-41a47c8dacbb'' AND GUID_RelationType=''cd32af17-bab3-49da-857b-60c5ac809e4e'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3181a694-0ce1-44cc-a16c-6c19d2b6b5d9'',''61579228-8a42-4c60-adb5-41a47c8dacbb'',''cd32af17-bab3-49da-857b-60c5ac809e4e'',1,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3181a694-0ce1-44cc-a16c-6c19d2b6b5d9'' AND GUID_Type_Right=''7a81bf47-2519-4db7-ae54-d1eb416c46af'' AND GUID_RelationType=''cd32af17-bab3-49da-857b-60c5ac809e4e'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3181a694-0ce1-44cc-a16c-6c19d2b6b5d9'',''7a81bf47-2519-4db7-ae54-d1eb416c46af'',''cd32af17-bab3-49da-857b-60c5ac809e4e'',1,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3d62cd71-88e2-4e3d-8a5d-9601da17da1d'' AND GUID_Type_Right=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_RelationType=''7dfcb2ed-c91f-4dbe-b455-9ee834002325'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3d62cd71-88e2-4e3d-8a5d-9601da17da1d'',''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''7dfcb2ed-c91f-4dbe-b455-9ee834002325'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''aa616051-e521-4fac-abdb-cbba6f8c6e73'' AND GUID_Type_Right=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_RelationType=''5c893080-9e8c-4fe2-97aa-87878d38ac4a'')=0
	INSERT INTO semtbl_Type_Type VALUES(''aa616051-e521-4fac-abdb-cbba6f8c6e73'',''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''5c893080-9e8c-4fe2-97aa-87878d38ac4a'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''7a81bf47-2519-4db7-ae54-d1eb416c46af'' AND GUID_Type_Right=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_RelationType=''7dfcb2ed-c91f-4dbe-b455-9ee834002325'')=0
	INSERT INTO semtbl_Type_Type VALUES(''7a81bf47-2519-4db7-ae54-d1eb416c46af'',''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''7dfcb2ed-c91f-4dbe-b455-9ee834002325'',1,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''5a95c5ab-a5ef-47d5-a878-e8a7efcf79a9'' AND GUID_Type_Right=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_RelationType=''b18b99bf-08fa-48cf-ba51-765c0bf5a7b7'')=0
	INSERT INTO semtbl_Type_Type VALUES(''5a95c5ab-a5ef-47d5-a878-e8a7efcf79a9'',''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''b18b99bf-08fa-48cf-ba51-765c0bf5a7b7'',1,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''5a95c5ab-a5ef-47d5-a878-e8a7efcf79a9'' AND GUID_Type_Right=''aa616051-e521-4fac-abdb-cbba6f8c6e73'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Type_Type VALUES(''5a95c5ab-a5ef-47d5-a878-e8a7efcf79a9'',''aa616051-e521-4fac-abdb-cbba6f8c6e73'',''e07469d9-766c-443e-8526-6d9c684f944f'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''c6c9bcb8-0ac9-4713-9417-eeec1453026c'' AND GUID_Type_Right=''13c09f11-175c-4eef-bc8a-0fd8e86d557f'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Type_Type VALUES(''c6c9bcb8-0ac9-4713-9417-eeec1453026c'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'',''e9711603-47db-44d8-a476-fe88290639a4'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_RelationType=''d91da85b-793c-431c-9724-8ddc1ace170e'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''d91da85b-793c-431c-9724-8ddc1ace170e'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''e79ff4de-2e39-4101-b5a1-0055c40f41cd'' AND GUID_RelationType=''dd5a24ec-e2bd-47c2-9761-d4a7db114aed'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''e79ff4de-2e39-4101-b5a1-0055c40f41cd'',''dd5a24ec-e2bd-47c2-9761-d4a7db114aed'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''98005f0d-3bd1-4a6e-af92-2f704071ea29'' AND GUID_RelationType=''4c432601-f11e-4554-884b-1f1606ae2c9c'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''98005f0d-3bd1-4a6e-af92-2f704071ea29'',''4c432601-f11e-4554-884b-1f1606ae2c9c'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''98005f0d-3bd1-4a6e-af92-2f704071ea29'' AND GUID_RelationType=''90d860c7-784c-477c-957a-c6c5a0a71b22'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''98005f0d-3bd1-4a6e-af92-2f704071ea29'',''90d860c7-784c-477c-957a-c6c5a0a71b22'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''98005f0d-3bd1-4a6e-af92-2f704071ea29'' AND GUID_RelationType=''7b476bc9-88db-423d-bb90-e72d38963f1c'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''98005f0d-3bd1-4a6e-af92-2f704071ea29'',''7b476bc9-88db-423d-bb90-e72d38963f1c'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''3181a694-0ce1-44cc-a16c-6c19d2b6b5d9'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''3181a694-0ce1-44cc-a16c-6c19d2b6b5d9'',''e9711603-47db-44d8-a476-fe88290639a4'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''7a81bf47-2519-4db7-ae54-d1eb416c46af'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''7a81bf47-2519-4db7-ae54-d1eb416c46af'',''e9711603-47db-44d8-a476-fe88290639a4'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''c6c9bcb8-0ac9-4713-9417-eeec1453026c'' AND GUID_RelationType=''fafc1464-815f-4596-9737-bcbc96bd744a'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''c6c9bcb8-0ac9-4713-9417-eeec1453026c'',''fafc1464-815f-4596-9737-bcbc96bd744a'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_RelationType=''408db9f1-ae42-4807-b656-729270646f0a'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''408db9f1-ae42-4807-b656-729270646f0a'',0,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_RelationType=''fafc1464-815f-4596-9737-bcbc96bd744a'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''fafc1464-815f-4596-9737-bcbc96bd744a'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute WHERE GUID_TokenAttribute=''3db95968-f23e-4b0d-8998-6c9235006349'' )=0
	INSERT INTO semtbl_Token_Attribute VALUES(''3db95968-f23e-4b0d-8998-6c9235006349'',''76bee339-e97c-4d61-9f1b-337d47af96ac'',''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute_Varchar255 WHERE GUID_TokenAttribute=''3db95968-f23e-4b0d-8998-6c9235006349'' )=0
	INSERT INTO semtbl_Token_Attribute_Varchar255 VALUES(''3db95968-f23e-4b0d-8998-6c9235006349'',''localizing_manager'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''4d3846a5-b238-4da1-8b22-7a8940adca7e'')=0
	INSERT INTO semtbl_OR VALUES(''4d3846a5-b238-4da1-8b22-7a8940adca7e'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''ff951cc8-a55d-4880-98de-49fdbaf9ab5d'')=0
	INSERT INTO semtbl_OR VALUES(''ff951cc8-a55d-4880-98de-49fdbaf9ab5d'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''07024367-2073-47f5-a4c2-dee8b726cc2e'')=0
	INSERT INTO semtbl_OR VALUES(''07024367-2073-47f5-a4c2-dee8b726cc2e'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''5faff2d0-12f8-4820-83c9-03c8a72e0083'')=0
	INSERT INTO semtbl_OR VALUES(''5faff2d0-12f8-4820-83c9-03c8a72e0083'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''61683539-c39a-483e-b39e-d6c143160a58'')=0
	INSERT INTO semtbl_OR VALUES(''61683539-c39a-483e-b39e-d6c143160a58'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''1f1faa3f-4ede-4bf5-8a10-c2e5e51ea368'')=0
	INSERT INTO semtbl_OR VALUES(''1f1faa3f-4ede-4bf5-8a10-c2e5e51ea368'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''af7399e1-2585-44a8-95f1-971b1df05e77'')=0
	INSERT INTO semtbl_OR VALUES(''af7399e1-2585-44a8-95f1-971b1df05e77'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''94639963-9017-4100-a6ab-a0b748ababce'')=0
	INSERT INTO semtbl_OR VALUES(''94639963-9017-4100-a6ab-a0b748ababce'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''ef07a352-2130-4e65-ae0c-d6d2e3190b17'')=0
	INSERT INTO semtbl_OR VALUES(''ef07a352-2130-4e65-ae0c-d6d2e3190b17'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''e8784d4a-42cd-410a-805b-9b1f71a9f297'')=0
	INSERT INTO semtbl_OR VALUES(''e8784d4a-42cd-410a-805b-9b1f71a9f297'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'')=0
	INSERT INTO semtbl_OR VALUES(''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'',''66a7f5c9-bff6-40dc-a893-15bdb65dbf26'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''abdf446b-0a14-47aa-88cc-9a219a4676bf'')=0
	INSERT INTO semtbl_OR VALUES(''abdf446b-0a14-47aa-88cc-9a219a4676bf'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''47121a8b-e65a-4683-b101-9dc5cd1966ac'')=0
	INSERT INTO semtbl_OR VALUES(''47121a8b-e65a-4683-b101-9dc5cd1966ac'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''709463e6-810e-46ac-ac0a-787214d6277b'')=0
	INSERT INTO semtbl_OR VALUES(''709463e6-810e-46ac-ac0a-787214d6277b'',''66a7f5c9-bff6-40dc-a893-15bdb65dbf26'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''b4c5ad2a-995d-478f-ba5c-0fa2c46a207c'')=0
	INSERT INTO semtbl_OR VALUES(''b4c5ad2a-995d-478f-ba5c-0fa2c46a207c'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''66db51c4-c0bd-4612-b39e-451ae9164a7c'')=0
	INSERT INTO semtbl_OR VALUES(''66db51c4-c0bd-4612-b39e-451ae9164a7c'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''a22b5ec6-cebe-4361-8bc5-1ef62524b7fa'')=0
	INSERT INTO semtbl_OR VALUES(''a22b5ec6-cebe-4361-8bc5-1ef62524b7fa'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''5b7370d1-c850-4203-9265-eabc2bcd2021'')=0
	INSERT INTO semtbl_OR VALUES(''5b7370d1-c850-4203-9265-eabc2bcd2021'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''d3c1742e-e3f9-4bb0-883f-3b927fe4f8ff'')=0
	INSERT INTO semtbl_OR VALUES(''d3c1742e-e3f9-4bb0-883f-3b927fe4f8ff'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''b3be716e-19c2-4df8-9887-126bf5e47b6d'')=0
	INSERT INTO semtbl_OR VALUES(''b3be716e-19c2-4df8-9887-126bf5e47b6d'',''66a7f5c9-bff6-40dc-a893-15bdb65dbf26'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''c18c4d8c-dfa5-4275-b4eb-e67272a6bf06'')=0
	INSERT INTO semtbl_OR VALUES(''c18c4d8c-dfa5-4275-b4eb-e67272a6bf06'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''9b3f66e5-7eb1-4912-bdca-f6940f0576f8'')=0
	INSERT INTO semtbl_OR VALUES(''9b3f66e5-7eb1-4912-bdca-f6940f0576f8'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''3e2f1b1a-b99a-4269-bcf2-47de2f20084b'')=0
	INSERT INTO semtbl_OR VALUES(''3e2f1b1a-b99a-4269-bcf2-47de2f20084b'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''4d3846a5-b238-4da1-8b22-7a8940adca7e'')=0
	INSERT INTO semtbl_OR_Type VALUES(''4d3846a5-b238-4da1-8b22-7a8940adca7e'',''3181a694-0ce1-44cc-a16c-6c19d2b6b5d9'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''ff951cc8-a55d-4880-98de-49fdbaf9ab5d'')=0
	INSERT INTO semtbl_OR_Type VALUES(''ff951cc8-a55d-4880-98de-49fdbaf9ab5d'',''5a95c5ab-a5ef-47d5-a878-e8a7efcf79a9'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''07024367-2073-47f5-a4c2-dee8b726cc2e'')=0
	INSERT INTO semtbl_OR_Type VALUES(''07024367-2073-47f5-a4c2-dee8b726cc2e'',''71415eeb-ce46-4b2c-b0a2-f72116b55438'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''5faff2d0-12f8-4820-83c9-03c8a72e0083'')=0
	INSERT INTO semtbl_OR_Type VALUES(''5faff2d0-12f8-4820-83c9-03c8a72e0083'',''aa616051-e521-4fac-abdb-cbba6f8c6e73'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''1f1faa3f-4ede-4bf5-8a10-c2e5e51ea368'')=0
	INSERT INTO semtbl_OR_Type VALUES(''1f1faa3f-4ede-4bf5-8a10-c2e5e51ea368'',''7a81bf47-2519-4db7-ae54-d1eb416c46af'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''ef07a352-2130-4e65-ae0c-d6d2e3190b17'')=0
	INSERT INTO semtbl_OR_Type VALUES(''ef07a352-2130-4e65-ae0c-d6d2e3190b17'',''ac0c99a0-d73d-4dc7-a789-3528a76822de'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''b4c5ad2a-995d-478f-ba5c-0fa2c46a207c'')=0
	INSERT INTO semtbl_OR_Type VALUES(''b4c5ad2a-995d-478f-ba5c-0fa2c46a207c'',''61579228-8a42-4c60-adb5-41a47c8dacbb'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''5b7370d1-c850-4203-9265-eabc2bcd2021'')=0
	INSERT INTO semtbl_OR_Type VALUES(''5b7370d1-c850-4203-9265-eabc2bcd2021'',''e79ff4de-2e39-4101-b5a1-0055c40f41cd'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''9b3f66e5-7eb1-4912-bdca-f6940f0576f8'')=0
	INSERT INTO semtbl_OR_Type VALUES(''9b3f66e5-7eb1-4912-bdca-f6940f0576f8'',''3d62cd71-88e2-4e3d-8a5d-9601da17da1d'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Attribute WHERE GUID_ObjectReference=''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'')=0
	INSERT INTO semtbl_OR_Attribute VALUES(''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'',''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Attribute WHERE GUID_ObjectReference=''709463e6-810e-46ac-ac0a-787214d6277b'')=0
	INSERT INTO semtbl_OR_Attribute VALUES(''709463e6-810e-46ac-ac0a-787214d6277b'',''0d2c794d-281d-44ff-9767-eb8549d4ad16'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Attribute WHERE GUID_ObjectReference=''b3be716e-19c2-4df8-9887-126bf5e47b6d'')=0
	INSERT INTO semtbl_OR_Attribute VALUES(''b3be716e-19c2-4df8-9887-126bf5e47b6d'',''4e173916-e8d7-4640-8ef1-965b74371124'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''61683539-c39a-483e-b39e-d6c143160a58'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''61683539-c39a-483e-b39e-d6c143160a58'',''65df1500-ffa8-4980-9c31-a5caae4a9104'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''af7399e1-2585-44a8-95f1-971b1df05e77'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''af7399e1-2585-44a8-95f1-971b1df05e77'',''cd32af17-bab3-49da-857b-60c5ac809e4e'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''94639963-9017-4100-a6ab-a0b748ababce'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''94639963-9017-4100-a6ab-a0b748ababce'',''d91da85b-793c-431c-9724-8ddc1ace170e'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''e8784d4a-42cd-410a-805b-9b1f71a9f297'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''e8784d4a-42cd-410a-805b-9b1f71a9f297'',''e9711603-47db-44d8-a476-fe88290639a4'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''abdf446b-0a14-47aa-88cc-9a219a4676bf'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''abdf446b-0a14-47aa-88cc-9a219a4676bf'',''413e9c02-9380-4f17-8806-5bd9881b8f89'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''47121a8b-e65a-4683-b101-9dc5cd1966ac'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''47121a8b-e65a-4683-b101-9dc5cd1966ac'',''1700a8b9-5f32-44ec-8687-1c5ddb84e109'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''66db51c4-c0bd-4612-b39e-451ae9164a7c'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''66db51c4-c0bd-4612-b39e-451ae9164a7c'',''5c893080-9e8c-4fe2-97aa-87878d38ac4a'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''a22b5ec6-cebe-4361-8bc5-1ef62524b7fa'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''a22b5ec6-cebe-4361-8bc5-1ef62524b7fa'',''7dfcb2ed-c91f-4dbe-b455-9ee834002325'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''d3c1742e-e3f9-4bb0-883f-3b927fe4f8ff'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''d3c1742e-e3f9-4bb0-883f-3b927fe4f8ff'',''e07469d9-766c-443e-8526-6d9c684f944f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''c18c4d8c-dfa5-4275-b4eb-e67272a6bf06'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''c18c4d8c-dfa5-4275-b4eb-e67272a6bf06'',''dd5a24ec-e2bd-47c2-9761-d4a7db114aed'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''3e2f1b1a-b99a-4269-bcf2-47de2f20084b'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''3e2f1b1a-b99a-4269-bcf2-47de2f20084b'',''b18b99bf-08fa-48cf-ba51-765c0bf5a7b7'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''6a1f040b-3477-47c6-8718-0050bddebddd'' AND GUID_ObjectReference=''4d3846a5-b238-4da1-8b22-7a8940adca7e'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''6a1f040b-3477-47c6-8718-0050bddebddd'',''4d3846a5-b238-4da1-8b22-7a8940adca7e'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''34393d78-0f7c-40a0-a194-088fcc517b14'' AND GUID_ObjectReference=''ff951cc8-a55d-4880-98de-49fdbaf9ab5d'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''34393d78-0f7c-40a0-a194-088fcc517b14'',''ff951cc8-a55d-4880-98de-49fdbaf9ab5d'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''1d7fefa9-2304-450d-9a4a-0a3c4be58ccc'' AND GUID_ObjectReference=''07024367-2073-47f5-a4c2-dee8b726cc2e'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''1d7fefa9-2304-450d-9a4a-0a3c4be58ccc'',''07024367-2073-47f5-a4c2-dee8b726cc2e'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''99ca8ff9-2940-493a-a276-0bcbd8a9f227'' AND GUID_ObjectReference=''5faff2d0-12f8-4820-83c9-03c8a72e0083'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''99ca8ff9-2940-493a-a276-0bcbd8a9f227'',''5faff2d0-12f8-4820-83c9-03c8a72e0083'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''5f151ab3-63fd-41d1-b582-1a5c59966ac9'' AND GUID_ObjectReference=''61683539-c39a-483e-b39e-d6c143160a58'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''5f151ab3-63fd-41d1-b582-1a5c59966ac9'',''61683539-c39a-483e-b39e-d6c143160a58'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''bb22c77c-d2d3-4dc1-990d-27bafdbb35a4'' AND GUID_ObjectReference=''1f1faa3f-4ede-4bf5-8a10-c2e5e51ea368'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''bb22c77c-d2d3-4dc1-990d-27bafdbb35a4'',''1f1faa3f-4ede-4bf5-8a10-c2e5e51ea368'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''ecca8471-4f62-44a8-934f-2d107685c4ec'' AND GUID_ObjectReference=''af7399e1-2585-44a8-95f1-971b1df05e77'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''ecca8471-4f62-44a8-934f-2d107685c4ec'',''af7399e1-2585-44a8-95f1-971b1df05e77'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''fb69b5e3-2b0a-47ad-8424-4692c2e83175'' AND GUID_ObjectReference=''94639963-9017-4100-a6ab-a0b748ababce'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''fb69b5e3-2b0a-47ad-8424-4692c2e83175'',''94639963-9017-4100-a6ab-a0b748ababce'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''f270a55b-1e57-4594-a6ff-62f42e60157a'' AND GUID_ObjectReference=''ef07a352-2130-4e65-ae0c-d6d2e3190b17'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''f270a55b-1e57-4594-a6ff-62f42e60157a'',''ef07a352-2130-4e65-ae0c-d6d2e3190b17'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''6c966e3c-c737-4af1-9970-68c8323679bc'' AND GUID_ObjectReference=''e8784d4a-42cd-410a-805b-9b1f71a9f297'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''6c966e3c-c737-4af1-9970-68c8323679bc'',''e8784d4a-42cd-410a-805b-9b1f71a9f297'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'' AND GUID_ObjectReference=''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'',''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''7cf624f0-86a2-46d7-ab81-6caa34c1175a'' AND GUID_ObjectReference=''abdf446b-0a14-47aa-88cc-9a219a4676bf'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''7cf624f0-86a2-46d7-ab81-6caa34c1175a'',''abdf446b-0a14-47aa-88cc-9a219a4676bf'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''15820ab1-0945-4e72-9792-6dd480e73954'' AND GUID_ObjectReference=''47121a8b-e65a-4683-b101-9dc5cd1966ac'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''15820ab1-0945-4e72-9792-6dd480e73954'',''47121a8b-e65a-4683-b101-9dc5cd1966ac'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''5a93b671-9910-47b7-9844-6fc59a2b8c95'' AND GUID_ObjectReference=''709463e6-810e-46ac-ac0a-787214d6277b'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''5a93b671-9910-47b7-9844-6fc59a2b8c95'',''709463e6-810e-46ac-ac0a-787214d6277b'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''5d5b5653-830b-47b4-b9e1-741c58ec7d97'' AND GUID_ObjectReference=''b4c5ad2a-995d-478f-ba5c-0fa2c46a207c'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''5d5b5653-830b-47b4-b9e1-741c58ec7d97'',''b4c5ad2a-995d-478f-ba5c-0fa2c46a207c'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''f2cde058-614e-41cb-96eb-78bbcf285171'' AND GUID_ObjectReference=''66db51c4-c0bd-4612-b39e-451ae9164a7c'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''f2cde058-614e-41cb-96eb-78bbcf285171'',''66db51c4-c0bd-4612-b39e-451ae9164a7c'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''983de3aa-2a11-4fd1-8ba6-8848929ede62'' AND GUID_ObjectReference=''a22b5ec6-cebe-4361-8bc5-1ef62524b7fa'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''983de3aa-2a11-4fd1-8ba6-8848929ede62'',''a22b5ec6-cebe-4361-8bc5-1ef62524b7fa'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''87eb4dc0-bdae-4c49-bf3c-a70ea7a6a4d6'' AND GUID_ObjectReference=''5b7370d1-c850-4203-9265-eabc2bcd2021'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''87eb4dc0-bdae-4c49-bf3c-a70ea7a6a4d6'',''5b7370d1-c850-4203-9265-eabc2bcd2021'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''3186cc5e-023b-4edc-b6c7-a89919320839'' AND GUID_ObjectReference=''d3c1742e-e3f9-4bb0-883f-3b927fe4f8ff'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''3186cc5e-023b-4edc-b6c7-a89919320839'',''d3c1742e-e3f9-4bb0-883f-3b927fe4f8ff'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''5eb07eaf-d049-440a-a22a-c402d569f775'' AND GUID_ObjectReference=''b3be716e-19c2-4df8-9887-126bf5e47b6d'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''5eb07eaf-d049-440a-a22a-c402d569f775'',''b3be716e-19c2-4df8-9887-126bf5e47b6d'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''e5268521-7038-464e-99f1-cebd83004cc2'' AND GUID_ObjectReference=''c18c4d8c-dfa5-4275-b4eb-e67272a6bf06'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''e5268521-7038-464e-99f1-cebd83004cc2'',''c18c4d8c-dfa5-4275-b4eb-e67272a6bf06'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''36eb44c2-eb95-43a7-b187-d403c1a8983a'' AND GUID_ObjectReference=''9b3f66e5-7eb1-4912-bdca-f6940f0576f8'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''36eb44c2-eb95-43a7-b187-d403c1a8983a'',''9b3f66e5-7eb1-4912-bdca-f6940f0576f8'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''22faaa6d-8fbe-4b5a-8856-dec1fbcb5959'' AND GUID_ObjectReference=''3e2f1b1a-b99a-4269-bcf2-47de2f20084b'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''22faaa6d-8fbe-4b5a-8856-dec1fbcb5959'',''3e2f1b1a-b99a-4269-bcf2-47de2f20084b'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_OR WHERE GUID_Type=''13c09f11-175c-4eef-bc8a-0fd8e86d557f'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Type_OR VALUES(''13c09f11-175c-4eef-bc8a-0fd8e86d557f'',''e07469d9-766c-443e-8526-6d9c684f944f'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_OR WHERE GUID_Type=''ac0c99a0-d73d-4dc7-a789-3528a76822de'' AND GUID_RelationType=''413e9c02-9380-4f17-8806-5bd9881b8f89'')=0
	INSERT INTO semtbl_Type_OR VALUES(''ac0c99a0-d73d-4dc7-a789-3528a76822de'',''413e9c02-9380-4f17-8806-5bd9881b8f89'',-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_OR WHERE GUID_Type=''3d62cd71-88e2-4e3d-8a5d-9601da17da1d'' AND GUID_RelationType=''65df1500-ffa8-4980-9c31-a5caae4a9104'')=0
	INSERT INTO semtbl_Type_OR VALUES(''3d62cd71-88e2-4e3d-8a5d-9601da17da1d'',''65df1500-ffa8-4980-9c31-a5caae4a9104'',0,-1)'
GO
