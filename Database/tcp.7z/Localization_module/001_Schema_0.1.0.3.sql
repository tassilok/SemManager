CREATE DATABASE sem_db_tcp_localization_module
GO
use [sem_db_change]
use [sem_db_tcp_localization_module]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Triggers

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Tables]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Triggers]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Tables]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Triggers]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Synonyms

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_ORType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_ORType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_ORType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Varchar255]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Varchar255] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Varchar255]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Int]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Int] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Int]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_RelationType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_RelationType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_RelationType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Datetime]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Datetime] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Datetime]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Int]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Int] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Int]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Real]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Real] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Real]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Varchar255]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Varchar255] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Varchar255]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Time]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Time] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Time]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Time]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_attribute_time] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_attribute_time]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Bit]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Bit] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Bit]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Date]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Date] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Date]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Datetime]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_attribute_datetime] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_attribute_datetime]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_VarcharMax]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_varcharMAX] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_varcharMAX]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Bit]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Bit] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Bit]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Date]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Date] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Date]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Real]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Real] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Real]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_AttributeType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_AttributeType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_AttributeType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_VARCHARMAX]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_VARCHARMAX] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_VARCHARMAX]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_AttributeType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_AttributeType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_AttributeType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_RelationType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_RelationType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_RelationType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Triggers

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Triggers

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Views

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Synonyms]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Triggers]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Synonyms

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================



-- Author:		<Author,,Name>



-- Create date: <Create Date,,>



-- Description:	<Description,,>



-- =============================================



CREATE PROCEDURE [dbo].[proc_TSQL_Views]



	-- Add the parameters for the stored procedure here



	



AS



BEGIN



	-- SET NOCOUNT ON added to prevent extra result sets from



	-- interfering with SELECT statements.



	SET NOCOUNT ON;







    -- Insert statements for procedure here



	SELECT * FROM sys.views ORDER BY name



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Synonyms

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Tables

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Tables

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Tables

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Tables

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Synonyms

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================



-- Author:		<Author,,Name>



-- Create date: <Create Date,,>



-- Description:	<Description,,>



-- =============================================



CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]



	-- Add the parameters for the stored procedure here







AS



BEGIN



	-- SET NOCOUNT ON added to prevent extra result sets from



	-- interfering with SELECT statements.



	SET NOCOUNT ON;







    -- Insert statements for procedure here



	SELECT * FROM sys.procedures ORDER By name



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Tables]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Triggers

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Localized_Names]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Localized_Names]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	DECLARE @GUID_Type			uniqueidentifier;
	DECLARE @Name_Type			varchar(255);

	SET @Name_Type = ''Localized Names'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);

	-- Return the result of the function
	RETURN @GUID_Type

END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Named_GUIDType]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date, ,>

-- Description:	<Description, ,>

-- =============================================

CREATE FUNCTION [dbo].[func_Named_GUIDType]

(

	-- Add the parameters for the function here

	@Name_Type		varchar(255)

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_Type		uniqueidentifier



	SET @GUID_Type = (SELECT     GUID_Type

		FROM         semtbl_Type

		WHERE     (Name_Type = @Name_Type));

	RETURN @GUID_Type;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_GUI_Entires]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_GUI_Entires] 
(	
	-- Add the parameters for the function here
	@GUID_Type_GUI_Entires		uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     GUID_Token AS GUID_GUI_Entires, Name_Token AS Name_GUI_Entires, GUID_Type AS GUID_Type_GUI_Entires
FROM         semtbl_Token
WHERE     (GUID_Type = @GUID_Type_GUI_Entires)
)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_described_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_described_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is described by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Codepage]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Codepage]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Codepage'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Language]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Language'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Named_GUIDRelationType]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date, ,>

-- Description:	<Description, ,>

-- =============================================

CREATE FUNCTION [dbo].[func_Named_GUIDRelationType]

(

	-- Add the parameters for the function here

	@Name_RelationType		varchar(255)

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType		uniqueidentifier



	SET @GUID_RelationType = (SELECT     GUID_RelationType

		FROM         semtbl_RelationType

		WHERE     (Name_RelationType = @Name_RelationType));

	RETURN @GUID_RelationType;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semfunc_ObjectReference]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION [dbo].[semfunc_ObjectReference]

(	

	-- Add the parameters for the function here

	

)

RETURNS @tmptbl_Token_Or TABLE 

(

	GUID_ObjectReference		uniqueidentifier,

	Name_Token					varchar(255),

	GUID_Ref					uniqueidentifier,

	GUID_ItemType				uniqueidentifier

)

AS

BEGIN

	DECLARE @GUID_OR_Type_Attribute uniqueidentifier;

	DECLARE @GUID_OR_Type_AttributeType uniqueidentifier;

	DECLARE @GUID_OR_Type_RelationType uniqueidentifier;

	DECLARE @GUID_OR_Type_Token uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Bit uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Date uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Datetime uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Int uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Real uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Time uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_VARCHAR255 uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_VARCHARMax uniqueidentifier;

	DECLARE @GUID_OR_Token_Token	uniqueidentifier;

	DECLARE @GUID_OR_Type			uniqueidentifier;

	DECLARE @GUID_OR_Type_Type_Attribute	uniqueidentifier;

	DECLARE @GUID_OR_Type_Type			uniqueidentifier;



	DECLARE @GUID_ObjectReference	uniqueidentifier;

	DECLARE @Name_Token				varchar(255);

	DECLARE @GUID_Ref				uniqueidentifier;

	DECLARE @GUID_ItemType			uniqueidentifier;

	

	SET @GUID_OR_Type_Attribute = (SELECT     GUID_ObjectReferenceType		

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Attribute''));

	SET @GUID_OR_Type_AttributeType = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''AttributeType''));

	SET @GUID_OR_Type_RelationType = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''RelationType''));

	SET @GUID_OR_Type_Token = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token''));

	SET @GUID_OR_Type_Token_Attribute_Bit = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Bit''));

	SET @GUID_OR_Type_Token_Attribute_Date = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Date''));

	SET @GUID_OR_Type_Token_Attribute_Datetime = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Datetime''));

	SET @GUID_OR_Type_Token_Attribute_Int = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Int''));

	SET @GUID_OR_Type_Token_Attribute_Real = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Real''));

	SET @GUID_OR_Type_Token_Attribute_Time = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Time''));

	SET @GUID_OR_Type_Token_Attribute_VARCHAR255 = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Varchar255''));

	SET @GUID_OR_Type_Token_Attribute_VARCHARMAX = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-VarcharMax''));

	SET @GUID_OR_Token_Token = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Token''));

	SET @GUID_OR_Type = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Type''));

	SET @GUID_OR_Type_Type_Attribute = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Type-Attribute''));

	SET @GUID_OR_Type_Type = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Type-Type''));



	-- Attribute

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_Attribute.GUID_ObjectReference, 

				semtbl_Attribute.GUID_Attribute, 

				semtbl_Attribute.Name_Attribute

			FROM         semtbl_OR_Attribute INNER JOIN

								  semtbl_Attribute ON semtbl_OR_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute;

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Attribute)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Attribute-Type

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_AttributeType.GUID_ObjectReference, 

				semtbl_AttributeType.GUID_AttributeType, 

				semtbl_AttributeType.Name_AttributeType

			FROM         semtbl_OR_AttributeType INNER JOIN

                      semtbl_AttributeType ON semtbl_OR_AttributeType.GUID_AttributeType = semtbl_AttributeType.GUID_AttributeType

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Attribute-Type: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_AttributeType)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- RelationType

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_RelationType.GUID_ObjectReference, 

				semtbl_RelationType.GUID_RelationType, 

				semtbl_RelationType.Name_RelationType

			FROM         semtbl_OR_RelationType INNER JOIN

                      semtbl_RelationType ON semtbl_OR_RelationType.GUID_RelationType = semtbl_RelationType.GUID_RelationType

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''RelationType: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_RelationType)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- Token

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_Token.GUID_ObjectReference, 

				semtbl_Token.GUID_Token, 

				semtbl_Token.Name_Token + ''\'' + semtbl_Type.Name_Type AS Name_Token_With_Type

			FROM         semtbl_OR_Token INNER JOIN

								  semtbl_Token ON semtbl_OR_Token.GUID_Token = semtbl_Token.GUID_Token INNER JOIN

								  semtbl_Type ON semtbl_Token.GUID_Type = semtbl_Type.GUID_Type

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- Token-Attribute-Bit

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_Token_Attribute_Bit.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

				FROM         semtbl_Token INNER JOIN

									  semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

									  semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

									  semtbl_OR_Token_Attribute_Bit ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Bit.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Bit)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Date

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Date.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Date ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Date.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Date)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Datetime

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_Token_Attribute_Datetime.GUID_ObjectReference, 

				semtbl_Token_Attribute.GUID_TokenAttribute, 

                semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

				FROM         semtbl_Token INNER JOIN

									  semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

									  semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

									  semtbl_OR_Token_Attribute_Datetime ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Datetime.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Datetime)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Int

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Int.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Int ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Int.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Int)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Real

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Real.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Real ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Real.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Real)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Time

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Time.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Time ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Time.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Time)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Varchar255

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Varchar255.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Varchar255 ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Varchar255.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_VARCHAR255)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-VarcharMAX

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_VARCHARMAX.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_VARCHARMAX ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_VARCHARMAX.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_VARCHARMax)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Token

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Token.GUID_ObjectReference, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Type.Name_Type + ''/'' + semtbl_RelationType.Name_RelationType + ''/'' + semtbl_Token_1.Name_Token + ''\'' + semtbl_Type_1.Name_Type

                       AS Name_Ref

			FROM         semtbl_Token AS semtbl_Token_1 INNER JOIN

                      semtbl_Token INNER JOIN

                      semtbl_RelationType INNER JOIN

                      semtbl_OR_Token_Token ON semtbl_RelationType.GUID_RelationType = semtbl_OR_Token_Token.GUID_RelationType ON 

                      semtbl_Token.GUID_Token = semtbl_OR_Token_Token.GUID_Token_Left ON semtbl_Token_1.GUID_Token = semtbl_OR_Token_Token.GUID_Token_Right INNER JOIN

                      semtbl_Type ON semtbl_Token.GUID_Type = semtbl_Type.GUID_Type INNER JOIN

                      semtbl_Type AS semtbl_Type_1 ON semtbl_Token_1.GUID_Type = semtbl_Type_1.GUID_Type

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Token: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or (GUID_ObjectReference,Name_Token,GUID_ItemType)VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_OR_Token_Token)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	-- Type

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Type.GUID_ObjectReference, semtbl_Type.GUID_Type, semtbl_Type.Name_Type

FROM         semtbl_OR_Type INNER JOIN

                      semtbl_Type ON semtbl_OR_Type.GUID_Type = semtbl_Type.GUID_Type

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Type: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- Type-Attribute

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Type_Attribute.GUID_ObjectReference, semtbl_Type.Name_Type + ''\[Name_Attribute]'' AS Name_Ref

FROM         semtbl_OR_Type_Attribute INNER JOIN

                      semtbl_Type ON semtbl_OR_Type_Attribute.GUID_Type = semtbl_Type.GUID_Type INNER JOIN

                      semtbl_Attribute ON semtbl_OR_Type_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Type-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or (GUID_ObjectReference,Name_Token,GUID_ItemType)VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_OR_Type_Type_Attribute)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- Type-Type

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT   semtbl_OR_Type_Type.GUID_ObjectReference, 

                 semtbl_Type.Name_Type + ''/'' + semtbl_RelationType.Name_RelationType + semtbl_Type_1.Name_Type AS Name_Ref

			FROM         semtbl_Type INNER JOIN

                      semtbl_RelationType INNER JOIN

                      semtbl_OR_Type_Type ON semtbl_RelationType.GUID_RelationType = semtbl_OR_Type_Type.GUID_RelationType INNER JOIN

                      semtbl_Type AS semtbl_Type_1 ON semtbl_OR_Type_Type.GUID_Type_Right = semtbl_Type_1.GUID_Type ON 

                      semtbl_Type.GUID_Type = semtbl_OR_Type_Type.GUID_Type_Left

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Type-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or (GUID_ObjectReference,Name_Token,GUID_ItemType)VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_OR_Type_Type)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	RETURN

END




'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Localized_Description]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Localized_Description] 
(	
	-- Add the parameters for the function here
	@GUID_Type_Localized_Description		uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     GUID_Token AS GUID_Localized_Description, Name_Token AS Name_Localized_Description, GUID_Type AS GUID_Type_Localized_Description
FROM         semtbl_Token
WHERE     (GUID_Type = @GUID_Type_Localized_Description)
)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Language] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Language		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Language, Name_Token AS Name_Language, GUID_Type AS GUID_Type_Language

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Language)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_additional]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_additional]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	-- Declare the return variable here
	DECLARE @GUID_RelationType			uniqueidentifier;
	DECLARE @Name_RelationType			varchar(255);

	SET @Name_RelationType = ''additional'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);

	-- Return the result of the function
	RETURN @GUID_RelationType

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Message]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Message]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Message'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_defined_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_defined_by]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	-- Declare the return variable here
	DECLARE @GUID_RelationType			uniqueidentifier;
	DECLARE @Name_RelationType			varchar(255);

	SET @Name_RelationType = ''is defined by'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);

	-- Return the result of the function
	RETURN @GUID_RelationType

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Language] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Language		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Language, Name_Token AS Name_Language, GUID_Type AS GUID_Type_Language

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Language)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Language] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Language		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Language, Name_Token AS Name_Language, GUID_Type AS GUID_Type_Language

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Language)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_ToolTip_Messages]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_ToolTip_Messages]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	DECLARE @GUID_Type			uniqueidentifier;
	DECLARE @Name_Type			varchar(255);

	SET @Name_Type = ''ToolTip-Messages'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);

	-- Return the result of the function
	RETURN @GUID_Type

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Language]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Language'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_Standard]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_Standard]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''Standard'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Software_Development]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Software_Development]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	DECLARE @GUID_Type			uniqueidentifier;
	DECLARE @Name_Type			varchar(255);

	SET @Name_Type = ''Software-Development'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);

	-- Return the result of the function
	RETURN @GUID_Type

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Language]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Language'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_GUI_Caption]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_GUI_Caption] 
(	
	-- Add the parameters for the function here
	@GUID_Type_GUI_Caption		uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     GUID_Token AS GUID_GUI_Caption, Name_Token AS Name_GUI_Caption, GUID_Type AS GUID_Type_GUI_Caption
FROM         semtbl_Token
WHERE     (GUID_Type = @GUID_Type_GUI_Caption)
)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_described_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_described_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is described by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Software_Development]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Software_Development] 
(	
	-- Add the parameters for the function here
	@GUID_Type_Software_Development		uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     GUID_Token AS GUID_Software_Development, Name_Token AS Name_Software_Development, GUID_Type AS GUID_Type_Software_Development
FROM         semtbl_Token
WHERE     (GUID_Type = @GUID_Type_Software_Development)
)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_db_postfix]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_db_postfix]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''db_postfix'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_alternative_for]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_alternative_for]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	-- Declare the return variable here
	DECLARE @GUID_RelationType			uniqueidentifier;
	DECLARE @Name_RelationType			varchar(255);

	SET @Name_RelationType = ''alternative for'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);

	-- Return the result of the function
	RETURN @GUID_RelationType

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_GUI_Caption]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_GUI_Caption]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	DECLARE @GUID_Type			uniqueidentifier;
	DECLARE @Name_Type			varchar(255);

	SET @Name_Type = ''GUI-Caption'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);

	-- Return the result of the function
	RETURN @GUID_Type

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_written_in]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_written_in]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	-- Declare the return variable here
	DECLARE @GUID_RelationType			uniqueidentifier;
	DECLARE @Name_RelationType			varchar(255);

	SET @Name_RelationType = ''is written in'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);

	-- Return the result of the function
	RETURN @GUID_RelationType

END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_GUI_Entires]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_GUI_Entires]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	DECLARE @GUID_Type			uniqueidentifier;
	DECLARE @Name_Type			varchar(255);

	SET @Name_Type = ''GUI-Entires'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);

	-- Return the result of the function
	RETURN @GUID_Type

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Named_GUIDAttribute]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date, ,>

-- Description:	<Description, ,>

-- =============================================

CREATE FUNCTION [dbo].[func_Named_GUIDAttribute]

(

	-- Add the parameters for the function here

	@Name_Attribute		varchar(255)

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_Attribute		uniqueidentifier



	SET @GUID_Attribute = (SELECT     GUID_Attribute

		FROM         semtbl_Attribute

		WHERE     (Name_Attribute = @Name_Attribute));

	RETURN @GUID_Attribute;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Localized_Description]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Localized_Description]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	DECLARE @GUID_Type			uniqueidentifier;
	DECLARE @Name_Type			varchar(255);

	SET @Name_Type = ''Localized Description'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);

	-- Return the result of the function
	RETURN @GUID_Type

END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_ToolTip_Messages]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_ToolTip_Messages] 
(	
	-- Add the parameters for the function here
	@GUID_Type_ToolTip_Messages		uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     GUID_Token AS GUID_ToolTip_Messages, Name_Token AS Name_ToolTip_Messages, GUID_Type AS GUID_Type_ToolTip_Messages
FROM         semtbl_Token
WHERE     (GUID_Type = @GUID_Type_ToolTip_Messages)
)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_contains]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_contains]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''contains'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Localized_Names]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Localized_Names] 
(	
	-- Add the parameters for the function here
	@GUID_Type_Localized_Names		uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     GUID_Token AS GUID_Localized_Names, Name_Token AS Name_Localized_Names, GUID_Type AS GUID_Type_Localized_Names
FROM         semtbl_Token
WHERE     (GUID_Type = @GUID_Type_Localized_Names)
)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_described_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_described_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is described by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Message]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Message]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Message'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_describes]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[dbg_RelationType_describes]
(
	-- Add the parameters for the function here
	
)
RETURNS uniqueidentifier
AS
BEGIN
	-- Declare the return variable here
	DECLARE @GUID_RelationType			uniqueidentifier;
	DECLARE @Name_RelationType			varchar(255);

	SET @Name_RelationType = ''describes'';
	-- Add the T-SQL statements to compute the return value here
	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);

	-- Return the result of the function
	RETURN @GUID_RelationType

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_GUIEntries_Of_SoftwareDevelopment]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[proc_GUIEntries_Of_SoftwareDevelopment]
	-- Add the parameters for the stored procedure here
	@GUID_Type_SoftwareDevelopment		uniqueidentifier,
	@GUID_Type_Language					uniqueidentifier,
	@GUID_Type_ToolTipMessage			uniqueidentifier,
	@GUID_Type_GUICaption				uniqueidentifier,
	@GUID_Type_GUIEntries				uniqueidentifier,
	@GUID_RelationType_isWrittenIn		uniqueidentifier,
	@GUID_RelationType_isDefinedBy		uniqueidentifier,
	@GUID_RelationType_contains			uniqueidentifier,
	@GUID_Language						uniqueidentifier,
	@GUID_SoftwareDevelopment			uniqueidentifier,
	@Name_GUIEntry						varchar(255)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT     func_Token_Software_Development_1.GUID_Software_Development, func_Token_Software_Development_1.Name_Software_Development, 
                      func_Token_Software_Development_1.GUID_Type_Software_Development, func_Token_GUI_Entires_1.GUID_GUI_Entires, 
                      func_Token_GUI_Entires_1.Name_GUI_Entires, func_Token_GUI_Entires_1.GUID_Type_GUI_Entires, 
                      func_GUICaption_And_Language_Of_GUIEntry_1.Name_GUI_Caption, func_ToolTipMessage_And_Language_Of_GUIEntry_1.Name_ToolTip_Messages
FROM         dbo.func_Token_Software_Development(@GUID_Type_SoftwareDevelopment) AS func_Token_Software_Development_1 INNER JOIN
                      semtbl_Token_Token AS SoftwareDevelopments_To_GUIEntries ON 
                      func_Token_Software_Development_1.GUID_Software_Development = SoftwareDevelopments_To_GUIEntries.GUID_Token_Left INNER JOIN
                      dbo.func_Token_GUI_Entires(@GUID_Type_GUIEntries) AS func_Token_GUI_Entires_1 ON 
                      SoftwareDevelopments_To_GUIEntries.GUID_Token_Right = func_Token_GUI_Entires_1.GUID_GUI_Entires LEFT OUTER JOIN
                      dbo.func_ToolTipMessage_And_Language_Of_GUIEntry(@GUID_Type_Language, @GUID_Type_ToolTipMessage, @GUID_RelationType_isWrittenIn, 
                      @GUID_RelationType_isDefinedBy, @GUID_Language) AS func_ToolTipMessage_And_Language_Of_GUIEntry_1 ON 
                      func_Token_GUI_Entires_1.GUID_GUI_Entires = func_ToolTipMessage_And_Language_Of_GUIEntry_1.GUID_GUIEntry LEFT OUTER JOIN
                      dbo.func_GUICaption_And_Language_Of_GUIEntry(@GUID_Type_GUICaption, @GUID_Type_Language, @GUID_RelationType_isDefinedBy, 
                      @GUID_RelationType_isWrittenIn, @GUID_Language) AS func_GUICaption_And_Language_Of_GUIEntry_1 ON 
                      func_Token_GUI_Entires_1.GUID_GUI_Entires = func_GUICaption_And_Language_Of_GUIEntry_1.GUI_Entry
WHERE     (SoftwareDevelopments_To_GUIEntries.GUID_RelationType = @GUID_RelationType_contains) AND 
                      (func_Token_Software_Development_1.GUID_Software_Development = @GUID_SoftwareDevelopment) AND 
                      (func_Token_GUI_Entires_1.Name_GUI_Entires = @Name_GUIEntry)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Language_By_CodePage]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE proc_Language_By_CodePage
	-- Add the parameters for the stored procedure here
	@GUID_Type_Language			uniqueidentifier,
	@GUID_Attribute_Codepage	uniqueidentifier,
	@intCodePage				int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT     func_Token_Language_1.GUID_Language, func_Token_Language_1.Name_Language, func_Token_Language_1.GUID_Type_Language, 
                      Language__Codepage_Val.GUID_TokenAttribute, Language__Codepage_Val.val AS Codepage
FROM         dbo.func_Token_Language(@GUID_Type_Language) AS func_Token_Language_1 INNER JOIN
                      semtbl_Token_Attribute AS Language__Codepage ON func_Token_Language_1.GUID_Language = Language__Codepage.GUID_Token INNER JOIN
                      semtbl_Token_Attribute_Int AS Language__Codepage_Val ON Language__Codepage.GUID_TokenAttribute = Language__Codepage_Val.GUID_TokenAttribute
WHERE     (Language__Codepage.GUID_Attribute = @GUID_Attribute_Codepage) AND (Language__Codepage_Val.val = @intCodePage)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_GUICaption_And_Language_Of_GUIEntry]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION func_GUICaption_And_Language_Of_GUIEntry
(	
	-- Add the parameters for the function here
	@GUID_Type_GUICaption				uniqueidentifier,
	@GUID_Type_Language					uniqueidentifier,
	@GUID_RelationType_isDefinedBy		uniqueidentifier,
	@GUID_RelationType_isWrittenIn		uniqueidentifier,
	@GUID_Language						uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     func_Token_GUI_Caption_1.GUID_GUI_Caption, func_Token_GUI_Caption_1.Name_GUI_Caption, func_Token_GUI_Caption_1.GUID_Type_GUI_Caption, 
                      GUI_Entry_To_GUICaption.GUID_Token_Left AS GUI_Entry, func_Token_Language_1.GUID_Language, func_Token_Language_1.Name_Language, 
                      func_Token_Language_1.GUID_Type_Language
FROM         dbo.func_Token_GUI_Caption(@GUID_Type_GUICaption) AS func_Token_GUI_Caption_1 INNER JOIN
                      semtbl_Token_Token AS GUI_Entry_To_GUICaption ON func_Token_GUI_Caption_1.GUID_GUI_Caption = GUI_Entry_To_GUICaption.GUID_Token_Right INNER JOIN
                      semtbl_Token_Token AS GUICaption_To_Language ON func_Token_GUI_Caption_1.GUID_GUI_Caption = GUICaption_To_Language.GUID_Token_Left INNER JOIN
                      dbo.func_Token_Language(@GUID_Type_Language) AS func_Token_Language_1 ON 
                      GUICaption_To_Language.GUID_Token_Right = func_Token_Language_1.GUID_Language
WHERE     (GUI_Entry_To_GUICaption.GUID_RelationType = @GUID_RelationType_isDefinedBy) AND 
                      (GUICaption_To_Language.GUID_RelationType = @GUID_RelationType_isWrittenIn) AND (func_Token_Language_1.GUID_Language = @GUID_Language)
)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_GUICaption_Of_SoftwareDevelopment_By_GUIDSoftwareDevelopment_And_GUIDLanguage]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[proc_GUICaption_Of_SoftwareDevelopment_By_GUIDSoftwareDevelopment_And_GUIDLanguage]
	-- Add the parameters for the stored procedure here
	@GUID_Type_SoftwareDevelopment		uniqueidentifier,
	@GUID_Type_GUICaption				uniqueidentifier,
	@GUID_Type_Language					uniqueidentifier,
	@GUID_RelationType_contains			uniqueidentifier,
	@GUID_RelationType_isWrittenIn		uniqueidentifier,
	@GUID_SoftwareDevelopment			uniqueidentifier,
	@GUID_Language						uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT     func_Token_Software_Development_1.GUID_Software_Development, func_Token_Software_Development_1.Name_Software_Development, 
                      func_Token_Software_Development_1.GUID_Type_Software_Development, func_Token_GUI_Caption_1.GUID_GUI_Caption, 
                      func_Token_GUI_Caption_1.Name_GUI_Caption, func_Token_GUI_Caption_1.GUID_Type_GUI_Caption, func_Token_Language_1.GUID_Language, 
                      func_Token_Language_1.Name_Language, func_Token_Language_1.GUID_Type_Language
FROM         dbo.func_Token_Software_Development(@GUID_Type_SoftwareDevelopment) AS func_Token_Software_Development_1 INNER JOIN
                      semtbl_Token_Token AS SoftwareDevelopment_To_GUICaption ON 
                      func_Token_Software_Development_1.GUID_Software_Development = SoftwareDevelopment_To_GUICaption.GUID_Token_Left INNER JOIN
                      dbo.func_Token_GUI_Caption(@GUID_Type_GUICaption) AS func_Token_GUI_Caption_1 ON 
                      SoftwareDevelopment_To_GUICaption.GUID_Token_Right = func_Token_GUI_Caption_1.GUID_GUI_Caption INNER JOIN
                      semtbl_Token_Token AS GUICaption_To_Language ON func_Token_GUI_Caption_1.GUID_GUI_Caption = GUICaption_To_Language.GUID_Token_Left INNER JOIN
                      dbo.func_Token_Language(@GUID_Type_Language) AS func_Token_Language_1 ON 
                      GUICaption_To_Language.GUID_Token_Right = func_Token_Language_1.GUID_Language
WHERE     (SoftwareDevelopment_To_GUICaption.GUID_RelationType = @GUID_RelationType_contains) AND 
                      (func_Token_Software_Development_1.GUID_Software_Development = @GUID_SoftwareDevelopment) AND 
                      (GUICaption_To_Language.GUID_RelationType = @GUID_RelationType_isWrittenIn) AND (func_Token_Language_1.GUID_Language = @GUID_Language)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_ToolTipMessage_And_Language_Of_GUIEntry]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[func_ToolTipMessage_And_Language_Of_GUIEntry] 
(	
	-- Add the parameters for the function here
	@GUID_Type_Language				uniqueidentifier,
	@GUID_Type_ToolTipMessage		uniqueidentifier,
	@GUID_RelationType_isWrittenIn	uniqueidentifier,
	@GUID_RelationType_isDefinedBy	uniqueidentifier,
	@GUID_Language					uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     func_Token_ToolTip_Messages_1.GUID_ToolTip_Messages, func_Token_ToolTip_Messages_1.Name_ToolTip_Messages, 
                      func_Token_ToolTip_Messages_1.GUID_Type_ToolTip_Messages, semtbl_Token_Token.GUID_Token_Left AS GUID_GUIEntry, 
                      func_Token_Language_1.GUID_Language, func_Token_Language_1.Name_Language, func_Token_Language_1.GUID_Type_Language
FROM         dbo.func_Token_ToolTip_Messages(@GUID_Type_ToolTipMessage) AS func_Token_ToolTip_Messages_1 INNER JOIN
                      semtbl_Token_Token ON func_Token_ToolTip_Messages_1.GUID_ToolTip_Messages = semtbl_Token_Token.GUID_Token_Right INNER JOIN
                      semtbl_Token_Token AS ToolTipMessage_To_Language ON 
                      func_Token_ToolTip_Messages_1.GUID_ToolTip_Messages = ToolTipMessage_To_Language.GUID_Token_Left INNER JOIN
                      dbo.func_Token_Language(@GUID_Type_Language) AS func_Token_Language_1 ON 
                      ToolTipMessage_To_Language.GUID_Token_Right = func_Token_Language_1.GUID_Language
WHERE     (ToolTipMessage_To_Language.GUID_RelationType = @GUID_RelationType_isWrittenIn) AND (func_Token_Language_1.GUID_Language = @GUID_Language) AND 
                      (semtbl_Token_Token.GUID_RelationType = @GUID_RelationType_isDefinedBy)
)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_ToolTipMessage_And_Language_Of_GUIEntry]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbg_ToolTipMessage_And_Language_Of_Message
	-- Add the parameters for the stored procedure here
	@GUID_Language					uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @GUID_Type_Language				uniqueidentifier;
	DECLARE @GUID_Type_ToolTipMessage		uniqueidentifier;
	DECLARE @GUID_RelationType_isWrittenIn	uniqueidentifier;
	DECLARE @GUID_RelationType_isDefinedBy	uniqueidentifier;

	SET @GUID_Type_Language				= dbo.dbg_Type_Language();
	SET @GUID_Type_ToolTipMessage		= dbo.dbg_Type_ToolTip_Messages();
	SET @GUID_RelationType_isWrittenIn	= dbo.dbg_RelationType_is_written_in();
	SET @GUID_RelationType_isDefinedBy	= dbo.dbg_RelationType_is_defined_by();

	PRINT @GUID_Type_Language;
	PRINT @GUID_Type_ToolTipMessage;
	PRINT @GUID_RelationType_isWrittenIn;
	PRINT @GUID_RelationType_isDefinedBy;

    -- Insert statements for procedure here
	SELECT * FROM func_ToolTipMessage_And_Language_Of_Message(
		@GUID_Type_Language,
		@GUID_Type_ToolTipMessage,
		@GUID_RelationType_isWrittenIn,
		@GUID_RelationType_isDefinedBy,
		@GUID_Language)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Alternative_LocalizedNames]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[func_Alternative_LocalizedNames]
(	
	-- Add the parameters for the function here
	@GUID_Type_LocalizedNames			uniqueidentifier,
	@GUID_Type_Language					uniqueidentifier,
	@GUID_RelationType_alternativeFor	uniqueidentifier,
	@GUID_RelationType_isWrittenIn		uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     semtbl_Token.GUID_Token, semtbl_Token.Name_Token, semtbl_Token.GUID_Type, semtbl_Token_1.GUID_Token AS GUID_Token_Language, 
                      semtbl_Token_1.Name_Token AS Name_Token_Language, semtbl_Token_1.GUID_Type AS GUID_Type_Language, semfunc_ObjectReference_1.GUID_Ref, 
                      semfunc_ObjectReference_1.GUID_ItemType
FROM         semtbl_Token INNER JOIN
                      semtbl_Token_Token AS semtbl_Token_Token_1 ON semtbl_Token.GUID_Token = semtbl_Token_Token_1.GUID_Token_Left INNER JOIN
                      semtbl_Token AS semtbl_Token_1 ON semtbl_Token_Token_1.GUID_Token_Right = semtbl_Token_1.GUID_Token INNER JOIN
                      semtbl_Token_OR ON semtbl_Token.GUID_Token = semtbl_Token_OR.GUID_Token_Left INNER JOIN
                      dbo.semfunc_ObjectReference() AS semfunc_ObjectReference_1 ON 
                      semtbl_Token_OR.GUID_ObjectReference = semfunc_ObjectReference_1.GUID_ObjectReference
WHERE     (semtbl_Token.GUID_Type = @GUID_Type_LocalizedNames) AND (semtbl_Token_Token_1.GUID_RelationType = @GUID_RelationType_isWrittenIn) AND 
                      (semtbl_Token_1.GUID_Type = @GUID_Type_Language) AND (semtbl_Token_OR.GUID_RelationType = @GUID_RelationType_alternativeFor)
)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Language_By_CodePage]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbg_Language_By_CodePage
	-- Add the parameters for the stored procedure here
	
	@intCodePage				int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @GUID_Type_Language			uniqueidentifier;
	DECLARE @GUID_Attribute_Codepage	uniqueidentifier;
	

	SET @GUID_Type_Language			= dbo.dbg_Type_Language();
	SET @GUID_Attribute_Codepage	= dbo.dbg_AttributeType_Codepage();
	
	PRINT @GUID_Type_Language;
	PRINT @GUID_Attribute_Codepage;

    -- Insert statements for procedure here
	SELECT     func_Token_Language_1.GUID_Language, func_Token_Language_1.Name_Language, func_Token_Language_1.GUID_Type_Language, 
                      Language__Codepage_Val.GUID_TokenAttribute, Language__Codepage_Val.val AS Codepage
FROM         dbo.func_Token_Language(@GUID_Type_Language) AS func_Token_Language_1 INNER JOIN
                      semtbl_Token_Attribute AS Language__Codepage ON func_Token_Language_1.GUID_Language = Language__Codepage.GUID_Token INNER JOIN
                      semtbl_Token_Attribute_Int AS Language__Codepage_Val ON Language__Codepage.GUID_TokenAttribute = Language__Codepage_Val.GUID_TokenAttribute
WHERE     (Language__Codepage.GUID_Attribute = @GUID_Attribute_Codepage) AND (Language__Codepage_Val.val = @intCodePage)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_GUICaption_Of_SoftwareDevelopment_By_GUIDSoftwareDevelopment_And_GUIDLanguage]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbg_GUICaption_Of_SoftwareDevelopment_By_GUIDSoftwareDevelopment_And_GUIDLanguage
	-- Add the parameters for the stored procedure here

	@GUID_SoftwareDevelopment			uniqueidentifier,
	@GUID_Language						uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @GUID_Type_SoftwareDevelopment		uniqueidentifier;
	DECLARE @GUID_Type_GUICaption				uniqueidentifier;
	DECLARE @GUID_Type_Language					uniqueidentifier;
	DECLARE @GUID_RelationType_contains			uniqueidentifier;
	DECLARE @GUID_RelationType_isWrittenIn		uniqueidentifier;
	
	SET @GUID_Type_SoftwareDevelopment		= dbo.dbg_Type_Software_Development();
	SET @GUID_Type_GUICaption				= dbo.dbg_Type_GUI_Caption();
	SET @GUID_Type_Language					= dbo.dbg_Type_Language();
	SET @GUID_RelationType_contains			= dbo.dbg_RelationType_contains();
	SET @GUID_RelationType_isWrittenIn		= dbo.dbg_RelationType_is_written_in();
	
	PRINT @GUID_Type_SoftwareDevelopment;
	PRINT @GUID_Type_GUICaption;
	PRINT @GUID_Type_Language;
	PRINT @GUID_RelationType_contains;
	PRINT @GUID_RelationType_isWrittenIn;
		
	-- Insert statements for procedure here
	SELECT     func_Token_Software_Development_1.GUID_Software_Development, func_Token_Software_Development_1.Name_Software_Development, 
                      func_Token_Software_Development_1.GUID_Type_Software_Development, func_Token_GUI_Caption_1.GUID_GUI_Caption, 
                      func_Token_GUI_Caption_1.Name_GUI_Caption, func_Token_GUI_Caption_1.GUID_Type_GUI_Caption, func_Token_Language_1.GUID_Language, 
                      func_Token_Language_1.Name_Language, func_Token_Language_1.GUID_Type_Language
FROM         dbo.func_Token_Software_Development(@GUID_Type_SoftwareDevelopment) AS func_Token_Software_Development_1 INNER JOIN
                      semtbl_Token_Token AS SoftwareDevelopment_To_GUICaption ON 
                      func_Token_Software_Development_1.GUID_Software_Development = SoftwareDevelopment_To_GUICaption.GUID_Token_Left INNER JOIN
                      dbo.func_Token_GUI_Caption(@GUID_Type_GUICaption) AS func_Token_GUI_Caption_1 ON 
                      SoftwareDevelopment_To_GUICaption.GUID_Token_Right = func_Token_GUI_Caption_1.GUID_GUI_Caption INNER JOIN
                      semtbl_Token_Token AS GUICaption_To_Language ON func_Token_GUI_Caption_1.GUID_GUI_Caption = GUICaption_To_Language.GUID_Token_Left INNER JOIN
                      dbo.func_Token_Language(@GUID_Type_Language) AS func_Token_Language_1 ON 
                      GUICaption_To_Language.GUID_Token_Right = func_Token_Language_1.GUID_Language
WHERE     (SoftwareDevelopment_To_GUICaption.GUID_RelationType = @GUID_RelationType_contains) AND 
                      (func_Token_Software_Development_1.GUID_Software_Development = @GUID_SoftwareDevelopment) AND 
                      (GUICaption_To_Language.GUID_RelationType = @GUID_RelationType_isWrittenIn) AND (func_Token_Language_1.GUID_Language = @GUID_Language)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_GUICaption_And_Language_Of_GUIEntry]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbg_GUICaption_And_Language_Of_GUIEntry 
	-- Add the parameters for the stored procedure here
	@GUID_Language		uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @GUID_Type_GUICaption				uniqueidentifier;
	DECLARE @GUID_Type_Language					uniqueidentifier;
	DECLARE @GUID_RelationType_isDefinedBy		uniqueidentifier;
	DECLARE @GUID_RelationType_isWrittenIn		uniqueidentifier;

	SET @GUID_Type_GUICaption				= dbo.dbg_Type_GUI_Caption();
	SET @GUID_Type_Language					= dbo.dbg_Type_Language();
	SET @GUID_RelationType_isDefinedBy		= dbo.dbg_RelationType_is_defined_by();
	SET @GUID_RelationType_isWrittenIn		= dbo.dbg_RelationType_is_written_in();

	PRINT @GUID_Type_GUICaption;
	PRINT @GUID_Type_Language;
	PRINT @GUID_RelationType_isDefinedBy;
	PRINT @GUID_RelationType_isWrittenIn;

    -- Insert statements for procedure here
	SELECT * FROM func_GUICaption_And_Language_Of_GUIEntry(
		@GUID_Type_GUICaption,
		@GUID_Type_Language,
		@GUID_RelationType_isDefinedBy,
		@GUID_RelationType_isWrittenIn,
		@GUID_Language)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Describing_LocalizedDescription]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[func_Describing_LocalizedDescription]
(	
	-- Add the parameters for the function here
	@GUID_Attribute_Message				uniqueidentifier,
	@GUID_Type_LocalizedDescription		uniqueidentifier,
	@GUID_Type_Language					uniqueidentifier,
	@GUID_RelationType_describes		uniqueidentifier,
	@GUID_RelationType_isWrittenIn		uniqueidentifier
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT     semtbl_Token.GUID_Token, semtbl_Token.Name_Token, semtbl_Token.GUID_Type, 
                      semtbl_Token_Attribute_VarcharMax.GUID_TokenAttribute AS GUID_TokenAttribute_Message, semtbl_Token_Attribute_VarcharMax.val AS Message, 
                      semtbl_Token_1.GUID_Token AS GUID_Token_Language, semtbl_Token_1.Name_Token AS Name_Token_Language, 
                      semtbl_Token_1.GUID_Type AS GUID_Type_Language, semfunc_ObjectReference_1.GUID_Ref, semfunc_ObjectReference_1.GUID_ItemType
FROM         semtbl_Token INNER JOIN
                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN
                      semtbl_Token_Attribute_VarcharMax ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_Token_Attribute_VarcharMax.GUID_TokenAttribute INNER JOIN
                      semtbl_Token_Token AS semtbl_Token_Token_1 ON semtbl_Token.GUID_Token = semtbl_Token_Token_1.GUID_Token_Left INNER JOIN
                      semtbl_Token AS semtbl_Token_1 ON semtbl_Token_Token_1.GUID_Token_Right = semtbl_Token_1.GUID_Token INNER JOIN
                      semtbl_Token_OR ON semtbl_Token.GUID_Token = semtbl_Token_OR.GUID_Token_Left INNER JOIN
                      dbo.semfunc_ObjectReference() AS semfunc_ObjectReference_1 ON 
                      semtbl_Token_OR.GUID_ObjectReference = semfunc_ObjectReference_1.GUID_ObjectReference
WHERE     (semtbl_Token.GUID_Type = @GUID_Type_LocalizedDescription) AND (semtbl_Token_Attribute.GUID_Attribute = @GUID_Attribute_Message) AND 
                      (semtbl_Token_Token_1.GUID_RelationType = @GUID_RelationType_isWrittenIn) AND (semtbl_Token_1.GUID_Type = @GUID_Type_Language) AND 
                      (semtbl_Token_OR.GUID_RelationType = @GUID_RelationType_describes)
)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_GUIEntries_Of_SoftwareDevelopment]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbg_GUIEntries_Of_SoftwareDevelopment
	-- Add the parameters for the stored procedure here
	
	@GUID_Language						uniqueidentifier,
	@GUID_SoftwareDevelopment			uniqueidentifier,
	@Name_GUIEntry						varchar(255)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @GUID_Type_SoftwareDevelopment		uniqueidentifier;
	DECLARE @GUID_Type_Language					uniqueidentifier;
	DECLARE @GUID_Type_ToolTipMessage			uniqueidentifier;
	DECLARE @GUID_Type_GUICaption				uniqueidentifier;
	DECLARE @GUID_Type_GUIEntries				uniqueidentifier;
	DECLARE @GUID_RelationType_isWrittenIn		uniqueidentifier;
	DECLARE @GUID_RelationType_isDefinedBy		uniqueidentifier;
	DECLARE @GUID_RelationType_contains			uniqueidentifier;
	

	SET @GUID_Type_SoftwareDevelopment		= dbo.dbg_Type_Software_Development();
	SET @GUID_Type_Language					= dbo.dbg_Type_Language();
	SET @GUID_Type_ToolTipMessage			= dbo.dbg_Type_ToolTip_Messages();
	SET @GUID_Type_GUICaption				= dbo.dbg_Type_GUI_Caption();
	SET @GUID_Type_GUIEntries				= dbo.dbg_Type_GUI_Entires();
	SET @GUID_RelationType_isWrittenIn		= dbo.dbg_RelationType_is_written_in();
	SET @GUID_RelationType_isDefinedBy		= dbo.dbg_RelationType_is_defined_by();
	SET @GUID_RelationType_contains			= dbo.dbg_RelationType_contains();


	PRINT @GUID_Type_SoftwareDevelopment;
	PRINT @GUID_Type_Language;
	PRINT @GUID_Type_ToolTipMessage;
	PRINT @GUID_Type_GUICaption;
	PRINT @GUID_Type_GUIEntries;
	PRINT @GUID_RelationType_isWrittenIn;
	PRINT @GUID_RelationType_isDefinedBy;
	PRINT @GUID_RelationType_contains;


    -- Insert statements for procedure here
	SELECT     func_Token_Software_Development_1.GUID_Software_Development, func_Token_Software_Development_1.Name_Software_Development, 
                      func_Token_Software_Development_1.GUID_Type_Software_Development, func_Token_GUI_Entires_1.GUID_GUI_Entires, 
                      func_Token_GUI_Entires_1.Name_GUI_Entires, func_Token_GUI_Entires_1.GUID_Type_GUI_Entires, 
                      func_GUICaption_And_Language_Of_GUIEntry_1.Name_GUI_Caption, func_ToolTipMessage_And_Language_Of_GUIEntry_1.Name_ToolTip_Messages
FROM         dbo.func_Token_Software_Development(@GUID_Type_SoftwareDevelopment) AS func_Token_Software_Development_1 INNER JOIN
                      semtbl_Token_Token AS SoftwareDevelopments_To_GUIEntries ON 
                      func_Token_Software_Development_1.GUID_Software_Development = SoftwareDevelopments_To_GUIEntries.GUID_Token_Left INNER JOIN
                      dbo.func_Token_GUI_Entires(@GUID_Type_GUIEntries) AS func_Token_GUI_Entires_1 ON 
                      SoftwareDevelopments_To_GUIEntries.GUID_Token_Right = func_Token_GUI_Entires_1.GUID_GUI_Entires LEFT OUTER JOIN
                      dbo.func_ToolTipMessage_And_Language_Of_GUIEntry(@GUID_Type_Language, @GUID_Type_ToolTipMessage, @GUID_RelationType_isWrittenIn, 
                      @GUID_RelationType_isDefinedBy, @GUID_Language) AS func_ToolTipMessage_And_Language_Of_GUIEntry_1 ON 
                      func_Token_GUI_Entires_1.GUID_GUI_Entires = func_ToolTipMessage_And_Language_Of_GUIEntry_1.GUID_GUIEntry LEFT OUTER JOIN
                      dbo.func_GUICaption_And_Language_Of_GUIEntry(@GUID_Type_GUICaption, @GUID_Type_Language, @GUID_RelationType_isDefinedBy, 
                      @GUID_RelationType_isWrittenIn, @GUID_Language) AS func_GUICaption_And_Language_Of_GUIEntry_1 ON 
                      func_Token_GUI_Entires_1.GUID_GUI_Entires = func_GUICaption_And_Language_Of_GUIEntry_1.GUI_Entry
WHERE     (SoftwareDevelopments_To_GUIEntries.GUID_RelationType = @GUID_RelationType_contains) AND 
                      (func_Token_Software_Development_1.GUID_Software_Development = @GUID_SoftwareDevelopment) AND 
                      (func_Token_GUI_Entires_1.Name_GUI_Entires = @Name_GUIEntry)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Describing_LocalizedDescription_By_GUID_Development]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[proc_Describing_LocalizedDescription_By_GUID_Development]
	-- Add the parameters for the stored procedure here
	@GUID_Attribute_Message				uniqueidentifier,
	@GUID_Type_LocalizedDescription		uniqueidentifier,
	@GUID_Type_Language					uniqueidentifier,
	@GUID_RelationType_describes		uniqueidentifier,
	@GUID_RelationType_isWrittenIn		uniqueidentifier,
	@GUID_Token							uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT     GUID_Token, Name_Token, GUID_Type, GUID_TokenAttribute_Message, Message, GUID_Ref, GUID_ItemType, GUID_Token_Language, Name_Token_Language, 
                      GUID_Type_Language
FROM         dbo.func_Describing_LocalizedDescription(@GUID_Attribute_Message, @GUID_Type_LocalizedDescription, @GUID_Type_Language, 
                      @GUID_RelationType_describes, @GUID_RelationType_isWrittenIn) AS func_Describing_LocalizedDescription_1
WHERE     (GUID_Ref = @GUID_Token)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Alternative_LocalizedNames_By_GUIDRef]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[proc_Alternative_LocalizedNames_By_GUIDRef] 
	-- Add the parameters for the stored procedure here
	@GUID_Type_LocalizedNames			uniqueidentifier,
	@GUID_Type_Language					uniqueidentifier,
	@GUID_RelationType_alternativeFor	uniqueidentifier,
	@GUID_RelationType_isWrittenIn		uniqueidentifier,
	@GUID_Related						uniqueidentifier
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT     GUID_Token, Name_Token, GUID_Type, GUID_Token_Language, Name_Token_Language, GUID_Type_Language, GUID_Ref, GUID_ItemType
FROM         dbo.func_Alternative_LocalizedNames(@GUID_Type_LocalizedNames, @GUID_Type_Language, @GUID_RelationType_alternativeFor, 
                      @GUID_RelationType_isWrittenIn) AS func_Alternative_LocalizedNames_1
WHERE     (GUID_Ref = @GUID_Related)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Alternative_LocalizedNames]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[dbg_Alternative_LocalizedNames] 
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @GUID_Type_LocalizedNames			uniqueidentifier;
	DECLARE @GUID_Type_Language					uniqueidentifier;
	DECLARE @GUID_RelationType_alternativeFor	uniqueidentifier;
	DECLARE @GUID_RelationType_isWrittenIn		uniqueidentifier;

	SET @GUID_Type_LocalizedNames			= dbo.func_Named_GUIDType(''Localized Names'');
	SET @GUID_Type_Language					= dbo.func_Named_GUIDType(''Language'');
	SET @GUID_RelationType_alternativeFor	= dbo.func_Named_GUIDRelationType(''alternative for'');
	SET @GUID_RelationType_isWrittenIn		= dbo.func_Named_GUIDRelationType(''is written in'');

	PRINT @GUID_Type_LocalizedNames;
	PRINT @GUID_Type_Language;
	PRINT @GUID_RelationType_alternativeFor;
	PRINT @GUID_RelationType_isWrittenIn;

    -- Insert statements for procedure here
	SELECT * FROM func_Alternative_LocalizedNames(
		@GUID_Type_LocalizedNames,
		@GUID_Type_Language,
		@GUID_RelationType_alternativeFor,
		@GUID_RelationType_isWrittenIn)
END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Describing_LocalizedDescription]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[dbg_Describing_LocalizedDescription] 
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @GUID_Attribute_Message				uniqueidentifier;
	DECLARE @GUID_Type_LocalizedDescription		uniqueidentifier;
	DECLARE @GUID_Type_Language					uniqueidentifier;
	DECLARE @GUID_RelationType_describes		uniqueidentifier;
	DECLARE @GUID_RelationType_isWrittenIn		uniqueidentifier;

	SET @GUID_Attribute_Message				= dbo.func_Named_GUIDAttribute(''Message'');
	SET @GUID_Type_LocalizedDescription		= dbo.func_Named_GUIDType(''Localized Description'');
	SET @GUID_Type_Language					= dbo.func_Named_GUIDType(''Language'');
	SET @GUID_RelationType_describes		= dbo.func_Named_GUIDRelationType(''describes'');
	SET @GUID_RelationType_isWrittenIn		= dbo.func_Named_GUIDRelationType(''is Written in'');

	PRINT @GUID_Attribute_Message;
	PRINT @GUID_Type_LocalizedDescription;
	PRINT @GUID_Type_Language;
	PRINT @GUID_RelationType_describes;
	PRINT @GUID_RelationType_isWrittenIn;

    -- Insert statements for procedure here
	SELECT * FROM func_Describing_LocalizedDescription(
		@GUID_Attribute_Message,
		@GUID_Type_LocalizedDescription,
		@GUID_Type_Language,
		@GUID_RelationType_describes,
		@GUID_RelationType_isWrittenIn)
		
END

'
END
GO
EXEC sp_addextendedproperty 
		@name = SchemaVersion, @value = '0.1.0.3';
GO
EXEC sp_addextendedproperty 
		@name = SemDB, @value = 'Yes';
GO
