CREATE DATABASE sem_db_tcp_mediaviewer_module
GO
use [sem_db_change]
use [sem_db_tcp_mediaviewer_module]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_Procedures

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Tables]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Triggers

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Tables]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Triggers]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Synonyms

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Triggers]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_Procedures

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Datetime]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Datetime] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Datetime]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Int]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Int] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Int]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Int]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Int] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Int]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Real]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Real] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Real]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Date]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Date] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Date]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Datetime]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_attribute_datetime] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_attribute_datetime]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_RelationType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_RelationType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_RelationType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Date]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Date] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Date]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_AttributeType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_AttributeType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_AttributeType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_VarcharMax]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_varcharMAX] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_varcharMAX]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_AttributeType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_AttributeType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_AttributeType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Real]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Real] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Real]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Time]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Time] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Time]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Varchar255]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Varchar255] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Varchar255]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_VARCHARMAX]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_VARCHARMAX] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_VARCHARMAX]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_ORType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_ORType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_ORType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Bit]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Bit] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Bit]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_RelationType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_RelationType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_RelationType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Time]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_attribute_time] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_attribute_time]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Varchar255]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_varchar255] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_varchar255]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Bit]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Bit] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Bit]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_Procedures

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Triggers

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Triggers

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Views

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Synonyms]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Triggers]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Synonyms

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Synonyms

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================



-- Author:		<Author,,Name>



-- Create date: <Create Date,,>



-- Description:	<Description,,>



-- =============================================



CREATE PROCEDURE [dbo].[proc_TSQL_Views]



	-- Add the parameters for the stored procedure here



	



AS



BEGIN



	-- SET NOCOUNT ON added to prevent extra result sets from



	-- interfering with SELECT statements.



	SET NOCOUNT ON;







    -- Insert statements for procedure here



	SELECT * FROM sys.views ORDER BY name



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Views]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Views]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.views ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Tables

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Tables

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Tables

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Tables

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Synonyms]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Synonyms

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.synonyms ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================



-- Author:		<Author,,Name>



-- Create date: <Create Date,,>



-- Description:	<Description,,>



-- =============================================



CREATE PROCEDURE [dbo].[proc_TSQL_Procedures]



	-- Add the parameters for the stored procedure here







AS



BEGIN



	-- SET NOCOUNT ON added to prevent extra result sets from



	-- interfering with SELECT statements.



	SET NOCOUNT ON;







    -- Insert statements for procedure here



	SELECT * FROM sys.procedures ORDER By name



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Functions]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Functions] 

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.ROUTINES WHERE Routine_Type=''FUNCTION'' ORDER By ROUTINE_NAME

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Parameters]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Parameters] 

	-- Add the parameters for the stored procedure here

	@Name_DBItem		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM INFORMATION_SCHEMA.PARAMETERS WHERE specific_Name=@Name_DBItem ORDER by PARAMETER_NAME;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Procedures]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Procedures]

	-- Add the parameters for the stored procedure here



AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.procedures ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Tables]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_Tables]

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.tables ORDER By name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_ObjectDefinition]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_TSQL_ObjectDefinition]

	-- Add the parameters for the stored procedure here

	@Name_Object		varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

    execute sp_helptext @Name_object

	--SELECT OBJECT_DEFINITION 

	--	(OBJECT_ID(@Name_Object)) AS ObjectDefinition

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_TSQL_Triggers]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_TSQL_Triggers

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM sys.triggers ORDER BY name

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Media_Item]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Media_Item] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Media_Item		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Media_Item, Name_Token AS Name_Media_Item, GUID_Type AS GUID_Type_Media_Item

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Media_Item)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_user]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_user] 

(	

	-- Add the parameters for the function here

	@GUID_Type_user		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_user, Name_Token AS Name_user, GUID_Type AS GUID_Type_user

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_user)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_MediaViewer_Module]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_MediaViewer_Module]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''MediaViewer-Module'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Month]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Month] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Month		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Month, Name_Token AS Name_Month, GUID_Type AS GUID_Type_Month

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Month)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_belonging_Done]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_belonging_Done]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''belonging Done'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Master_Password]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Master_Password]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Master-Password'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_File]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_File] 

(	

	-- Add the parameters for the function here

	@GUID_Type_File		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_File, Name_Token AS Name_File, GUID_Type AS GUID_Type_File

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_File)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Named_GUIDType]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date, ,>

-- Description:	<Description, ,>

-- =============================================

CREATE FUNCTION [dbo].[func_Named_GUIDType]

(

	-- Add the parameters for the function here

	@Name_Type		varchar(255)

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_Type		uniqueidentifier



	SET @GUID_Type = (SELECT     GUID_Type

		FROM         semtbl_Type

		WHERE     (Name_Type = @Name_Type));

	RETURN @GUID_Type;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Haustier]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Haustier]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Haustier'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Image_Objects__No_Objects_]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Image_Objects__No_Objects_]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Image-Objects (No Objects)'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_mp3_File]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_mp3_File]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''mp3-File'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_user]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_user] 

(	

	-- Add the parameters for the function here

	@GUID_Type_user		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_user, Name_Token AS Name_user, GUID_Type AS GUID_Type_user

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_user)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Bauwerke]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Bauwerke] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Bauwerke		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Bauwerke, Name_Token AS Name_Bauwerke, GUID_Type AS GUID_Type_Bauwerke

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Bauwerke)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_described_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_described_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is described by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_MediaViewer_Module]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_MediaViewer_Module] 

(	

	-- Add the parameters for the function here

	@GUID_Type_MediaViewer_Module		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_MediaViewer_Module, Name_Token AS Name_MediaViewer_Module, GUID_Type AS GUID_Type_MediaViewer_Module

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_MediaViewer_Module)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Module]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Module] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Module		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Module, Name_Token AS Name_Module, GUID_Type AS GUID_Type_Module

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Module)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Module]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Module]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Module'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_File]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_File]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''File'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Media]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Media] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Media		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Media, Name_Token AS Name_Media, GUID_Type AS GUID_Type_Media

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Media)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_of_Type]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_of_Type]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is of Type'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Titel]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Titel]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Titel'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Language]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Language'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Named_GUIDRelationType]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date, ,>

-- Description:	<Description, ,>

-- =============================================

CREATE FUNCTION [dbo].[func_Named_GUIDRelationType]

(

	-- Add the parameters for the function here

	@Name_RelationType		varchar(255)

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType		uniqueidentifier



	SET @GUID_RelationType = (SELECT     GUID_RelationType

		FROM         semtbl_RelationType

		WHERE     (Name_RelationType = @Name_RelationType));

	RETURN @GUID_RelationType;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semfunc_ObjectReference]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION [dbo].[semfunc_ObjectReference]

(	

	-- Add the parameters for the function here

	

)

RETURNS @tmptbl_Token_Or TABLE 

(

	GUID_ObjectReference		uniqueidentifier,

	Name_Token					varchar(255),

	GUID_Ref					uniqueidentifier,

	GUID_ItemType				uniqueidentifier

)

AS

BEGIN

	DECLARE @GUID_OR_Type_Attribute uniqueidentifier;

	DECLARE @GUID_OR_Type_AttributeType uniqueidentifier;

	DECLARE @GUID_OR_Type_RelationType uniqueidentifier;

	DECLARE @GUID_OR_Type_Token uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Bit uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Date uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Datetime uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Int uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Real uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_Time uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_VARCHAR255 uniqueidentifier;

	DECLARE @GUID_OR_Type_Token_Attribute_VARCHARMax uniqueidentifier;

	DECLARE @GUID_OR_Token_Token	uniqueidentifier;

	DECLARE @GUID_OR_Type			uniqueidentifier;

	DECLARE @GUID_OR_Type_Type_Attribute	uniqueidentifier;

	DECLARE @GUID_OR_Type_Type			uniqueidentifier;



	DECLARE @GUID_ObjectReference	uniqueidentifier;

	DECLARE @Name_Token				varchar(255);

	DECLARE @GUID_Ref				uniqueidentifier;

	DECLARE @GUID_ItemType			uniqueidentifier;

	

	SET @GUID_OR_Type_Attribute = (SELECT     GUID_ObjectReferenceType		

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Attribute''));

	SET @GUID_OR_Type_AttributeType = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''AttributeType''));

	SET @GUID_OR_Type_RelationType = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''RelationType''));

	SET @GUID_OR_Type_Token = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token''));

	SET @GUID_OR_Type_Token_Attribute_Bit = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Bit''));

	SET @GUID_OR_Type_Token_Attribute_Date = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Date''));

	SET @GUID_OR_Type_Token_Attribute_Datetime = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Datetime''));

	SET @GUID_OR_Type_Token_Attribute_Int = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Int''));

	SET @GUID_OR_Type_Token_Attribute_Real = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Real''));

	SET @GUID_OR_Type_Token_Attribute_Time = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Time''));

	SET @GUID_OR_Type_Token_Attribute_VARCHAR255 = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-Varchar255''));

	SET @GUID_OR_Type_Token_Attribute_VARCHARMAX = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Attribute-VarcharMax''));

	SET @GUID_OR_Token_Token = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Token-Token''));

	SET @GUID_OR_Type = (SELECT     GUID_ObjectReferenceType

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Type''));

	SET @GUID_OR_Type_Type_Attribute = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Type-Attribute''));

	SET @GUID_OR_Type_Type = (SELECT     GUID_ObjectReferenceType 

		FROM         semtbl_ORType

		WHERE     (Name_ObjectReferenceType = ''Type-Type''));



	-- Attribute

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_Attribute.GUID_ObjectReference, 

				semtbl_Attribute.GUID_Attribute, 

				semtbl_Attribute.Name_Attribute

			FROM         semtbl_OR_Attribute INNER JOIN

								  semtbl_Attribute ON semtbl_OR_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute;

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Attribute)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Attribute-Type

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_AttributeType.GUID_ObjectReference, 

				semtbl_AttributeType.GUID_AttributeType, 

				semtbl_AttributeType.Name_AttributeType

			FROM         semtbl_OR_AttributeType INNER JOIN

                      semtbl_AttributeType ON semtbl_OR_AttributeType.GUID_AttributeType = semtbl_AttributeType.GUID_AttributeType

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Attribute-Type: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_AttributeType)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- RelationType

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_RelationType.GUID_ObjectReference, 

				semtbl_RelationType.GUID_RelationType, 

				semtbl_RelationType.Name_RelationType

			FROM         semtbl_OR_RelationType INNER JOIN

                      semtbl_RelationType ON semtbl_OR_RelationType.GUID_RelationType = semtbl_RelationType.GUID_RelationType

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''RelationType: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_RelationType)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- Token

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_Token.GUID_ObjectReference, 

				semtbl_Token.GUID_Token, 

				semtbl_Token.Name_Token + ''\'' + semtbl_Type.Name_Type AS Name_Token_With_Type

			FROM         semtbl_OR_Token INNER JOIN

								  semtbl_Token ON semtbl_OR_Token.GUID_Token = semtbl_Token.GUID_Token INNER JOIN

								  semtbl_Type ON semtbl_Token.GUID_Type = semtbl_Type.GUID_Type

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- Token-Attribute-Bit

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_Token_Attribute_Bit.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

				FROM         semtbl_Token INNER JOIN

									  semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

									  semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

									  semtbl_OR_Token_Attribute_Bit ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Bit.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Bit)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Date

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Date.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Date ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Date.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Date)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Datetime

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT  semtbl_OR_Token_Attribute_Datetime.GUID_ObjectReference, 

				semtbl_Token_Attribute.GUID_TokenAttribute, 

                semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

				FROM         semtbl_Token INNER JOIN

									  semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

									  semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

									  semtbl_OR_Token_Attribute_Datetime ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Datetime.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Datetime)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Int

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Int.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Int ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Int.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Int)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Real

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Real.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Real ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Real.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Real)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Time

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Time.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Time ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Time.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_Time)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-Varchar255

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_Varchar255.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_Varchar255 ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_Varchar255.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_VARCHAR255)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Attribute-VarcharMAX

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Attribute_VARCHARMAX.GUID_ObjectReference, semtbl_Token_Attribute.GUID_TokenAttribute, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Attribute.Name_Attribute AS Name_Ref

FROM         semtbl_Token INNER JOIN

                      semtbl_Token_Attribute ON semtbl_Token.GUID_Token = semtbl_Token_Attribute.GUID_Token INNER JOIN

                      semtbl_Attribute ON semtbl_Token_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute INNER JOIN

                      semtbl_OR_Token_Attribute_VARCHARMAX ON semtbl_Token_Attribute.GUID_TokenAttribute = semtbl_OR_Token_Attribute_VARCHARMAX.GUID_TokenAttribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type_Token_Attribute_VARCHARMax)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	

	-- Token-Token

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Token_Token.GUID_ObjectReference, 

                      semtbl_Token.Name_Token + ''\'' + semtbl_Type.Name_Type + ''/'' + semtbl_RelationType.Name_RelationType + ''/'' + semtbl_Token_1.Name_Token + ''\'' + semtbl_Type_1.Name_Type

                       AS Name_Ref

			FROM         semtbl_Token AS semtbl_Token_1 INNER JOIN

                      semtbl_Token INNER JOIN

                      semtbl_RelationType INNER JOIN

                      semtbl_OR_Token_Token ON semtbl_RelationType.GUID_RelationType = semtbl_OR_Token_Token.GUID_RelationType ON 

                      semtbl_Token.GUID_Token = semtbl_OR_Token_Token.GUID_Token_Left ON semtbl_Token_1.GUID_Token = semtbl_OR_Token_Token.GUID_Token_Right INNER JOIN

                      semtbl_Type ON semtbl_Token.GUID_Type = semtbl_Type.GUID_Type INNER JOIN

                      semtbl_Type AS semtbl_Type_1 ON semtbl_Token_1.GUID_Type = semtbl_Type_1.GUID_Type

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Token-Token: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or (GUID_ObjectReference,Name_Token,GUID_ItemType)VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_OR_Token_Token)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	-- Type

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Type.GUID_ObjectReference, semtbl_Type.GUID_Type, semtbl_Type.Name_Type

FROM         semtbl_OR_Type INNER JOIN

                      semtbl_Type ON semtbl_OR_Type.GUID_Type = semtbl_Type.GUID_Type

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@GUID_Ref,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Type: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_Ref,

			@GUID_OR_Type)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@GUID_Ref,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- Type-Attribute

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT     semtbl_OR_Type_Attribute.GUID_ObjectReference, semtbl_Type.Name_Type + ''\[Name_Attribute]'' AS Name_Ref

FROM         semtbl_OR_Type_Attribute INNER JOIN

                      semtbl_Type ON semtbl_OR_Type_Attribute.GUID_Type = semtbl_Type.GUID_Type INNER JOIN

                      semtbl_Attribute ON semtbl_OR_Type_Attribute.GUID_Attribute = semtbl_Attribute.GUID_Attribute

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Type-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or (GUID_ObjectReference,Name_Token,GUID_ItemType)VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_OR_Type_Type_Attribute)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;



	-- Type-Type

	DECLARE cur_ObjectReference CURSOR FOR

		SELECT   semtbl_OR_Type_Type.GUID_ObjectReference, 

                 semtbl_Type.Name_Type + ''/'' + semtbl_RelationType.Name_RelationType + semtbl_Type_1.Name_Type AS Name_Ref

			FROM         semtbl_Type INNER JOIN

                      semtbl_RelationType INNER JOIN

                      semtbl_OR_Type_Type ON semtbl_RelationType.GUID_RelationType = semtbl_OR_Type_Type.GUID_RelationType INNER JOIN

                      semtbl_Type AS semtbl_Type_1 ON semtbl_OR_Type_Type.GUID_Type_Right = semtbl_Type_1.GUID_Type ON 

                      semtbl_Type.GUID_Type = semtbl_OR_Type_Type.GUID_Type_Left

	OPEN cur_ObjectReference;

	FETCH NEXT FROM cur_ObjectReference INTO

		@GUID_ObjectReference,

		@Name_Token;

	WHILE @@FETCH_STATUS=0

	BEGIN

		SET @Name_Token = ''Type-Attribute: '' + @Name_Token;

		

		INSERT INTO @tmptbl_Token_Or (GUID_ObjectReference,Name_Token,GUID_ItemType)VALUES(

			@GUID_ObjectReference,

			@Name_Token,

			@GUID_OR_Type_Type)

			

		FETCH NEXT FROM cur_ObjectReference INTO

			@GUID_ObjectReference,

			@Name_Token;

	END

	CLOSE cur_ObjectReference;

	DEALLOCATE cur_ObjectReference;

	RETURN

END




'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Year]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Year] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Year		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Year, Name_Token AS Name_Year, GUID_Type AS GUID_Type_Year

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Year)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Search_Template]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Search_Template] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Search_Template		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Search_Template, Name_Token AS Name_Search_Template, GUID_Type AS GUID_Type_Search_Template

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Search_Template)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Logentry]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Logentry] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Logentry		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Logentry, Name_Token AS Name_Logentry, GUID_Type AS GUID_Type_Logentry

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Logentry)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Language] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Language		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Language, Name_Token AS Name_Language, GUID_Type AS GUID_Type_Language

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Language)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Tierarten]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Tierarten]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Tierarten'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Images__Graphic_]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Images__Graphic_] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Images__Graphic_		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Images__Graphic_, Name_Token AS Name_Images__Graphic_, GUID_Type AS GUID_Type_Images__Graphic_

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Images__Graphic_)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Band]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Band]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Band'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Message]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Message]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Message'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Genre]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Genre]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Genre'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Search_Template]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Search_Template]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Search-Template'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_contact]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_contact]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''contact'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Day]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Day] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Day		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Day, Name_Token AS Name_Day, GUID_Type AS GUID_Type_Day

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Day)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Bauwerke]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Bauwerke]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Bauwerke'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_belonging_Done]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_belonging_Done]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''belonging Done'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Language]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Language'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Band]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Band] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Band		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Band, Name_Token AS Name_Band, GUID_Type AS GUID_Type_Band

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Band)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Image_Objects]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Image_Objects]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Image-Objects'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Media_Position]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Media_Position]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Media-Position'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_PDF_Documents]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'

CREATE FUNCTION [dbo].[dbg_Type_PDF_Documents]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''PDF-Documents'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Filetypes]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Filetypes]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Filetypes'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Blob]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Blob]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Blob'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Media_Item_Range]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Media_Item_Range]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Media-Item Range'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_used_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_used_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is used by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Day]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Day]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Day'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_ID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_ID]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''ID'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Logentry]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Logentry] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Logentry		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Logentry, Name_Token AS Name_Logentry, GUID_Type AS GUID_Type_Logentry

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Logentry)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Haustier]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Haustier] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Haustier		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Haustier, Name_Token AS Name_Haustier, GUID_Type AS GUID_Type_Haustier

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Haustier)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_user]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_user]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''user'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_comment]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_comment]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''comment'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_has]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_has]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''has'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Partner]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Partner]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Partner'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Images_Of_Partner]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_Images_Of_Partner

	-- Add the parameters for the stored procedure here

	 @GUID_Type_Partner				uniqueidentifier

	,@GUID_RelationType_is			uniqueidentifier

	,@GUID_RelationType_locatedIn	uniqueidentifier

	,@GUID_Partner					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     ImageObject_To_Images.GUID_Token_Right AS GUID_Item

FROM         semtbl_Token AS Partner INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_Partner ON Partner.GUID_Token = ImageObject_To_Partner.GUID_Token_Right INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_Images ON ImageObject_To_Partner.GUID_Token_Left = ImageObject_To_Images.GUID_Token_Left

WHERE     (Partner.GUID_Type = @GUID_Type_Partner) AND (Partner.GUID_Token = @GUID_Partner) AND 

                      (ImageObject_To_Partner.GUID_RelationType = @GUID_RelationType_is) AND (ImageObject_To_Images.GUID_RelationType = @GUID_RelationType_locatedIn)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_DateTimeStamp]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_DateTimestamp]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''DateTimestamp'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_user]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_user]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''user'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_finished_with]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_finished_with]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''finished with'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_Standard]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_Standard]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''Standard'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_started_with]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_started_with]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''started with'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Language]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Language'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_offers]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_offers]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''offers'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Tierarten]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Tierarten] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Tierarten		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Tierarten, Name_Token AS Name_Tierarten, GUID_Type AS GUID_Type_Tierarten

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Tierarten)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Media]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Media] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Media		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Media, Name_Token AS Name_Media, GUID_Type AS GUID_Type_Media

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Media)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_db_postfix]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_db_postfix]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''db_postfix'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_from]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_from]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''from'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_offered_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_offered_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''offered by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_File]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_File] 

(	

	-- Add the parameters for the function here

	@GUID_Type_File		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_File, Name_Token AS Name_File, GUID_Type AS GUID_Type_File

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_File)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_located_in]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_located_in]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''located in'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Ort]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Ort]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Ort'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Pflanzenarten]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Pflanzenarten] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Pflanzenarten		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Pflanzenarten, Name_Token AS Name_Pflanzenarten, GUID_Type AS GUID_Type_Pflanzenarten

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Pflanzenarten)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Partner]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Partner] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Partner		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Partner, Name_Token AS Name_Partner, GUID_Type AS GUID_Type_Partner

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Partner)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Media_Item_Bookmark]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Media_Item_Bookmark] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Media_Item_Bookmark		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Media_Item_Bookmark, Name_Token AS Name_Media_Item_Bookmark, GUID_Type AS GUID_Type_Media_Item_Bookmark

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Media_Item_Bookmark)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Logentry]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Logentry]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Logentry'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Images__Graphic_]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Images__Graphic_]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Images (Graphic)'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Year]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Year]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Year'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Image_Objects__No_Objects_]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Image_Objects__No_Objects_] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Image_Objects__No_Objects_		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Image_Objects__No_Objects_, Name_Token AS Name_Image_Objects__No_Objects_, GUID_Type AS GUID_Type_Image_Objects__No_Objects_

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Image_Objects__No_Objects_)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Language] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Language		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Language, Name_Token AS Name_Language, GUID_Type AS GUID_Type_Language

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Language)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Pflanzenarten]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Pflanzenarten]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Pflanzenarten'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_belonging_Source]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_belonging_Source]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''belonging Source'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Media_Item]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Media_Item]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Media-Item'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_belongs_to]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_belongs_to]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''belongs to'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_described_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_described_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is described by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_Artist]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_Artist]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''Artist'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Wichtige_Ereignisse]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Wichtige_Ereignisse] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Wichtige_Ereignisse		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Wichtige_Ereignisse, Name_Token AS Name_Wichtige_Ereignisse, GUID_Type AS GUID_Type_Wichtige_Ereignisse

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Wichtige_Ereignisse)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Wichtige_Ereignisse]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Wichtige_Ereignisse]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Wichtige Ereignisse'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_mp3_File]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_mp3_File] 

(	

	-- Add the parameters for the function here

	@GUID_Type_mp3_File		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_mp3_File, Name_Token AS Name_mp3_File, GUID_Type AS GUID_Type_mp3_File

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_mp3_File)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_taking]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_taking]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''taking'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_DateTimeStamp]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_DateTimestamp]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''DateTimestamp'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Album]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Album] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Album		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Album, Name_Token AS Name_Album, GUID_Type AS GUID_Type_Album

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Album)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Filetypes]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Filetypes] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Filetypes		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Filetypes, Name_Token AS Name_Filetypes, GUID_Type AS GUID_Type_Filetypes

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Filetypes)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_was_created_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_was_created_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''was created by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_File]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_File]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''File'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Ort]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Ort] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Ort		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Ort, Name_Token AS Name_Ort, GUID_Type AS GUID_Type_Ort

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Ort)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Media_Item_Bookmark]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Media_Item_Bookmark]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Media-Item Bookmark'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Media]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Media]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Media'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Month]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Month]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Month'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_L_nge__Minuten_]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_L_nge__Minuten_]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Länge (Minuten)'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_was_created_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_was_created_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''was created by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Album]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Album]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Album'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Media_Item_Range]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Media_Item_Range] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Media_Item_Range		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Media_Item_Range, Name_Token AS Name_Media_Item_Range, GUID_Type AS GUID_Type_Media_Item_Range

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Media_Item_Range)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_Composer]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_Composer]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''Composer'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[is_ObjectReferenceType_Attribute]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date, ,>

-- Description:	<Description, ,>

-- =============================================

CREATE FUNCTION [dbo].[is_ObjectReferenceType_Attribute]

(

	-- Add the parameters for the function here

	@strGUID_ObjectReferenceType	uniqueidentifier

)

RETURNS bit

AS

BEGIN

	-- Declare the return variable here

	DECLARE @strGUID_Token_ObjectReferenceType	uniqueidentifier;

	DECLARE @bitResult							bit;



	SET @bitResult = 0;



	-- Add the T-SQL statements to compute the return value here

	

	SET @strGUID_Token_ObjectReferenceType=(SELECT GUID_Token FROM semtbl_Token WHERE GUID_Type=dbo.func_TypeGUID_ObjectReferenceType() AND Name_Token=''Attribute'');



	If @strGUID_Token_ObjectReferenceType=@strGUID_ObjectReferenceType

		SET @bitResult = 1;

	-- Return the result of the function

	RETURN @bitResult;



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_ID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_ID]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''ID'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Language]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Language] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Language		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Language, Name_Token AS Name_Language, GUID_Type AS GUID_Type_Language

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Language)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Logentry]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Logentry]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Logentry'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_taking_at]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_taking_at]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''taking at'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Media]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Media]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Media'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Image_Objects]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Image_Objects] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Image_Objects		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Image_Objects, Name_Token AS Name_Image_Objects, GUID_Type AS GUID_Type_Image_Objects

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Image_Objects)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_LCID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_LCID]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''LCID'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_started_with]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_started_with]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''started with'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_described_by]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_described_by]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is described by'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Message]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Message]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Message'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_PDF_Documents]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'

CREATE FUNCTION [dbo].[func_Token_PDF_Documents] 

(	

	-- Add the parameters for the function here

	@GUID_Type_PDF_Documents		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_PDF_Documents, Name_Token AS Name_PDF_Documents, GUID_Type AS GUID_Type_PDF_Documents

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_PDF_Documents)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Genre]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Genre] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Genre		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Genre, Name_Token AS Name_Genre, GUID_Type AS GUID_Type_Genre

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Genre)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Short]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Short]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Short'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Named_GUIDAttribute]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date, ,>

-- Description:	<Description, ,>

-- =============================================

CREATE FUNCTION [dbo].[func_Named_GUIDAttribute]

(

	-- Add the parameters for the function here

	@Name_Attribute		varchar(255)

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_Attribute		uniqueidentifier



	SET @GUID_Attribute = (SELECT     GUID_Attribute

		FROM         semtbl_Attribute

		WHERE     (Name_Attribute = @Name_Attribute));

	RETURN @GUID_Attribute;

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_finished_with]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_finished_with]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''finished with'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_partner_of]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_partner_of]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is partner of'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Codepage]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Codepage]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Codepage'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_Disc]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_Disc]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''Disc'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_has]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_has]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''has'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Images_And_Files]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE dbg_Images_And_Files

	-- Add the parameters for the stored procedure here

	 

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;





	DECLARE @GUID_Type_Image					uniqueidentifier

	DECLARE @GUID_Type_File						uniqueidentifier

	DECLARE @GUID_RelationType_belongingSource	uniqueidentifier

	

	SET @GUID_Type_Image					= dbo.dbg_Type_Images__Graphic_()

	SET @GUID_Type_File						= dbo.dbg_Type_File()

	SET @GUID_RelationType_belongingSource	= dbo.dbg_RelationType_belonging_Source()

	

	PRINT @GUID_Type_Image					

	PRINT @GUID_Type_File					

	PRINT @GUID_RelationType_belongingSource	

    -- Insert statements for procedure here

	SELECT     func_Token_Images__Graphic__1.GUID_Images__Graphic_, func_Token_Images__Graphic__1.Name_Images__Graphic_, 

                      func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, func_Token_File_1.GUID_File, func_Token_File_1.Name_File, 

                      func_Token_File_1.GUID_Type_File

		FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_Image) AS func_Token_Images__Graphic__1 INNER JOIN

							  semtbl_Token_Token AS Image_To_File ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = Image_To_File.GUID_Token_Left INNER JOIN

							  dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON Image_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

		WHERE     (Image_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Images_Same_TakeDate]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE dbg_Images_Same_TakeDate

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Attribute_taking	uniqueidentifier

	DECLARE @GUID_Type_ImageGraphic	uniqueidentifier

	

	SET @GUID_Attribute_taking = dbo.dbg_AttributeType_taking()

	SET @GUID_Type_ImageGraphic =  dbo.dbg_Type_Images__Graphic_()

	

	PRINT @GUID_Attribute_taking

	PRINT @GUID_Type_ImageGraphic

	

    -- Insert statements for procedure here

    SELECT     func_Token_Images__Graphic__1.GUID_Images__Graphic_,func_Token_Images__Graphic__1.Name_Images__Graphic_, func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, ImageGraphic__taking_Val.Val

FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 INNER JOIN

                      semtbl_Token_Attribute AS ImageGraphic__taking ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = ImageGraphic__taking.GUID_Token INNER JOIN

                      semtbl_Token_attribute_datetime AS ImageGraphic__taking_Val ON 

                      ImageGraphic__taking.GUID_TokenAttribute = ImageGraphic__taking_Val.GUID_TokenAttribute

                      JOIN 

	(SELECT     ImageGraphic__taking_Val.val, COUNT(*) AS Count

FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 INNER JOIN

                      semtbl_Token_Attribute AS ImageGraphic__taking ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = ImageGraphic__taking.GUID_Token INNER JOIN

                      semtbl_Token_attribute_datetime AS ImageGraphic__taking_Val ON 

                      ImageGraphic__taking.GUID_TokenAttribute = ImageGraphic__taking_Val.GUID_TokenAttribute

WHERE     (ImageGraphic__taking.GUID_Attribute = @GUID_Attribute_taking)

GROUP BY ImageGraphic__taking_Val.val

HAVING      (COUNT(*) > 1)) Dates ON ImageGraphic__taking_Val.Val = Dates.Val

WHERE     (ImageGraphic__taking.GUID_Attribute = @GUID_Attribute_taking)

ORDER BY ImageGraphic__taking_Val.Val

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Image_Of_Or]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Image_Of_Or] 

	-- Add the parameters for the stored procedure here

	@GUID_Type_ImageGraphic				uniqueidentifier,

	@GUID_Type_File						uniqueidentifier,

	@GUID_RelationType_belongsTo		uniqueidentifier,

	@GUID_RelationType_belongingSource	uniqueidentifier,

	@GUID_ObjectReference				uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     ImageGraphic_To_ObjectReference.OrderID, func_Token_Images__Graphic__1.GUID_Images__Graphic_, 

                      func_Token_Images__Graphic__1.Name_Images__Graphic_, func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, 

                      ImageGraphic_To_File.GUID_RelationType, ImageGraphic_To_ObjectReference.GUID_ObjectReference, func_Token_File_1.GUID_File, func_Token_File_1.Name_File, 

                      func_Token_File_1.GUID_Type_File

FROM         semtbl_Token_OR AS ImageGraphic_To_ObjectReference INNER JOIN

                      dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 ON 

                      ImageGraphic_To_ObjectReference.GUID_Token_Left = func_Token_Images__Graphic__1.GUID_Images__Graphic_ INNER JOIN

                      semtbl_Token_Token AS ImageGraphic_To_File ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = ImageGraphic_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON ImageGraphic_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

WHERE     (ImageGraphic_To_ObjectReference.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (ImageGraphic_To_ObjectReference.GUID_ObjectReference = @GUID_ObjectReference) AND 

                      (ImageGraphic_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

ORDER BY ImageGraphic_To_ObjectReference.OrderID

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Days]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION func_Days 

(	

	-- Add the parameters for the function here

	 @GUID_Type_Day		uniqueidentifier

	,@GUID_Attribute_ID	uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     func_Token_Day_1.GUID_Day, Day__ID_Val.GUID_TokenAttribute AS GUID_TokenAttribute_Day, Day__ID_Val.val AS Day

	FROM         dbo.func_Token_Day(@GUID_Type_Day) AS func_Token_Day_1 INNER JOIN

						  semtbl_Token_Attribute AS Day__ID ON func_Token_Day_1.GUID_Day = Day__ID.GUID_Token INNER JOIN

						  semtbl_Token_Attribute_Int AS Day__ID_Val ON Day__ID.GUID_TokenAttribute = Day__ID_Val.GUID_TokenAttribute

	WHERE     (Day__ID.GUID_Attribute = @GUID_Attribute_ID)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_MediaItems_And_Files]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE dbg_MediaItems_And_Files

	-- Add the parameters for the stored procedure here

	 

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Type_MediaItem				uniqueidentifier

	DECLARE @GUID_Type_File						uniqueidentifier

	DECLARE @GUID_RelationType_belongingSource	uniqueidentifier

	

	SET @GUID_Type_MediaItem				= dbo.dbg_Type_Media_Item()

	SET @GUID_Type_File						= dbo.dbg_Type_File()

	SET @GUID_RelationType_belongingSource	= dbo.dbg_RelationType_belonging_Source()

	

	PRINT @GUID_Type_MediaItem				

	PRINT @GUID_Type_File					

	PRINT @GUID_RelationType_belongingSource	

    -- Insert statements for procedure here

	SELECT     func_Token_Media_Item_1.GUID_Media_Item, func_Token_Media_Item_1.Name_Media_Item, func_Token_Media_Item_1.GUID_Type_Media_Item, 

                      func_Token_File_1.GUID_File, func_Token_File_1.Name_File, func_Token_File_1.GUID_Type_File

FROM         dbo.func_Token_Media_Item(@GUID_Type_MediaItem) AS func_Token_Media_Item_1 INNER JOIN

                      semtbl_Token_Token AS MediaItem_To_File ON func_Token_Media_Item_1.GUID_Media_Item = MediaItem_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON MediaItem_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

WHERE     (MediaItem_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)	

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_MediaItem_Of_Or]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'



-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_MediaItem_Of_Or] 

	-- Add the parameters for the stored procedure here

	

	@GUID_ObjectReference				uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Type_MediaItem				uniqueidentifier

	DECLARE @GUID_Type_File						uniqueidentifier

	DECLARE @GUID_Type_Bookmark					uniqueidentifier

	DECLARE @GUID_RelationType_belongsTo		uniqueidentifier

	DECLARE @GUID_RelationType_belongingSource	uniqueidentifier

	

	SET @GUID_Type_MediaItem				= dbo.dbg_Type_Media_Item()

	SET @GUID_Type_File						= dbo.dbg_Type_File()

	SET @GUID_RelationType_belongsTo		= dbo.dbg_RelationType_belongs_to()

	SET @GUID_RelationType_belongingSource	= dbo.dbg_RelationType_belonging_Source()

	SET @GUID_Type_Bookmark					= dbo.dbg_Type_Media_Item_Bookmark()

	

	PRINT @GUID_Type_MediaItem				

	PRINT @GUID_RelationType_belongsTo		

	PRINT @GUID_RelationType_belongingSource	

	

	

    -- Insert statements for procedure here

	SELECT     MediaItem_To_ObjectReference.OrderID, func_Token_MediaItem_1.GUID_Media_Item, func_Token_MediaItem_1.Name_Media_Item, 

                      func_Token_MediaItem_1.GUID_Type_Media_Item, MediaItem_To_File.GUID_RelationType, MediaItem_To_ObjectReference.GUID_ObjectReference, 

                      func_Token_File_1.GUID_File, func_Token_File_1.Name_File, func_Token_File_1.GUID_Type_File, RAND(ABS(CONVERT(INT, CONVERT(binary(4), NEWID())))) AS Random, ISNULL(Count_Bookmarks,0) AS Count_Bookmarks

FROM         semtbl_Token_OR AS MediaItem_To_ObjectReference INNER JOIN

                      dbo.func_Token_Media_Item(@GUID_Type_MediaItem) AS func_Token_MediaItem_1 ON 

                      MediaItem_To_ObjectReference.GUID_Token_Left = func_Token_MediaItem_1.GUID_Media_Item INNER JOIN

                      semtbl_Token_Token AS MediaItem_To_File ON func_Token_MediaItem_1.GUID_Media_Item = MediaItem_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON MediaItem_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

                      LEFT OUTER JOIN (SELECT     Bookmark_To_MediaItem.GUID_Token_Right, COUNT(*) AS Count_Bookmarks

FROM         dbo.func_Token_Media_Item_Bookmark(@GUID_Type_Bookmark) AS func_Token_Media_Item_Bookmark_1 INNER JOIN

                      semtbl_Token_Token AS Bookmark_To_MediaItem ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = Bookmark_To_MediaItem.GUID_Token_Left

WHERE     (Bookmark_To_MediaItem.GUID_RelationType = @GUID_RelationType_belongsTo)

GROUP BY Bookmark_To_MediaItem.GUID_Token_Right) AS Bookmarks ON func_Token_MediaItem_1.GUID_Media_Item = Bookmarks.GUID_Token_Right

WHERE     (MediaItem_To_ObjectReference.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (MediaItem_To_ObjectReference.GUID_ObjectReference = @GUID_ObjectReference) AND 

                      (MediaItem_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

ORDER BY MediaItem_To_ObjectReference.OrderID, func_Token_MediaItem_1.Name_Media_Item

END




'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_PDF_Of_Or]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_PDF_Of_Or] 

	-- Add the parameters for the stored procedure here

	

	@GUID_ObjectReference				uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Type_PDF_Documents			uniqueidentifier;

	DECLARE @GUID_Type_File						uniqueidentifier

	DECLARE @GUID_RelationType_belongsTo		uniqueidentifier;

	DECLARE @GUID_RelationType_belongingSource	uniqueidentifier;

	

	SET @GUID_Type_PDF_Documents			= dbo.dbg_Type_PDF_Documents();

	SET @GUID_Type_File						= dbo.dbg_Type_File()

	SET @GUID_RelationType_belongsTo		= dbo.dbg_RelationType_belongs_to();

	SET @GUID_RelationType_belongingSource	= dbo.dbg_RelationType_belonging_Source();

	

	PRINT @GUID_Type_PDF_Documents;

	PRINT @GUID_Type_File

	PRINT @GUID_RelationType_belongsTo;

	PRINT @GUID_RelationType_belongingSource;

	

    -- Insert statements for procedure here

	SELECT     PDF_Documents_To_ObjectReference.OrderID, func_Token_PDF_Documents_1.GUID_PDF_Documents, func_Token_PDF_Documents_1.Name_PDF_Documents, 

                      func_Token_PDF_Documents_1.GUID_Type_PDF_Documents, PDF_Documents_To_File.GUID_RelationType, 

                      PDF_Documents_To_ObjectReference.GUID_ObjectReference, func_Token_File_1.GUID_File, func_Token_File_1.Name_File, 

                      func_Token_File_1.GUID_Type_File

FROM         semtbl_Token_OR AS PDF_Documents_To_ObjectReference INNER JOIN

                      dbo.func_Token_PDF_Documents(@GUID_Type_PDF_Documents) AS func_Token_PDF_Documents_1 ON 

                      PDF_Documents_To_ObjectReference.GUID_Token_Left = func_Token_PDF_Documents_1.GUID_PDF_Documents INNER JOIN

                      semtbl_Token_Token AS PDF_Documents_To_File ON 

                      func_Token_PDF_Documents_1.GUID_PDF_Documents = PDF_Documents_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON PDF_Documents_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

WHERE     (PDF_Documents_To_ObjectReference.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (PDF_Documents_To_ObjectReference.GUID_ObjectReference = @GUID_ObjectReference) AND 

                      (PDF_Documents_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

ORDER BY PDF_Documents_To_ObjectReference.OrderID

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Composer]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_Composer

	-- Add the parameters for the stored procedure here

	 @GUID_Type_Partner				uniqueidentifier

	,@GUID_RelationType_Composer	uniqueidentifier

	,@GUID_BaseConfig				uniqueidentifier

	,@Name_Composer					varchar(255)

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     func_Token_Partner_1.GUID_Partner, func_Token_Partner_1.Name_Partner, func_Token_Partner_1.GUID_Type_Partner

FROM         dbo.func_Token_Partner(@GUID_Type_Partner) AS func_Token_Partner_1 INNER JOIN

                      semtbl_Token_Token AS BaseConfig_To_Composer ON func_Token_Partner_1.GUID_Partner = BaseConfig_To_Composer.GUID_Token_Right

WHERE     (BaseConfig_To_Composer.GUID_Token_Left = @GUID_BaseConfig) AND (BaseConfig_To_Composer.GUID_RelationType = @GUID_RelationType_Composer) AND 

                      (func_Token_Partner_1.Name_Partner = @Name_Composer)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Years]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION func_Years 

(	

	-- Add the parameters for the function here

	 @GUID_Type_Year		uniqueidentifier

	,@GUID_Attribute_ID	uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     func_Token_Year_1.GUID_Year, Year__ID_Val.GUID_TokenAttribute AS GUID_TokenAttribute_Year, Year__ID_Val.val AS Year

	FROM         dbo.func_Token_Year(@GUID_Type_Year) AS func_Token_Year_1 INNER JOIN

						  semtbl_Token_Attribute AS Year__ID ON func_Token_Year_1.GUID_Year = Year__ID.GUID_Token INNER JOIN

						  semtbl_Token_Attribute_Int AS Year__ID_Val ON Year__ID.GUID_TokenAttribute = Year__ID_Val.GUID_TokenAttribute

	WHERE     (Year__ID.GUID_Attribute = @GUID_Attribute_ID)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_User_Of_Logentry]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION [dbo].[func_User_Of_Logentry]

(	

	-- Add the parameters for the function here

	 @GUID_Type_User					uniqueidentifier

	,@GUID_Type_Logentry				uniqueidentifier

	,@GUID_RelationType_wasCreatedBy	uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     func_Token_user_1.GUID_user, func_Token_user_1.Name_user, func_Token_user_1.GUID_Type_user, func_Token_Logentry_1.GUID_Logentry

FROM         dbo.func_Token_user(@GUID_Type_User) AS func_Token_user_1 INNER JOIN

                      semtbl_Token_Token AS Logentry_To_User ON func_Token_user_1.GUID_user = Logentry_To_User.GUID_Token_Right INNER JOIN

                      dbo.func_Token_Logentry(@GUID_Type_Logentry) AS func_Token_Logentry_1 ON 

                      Logentry_To_User.GUID_Token_Left = func_Token_Logentry_1.GUID_Logentry

WHERE     (Logentry_To_User.GUID_RelationType = @GUID_RelationType_wasCreatedBy)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Genre]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATe PROCEDURE proc_Genre

	-- Add the parameters for the stored procedure here

	 @GUID_Type_Genre		uniqueidentifier

	,@GUID_Attribute_ID		uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	



    -- Insert statements for procedure here

	SELECT     func_Token_Genre_1.GUID_Genre, func_Token_Genre_1.Name_Genre, func_Token_Genre_1.GUID_Type_Genre, 

                      Genre__ID_Val.GUID_TokenAttribute AS GUID_TokenAttribute_ID, Genre__ID_Val.val AS ID

FROM         dbo.func_Token_Genre(@GUID_Type_Genre) AS func_Token_Genre_1 INNER JOIN

                      semtbl_Token_Attribute AS Genre__ID ON func_Token_Genre_1.GUID_Genre = Genre__ID.GUID_Token INNER JOIN

                      semtbl_Token_Attribute_Int AS Genre__ID_Val ON Genre__ID.GUID_TokenAttribute = Genre__ID_Val.GUID_TokenAttribute

WHERE     (Genre__ID.GUID_Attribute = @GUID_Attribute_ID)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Images_Same_TakeDate]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_Images_Same_TakeDate

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_taking	uniqueidentifier

	,@GUID_Type_ImageGraphic	uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

    -- Insert statements for procedure here

    SELECT     func_Token_Images__Graphic__1.GUID_Images__Graphic_,func_Token_Images__Graphic__1.Name_Images__Graphic_, func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, ImageGraphic__taking_Val.Val

FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 INNER JOIN

                      semtbl_Token_Attribute AS ImageGraphic__taking ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = ImageGraphic__taking.GUID_Token INNER JOIN

                      semtbl_Token_attribute_datetime AS ImageGraphic__taking_Val ON 

                      ImageGraphic__taking.GUID_TokenAttribute = ImageGraphic__taking_Val.GUID_TokenAttribute

                      JOIN 

	(SELECT     ImageGraphic__taking_Val.val, COUNT(*) AS Count

FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 INNER JOIN

                      semtbl_Token_Attribute AS ImageGraphic__taking ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = ImageGraphic__taking.GUID_Token INNER JOIN

                      semtbl_Token_attribute_datetime AS ImageGraphic__taking_Val ON 

                      ImageGraphic__taking.GUID_TokenAttribute = ImageGraphic__taking_Val.GUID_TokenAttribute

WHERE     (ImageGraphic__taking.GUID_Attribute = @GUID_Attribute_taking)

GROUP BY ImageGraphic__taking_Val.val

HAVING      (COUNT(*) > 1)) Dates ON ImageGraphic__taking_Val.Val = Dates.Val

WHERE     (ImageGraphic__taking.GUID_Attribute = @GUID_Attribute_taking)

ORDER BY ImageGraphic__taking_Val.Val

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Images_Of_NamedRelated]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Images_Of_NamedRelated]

	-- Add the parameters for the stored procedure here

	 

	@GUID_Related						uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Type_ImageObjects				uniqueidentifier

	DECLARE @GUID_Type_File						uniqueidentifier

	DECLARE @GUID_Type_Image					uniqueidentifier

	DECLARE @GUID_RelationType_belongingSource	uniqueidentifier

	DECLARE @GUID_RelationType_locatedIn		uniqueidentifier

	DECLARE @GUID_RelationType_Is				uniqueidentifier

	

	SET @GUID_Type_ImageObjects				= dbo.dbg_Type_Image_Objects()

	SET @GUID_Type_File						= dbo.dbg_Type_File()

	SET @GUID_Type_Image					= dbo.dbg_Type_Images__Graphic_()

	SET @GUID_RelationType_belongingSource	= dbo.dbg_RelationType_belonging_Source()

	SET @GUID_RelationType_locatedIn		= dbo.dbg_RelationType_located_in()

	SET @GUID_RelationType_Is				= dbo.dbg_RelationType_is()

	

	PRINT @GUID_Type_ImageObjects			

	PRINT @GUID_Type_File					

	PRINT @GUID_Type_Image					

	PRINT @GUID_RelationType_belongingSource

	PRINT @GUID_RelationType_locatedIn		

	PRINT @GUID_RelationType_Is				

    -- Insert statements for procedure here

	SELECT     ImageObject_To_Image.OrderID, func_Token_Images__Graphic__1.GUID_Images__Graphic_, func_Token_Images__Graphic__1.Name_Images__Graphic_, 

                      func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, ImageObject_To_Image.GUID_RelationType, func_Token_File_1.GUID_File, 

                      func_Token_File_1.Name_File, func_Token_File_1.GUID_Type_File, ImageObject_To_Partner.GUID_Token_Right

FROM         semtbl_Token_Token AS ImageObject_To_Image INNER JOIN

                      dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 ON 

                      ImageObject_To_Image.GUID_Token_Left = func_Token_Image_Objects_1.GUID_Image_Objects INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_File ON func_Token_File_1.GUID_File = ImageObject_To_File.GUID_Token_Right INNER JOIN

                      dbo.func_Token_Images__Graphic_(@GUID_Type_Image) AS func_Token_Images__Graphic__1 ON 

                      ImageObject_To_File.GUID_Token_Left = func_Token_Images__Graphic__1.GUID_Images__Graphic_ ON 

                      ImageObject_To_Image.GUID_Token_Right = func_Token_Images__Graphic__1.GUID_Images__Graphic_ INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_Partner ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_To_Partner.GUID_Token_Left

WHERE     (ImageObject_To_File.GUID_RelationType = @GUID_RelationType_belongingSource) AND 

                      (ImageObject_To_Image.GUID_RelationType = @GUID_RelationType_locatedIn) AND (ImageObject_To_Partner.GUID_RelationType = @GUID_RelationType_Is) AND 

                      (ImageObject_To_Partner.GUID_Token_Right = @GUID_Related)

ORDER BY ImageObject_To_Image.OrderID, func_Token_Images__Graphic__1.Name_Images__Graphic_

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_ImageObjects_Of_Images]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_ImageObjects_Of_Images]

	-- Add the parameters for the stored procedure here

	 @GUID_Type_ImageObjects			uniqueidentifier

	,@GUID_Type_Partner					uniqueidentifier

	,@GUID_RelationType_locatedIn		uniqueidentifier

	,@GUID_RelationType_Is				uniqueidentifier

	,@GUID_RelationType_has				uniqueidentifier

	,@GUID_noPersons					uniqueidentifier

	,@GUID_Image						uniqueidentifier = null

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	IF @GUID_Image IS NULL

	BEGIN

		SELECT   Image_To_Objects.GUID_Token_Right

					,func_Token_Image_Objects_1.GUID_Image_Objects

					,func_Token_Image_Objects_1.Name_Image_Objects

					,func_Token_Image_Objects_1.GUID_Type_Image_Objects

					,func_Token_Partner_1.GUID_Partner

					,func_Token_Partner_1.Name_Partner

					,func_Token_Partner_1.GUID_Type_Partner

		FROM         dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 INNER JOIN

							  semtbl_Token_Token AS Image_To_Objects ON func_Token_Image_Objects_1.GUID_Image_Objects = Image_To_Objects.GUID_Token_Left INNER JOIN

							  semtbl_Token_Token AS ImageObject_to_Partner ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_to_Partner.GUID_Token_Left INNER JOIN

							  dbo.func_Token_Partner(@GUID_Type_Partner) AS func_Token_Partner_1 ON 

							  ImageObject_to_Partner.GUID_Token_Right = func_Token_Partner_1.GUID_Partner

		WHERE     (Image_To_Objects.GUID_RelationType = @GUID_RelationType_locatedIn) AND 

							  (ImageObject_to_Partner.GUID_RelationType = @GUID_RelationType_Is)

		                      

			UNION

			

		SELECT     semtbl_Token_Token.GUID_Token_Right, func_Token_Image_Objects_1.GUID_Image_Objects, func_Token_Image_Objects_1.Name_Image_Objects, 

							  func_Token_Image_Objects_1.GUID_Type_Image_Objects, ImageObject_To_NoObjects.GUID_Token_Right AS GUID_Partner, CAST(NULL AS VARCHAR(255)) AS Name_Partner, CAST(NULL AS Uniqueidentifier) AS GUID_Type_Partner

		FROM         semtbl_Token_Token INNER JOIN

							  dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 ON 

							  semtbl_Token_Token.GUID_Token_Left = func_Token_Image_Objects_1.GUID_Image_Objects INNER JOIN

							  semtbl_Token_Token AS ImageObject_To_NoObjects ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_To_NoObjects.GUID_Token_Left

		WHERE     (semtbl_Token_Token.GUID_RelationType = @GUID_RelationType_locatedIn) AND 

							  (ImageObject_To_NoObjects.GUID_Token_Right = @GUID_noPersons) AND (ImageObject_To_NoObjects.GUID_RelationType = @GUID_RelationType_has)

	END

	ELSE

	BEGIN

		SELECT   Image_To_Objects.GUID_Token_Right

					,func_Token_Image_Objects_1.GUID_Image_Objects

					,func_Token_Image_Objects_1.Name_Image_Objects

					,func_Token_Image_Objects_1.GUID_Type_Image_Objects

					,func_Token_Partner_1.GUID_Partner

					,func_Token_Partner_1.Name_Partner

					,func_Token_Partner_1.GUID_Type_Partner

		FROM         dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 INNER JOIN

							  semtbl_Token_Token AS Image_To_Objects ON func_Token_Image_Objects_1.GUID_Image_Objects = Image_To_Objects.GUID_Token_Left INNER JOIN

							  semtbl_Token_Token AS ImageObject_to_Partner ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_to_Partner.GUID_Token_Left INNER JOIN

							  dbo.func_Token_Partner(@GUID_Type_Partner) AS func_Token_Partner_1 ON 

							  ImageObject_to_Partner.GUID_Token_Right = func_Token_Partner_1.GUID_Partner

		WHERE     (Image_To_Objects.GUID_Token_Right = @GUID_Image) AND (Image_To_Objects.GUID_RelationType = @GUID_RelationType_locatedIn) AND 

							  (ImageObject_to_Partner.GUID_RelationType = @GUID_RelationType_Is)

		                      

			UNION

			

		SELECT     semtbl_Token_Token.GUID_Token_Right, func_Token_Image_Objects_1.GUID_Image_Objects, func_Token_Image_Objects_1.Name_Image_Objects, 

							  func_Token_Image_Objects_1.GUID_Type_Image_Objects, ImageObject_To_NoObjects.GUID_Token_Right AS GUID_Partner, CAST(NULL AS VARCHAR(255)) AS Name_Partner, CAST(NULL AS Uniqueidentifier) AS GUID_Type_Partner

		FROM         semtbl_Token_Token INNER JOIN

							  dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 ON 

							  semtbl_Token_Token.GUID_Token_Left = func_Token_Image_Objects_1.GUID_Image_Objects INNER JOIN

							  semtbl_Token_Token AS ImageObject_To_NoObjects ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_To_NoObjects.GUID_Token_Left

		WHERE     (semtbl_Token_Token.GUID_RelationType = @GUID_RelationType_locatedIn) AND (semtbl_Token_Token.GUID_Token_Right = @GUID_Image) AND 

							  (ImageObject_To_NoObjects.GUID_Token_Right = @GUID_noPersons) AND (ImageObject_To_NoObjects.GUID_RelationType = @GUID_RelationType_has)

	END	

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Images_And_Files]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_Images_And_Files

	-- Add the parameters for the stored procedure here

	 @GUID_Type_Image					uniqueidentifier

	,@GUID_Type_File					uniqueidentifier

	,@GUID_RelationType_belongingSource	uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     func_Token_Images__Graphic__1.GUID_Images__Graphic_, func_Token_Images__Graphic__1.Name_Images__Graphic_, 

                      func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, func_Token_File_1.GUID_File, func_Token_File_1.Name_File, 

                      func_Token_File_1.GUID_Type_File

		FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_Image) AS func_Token_Images__Graphic__1 INNER JOIN

							  semtbl_Token_Token AS Image_To_File ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = Image_To_File.GUID_Token_Left INNER JOIN

							  dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON Image_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

		WHERE     (Image_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_ImageObjects_Of_Images]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_ImageObjects_Of_Images]

	-- Add the parameters for the stored procedure here

	 

	 @GUID_Image						uniqueidentifier = null

	,@GUID_noPersons					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

	DECLARE @GUID_Type_ImageObjects			uniqueidentifier

	DECLARE @GUID_Type_Partner				uniqueidentifier

	DECLARE @GUID_RelationType_locatedIn	uniqueidentifier

	DECLARE @GUID_RelationType_Is			uniqueidentifier

	DECLARE @GUID_RelationType_has			uniqueidentifier

	

	SET @GUID_Type_ImageObjects			= dbo.dbg_Type_Image_Objects()

	SET @GUID_Type_Partner				= dbo.dbg_Type_Partner()

	SET @GUID_RelationType_locatedIn	= dbo.dbg_RelationType_located_in()

	SET @GUID_RelationType_Is			= dbo.dbg_RelationType_is()

	SET @GUID_RelationType_has			= dbo.dbg_RelationType_has()

	

	PRINT @GUID_Type_ImageObjects			

	PRINT @GUID_Type_Partner				

	PRINT @GUID_RelationType_locatedIn		

	PRINT @GUID_RelationType_Is				

	PRINT @GUID_RelationType_has



    -- Insert statements for procedure here

	IF @GUID_Image IS NULL

	BEGIN

		SELECT   Image_To_Objects.GUID_Token_Right

					,func_Token_Image_Objects_1.GUID_Image_Objects

					,func_Token_Image_Objects_1.Name_Image_Objects

					,func_Token_Image_Objects_1.GUID_Type_Image_Objects

					,func_Token_Partner_1.GUID_Partner

					,func_Token_Partner_1.Name_Partner

					,func_Token_Partner_1.GUID_Type_Partner

		FROM         dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 INNER JOIN

							  semtbl_Token_Token AS Image_To_Objects ON func_Token_Image_Objects_1.GUID_Image_Objects = Image_To_Objects.GUID_Token_Left INNER JOIN

							  semtbl_Token_Token AS ImageObject_to_Partner ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_to_Partner.GUID_Token_Left INNER JOIN

							  dbo.func_Token_Partner(@GUID_Type_Partner) AS func_Token_Partner_1 ON 

							  ImageObject_to_Partner.GUID_Token_Right = func_Token_Partner_1.GUID_Partner

		WHERE     (Image_To_Objects.GUID_RelationType = @GUID_RelationType_locatedIn) AND 

							  (ImageObject_to_Partner.GUID_RelationType = @GUID_RelationType_Is)

		                      

			UNION

			

		SELECT     semtbl_Token_Token.GUID_Token_Right, func_Token_Image_Objects_1.GUID_Image_Objects, func_Token_Image_Objects_1.Name_Image_Objects, 

							  func_Token_Image_Objects_1.GUID_Type_Image_Objects, ImageObject_To_NoObjects.GUID_Token_Right AS GUID_Partner, CAST(NULL AS VARCHAR(255)) AS Name_Partner, CAST(NULL AS Uniqueidentifier) AS GUID_Type_Partner

		FROM         semtbl_Token_Token INNER JOIN

							  dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 ON 

							  semtbl_Token_Token.GUID_Token_Left = func_Token_Image_Objects_1.GUID_Image_Objects INNER JOIN

							  semtbl_Token_Token AS ImageObject_To_NoObjects ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_To_NoObjects.GUID_Token_Left

		WHERE     (semtbl_Token_Token.GUID_RelationType = @GUID_RelationType_locatedIn) AND 

							  (ImageObject_To_NoObjects.GUID_Token_Right = @GUID_noPersons) AND (ImageObject_To_NoObjects.GUID_RelationType = @GUID_RelationType_has)

	END

	ELSE

	BEGIN

		SELECT   Image_To_Objects.GUID_Token_Right

					,func_Token_Image_Objects_1.GUID_Image_Objects

					,func_Token_Image_Objects_1.Name_Image_Objects

					,func_Token_Image_Objects_1.GUID_Type_Image_Objects

					,func_Token_Partner_1.GUID_Partner

					,func_Token_Partner_1.Name_Partner

					,func_Token_Partner_1.GUID_Type_Partner

		FROM         dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 INNER JOIN

							  semtbl_Token_Token AS Image_To_Objects ON func_Token_Image_Objects_1.GUID_Image_Objects = Image_To_Objects.GUID_Token_Left INNER JOIN

							  semtbl_Token_Token AS ImageObject_to_Partner ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_to_Partner.GUID_Token_Left INNER JOIN

							  dbo.func_Token_Partner(@GUID_Type_Partner) AS func_Token_Partner_1 ON 

							  ImageObject_to_Partner.GUID_Token_Right = func_Token_Partner_1.GUID_Partner

		WHERE     (Image_To_Objects.GUID_Token_Right = @GUID_Image) AND (Image_To_Objects.GUID_RelationType = @GUID_RelationType_locatedIn) AND 

							  (ImageObject_to_Partner.GUID_RelationType = @GUID_RelationType_Is)

		                      

			UNION

			

		SELECT     semtbl_Token_Token.GUID_Token_Right, func_Token_Image_Objects_1.GUID_Image_Objects, func_Token_Image_Objects_1.Name_Image_Objects, 

							  func_Token_Image_Objects_1.GUID_Type_Image_Objects, ImageObject_To_NoObjects.GUID_Token_Right AS GUID_Partner, CAST(NULL AS VARCHAR(255)) AS Name_Partner, CAST(NULL AS Uniqueidentifier) AS GUID_Type_Partner

		FROM         semtbl_Token_Token INNER JOIN

							  dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 ON 

							  semtbl_Token_Token.GUID_Token_Left = func_Token_Image_Objects_1.GUID_Image_Objects INNER JOIN

							  semtbl_Token_Token AS ImageObject_To_NoObjects ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_To_NoObjects.GUID_Token_Left

		WHERE     (semtbl_Token_Token.GUID_RelationType = @GUID_RelationType_locatedIn) AND (semtbl_Token_Token.GUID_Token_Right = @GUID_Image) AND 

							  (ImageObject_To_NoObjects.GUID_Token_Right = @GUID_noPersons) AND (ImageObject_To_NoObjects.GUID_RelationType = @GUID_RelationType_has)

	END							 

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Image_Of_Or_ImportantEvents]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Image_Of_Or_ImportantEvents] 

	-- Add the parameters for the stored procedure here

	@GUID_Image			uniqueidentifier	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

	DECLARE @GUID_Type_ImageGraphic				uniqueidentifier;

	DECLARE @GUID_Type_File						uniqueidentifier

	DECLARE @GUID_Type_ImportantEvent			uniqueidentifier

	DECLARE @GUID_RelationType_belongsTo		uniqueidentifier;

	DECLARE @GUID_RelationType_belongingSource	uniqueidentifier;

	

	SET @GUID_Type_ImageGraphic				= dbo.dbg_Type_Images__Graphic_();

	SET @GUID_Type_File						= dbo.dbg_Type_File()

	SET @GUID_Type_ImportantEvent			= dbo.dbg_Type_Wichtige_Ereignisse()

	SET @GUID_RelationType_belongsTo		= dbo.dbg_RelationType_belongs_to();

	SET @GUID_RelationType_belongingSource	= dbo.dbg_RelationType_belonging_Source();

	

	PRINT @GUID_Type_ImageGraphic;

	PRINT @GUID_Type_File

	PRINT @GUID_Type_ImportantEvent

	PRINT @GUID_RelationType_belongsTo;

	PRINT @GUID_RelationType_belongingSource;

	

    -- Insert statements for procedure here

	SELECT     ImageGraphic_To_ObjectReference.OrderID, func_Token_Images__Graphic__1.GUID_Images__Graphic_, 

                      func_Token_Images__Graphic__1.Name_Images__Graphic_, func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, 

                      ImageGraphic_To_File.GUID_RelationType, ImageGraphic_To_ObjectReference.GUID_ObjectReference, func_Token_File_1.GUID_File, func_Token_File_1.Name_File, 

                      func_Token_File_1.GUID_Type_File, func_Token_Wichtige_Ereignisse_1.GUID_Wichtige_Ereignisse, 

                      func_Token_Wichtige_Ereignisse_1.Name_Wichtige_Ereignisse, func_Token_Wichtige_Ereignisse_1.GUID_Type_Wichtige_Ereignisse

FROM         semtbl_Token_OR AS ImageGraphic_To_ObjectReference INNER JOIN

                      dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 ON 

                      ImageGraphic_To_ObjectReference.GUID_Token_Left = func_Token_Images__Graphic__1.GUID_Images__Graphic_ INNER JOIN

                      semtbl_Token_Token AS ImageGraphic_To_File ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = ImageGraphic_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON ImageGraphic_To_File.GUID_Token_Right = func_Token_File_1.GUID_File INNER JOIN

                      semtbl_OR_Token ON ImageGraphic_To_ObjectReference.GUID_ObjectReference = semtbl_OR_Token.GUID_ObjectReference INNER JOIN

                      dbo.func_Token_Wichtige_Ereignisse(@GUID_Type_ImportantEvent) AS func_Token_Wichtige_Ereignisse_1 ON 

                      semtbl_OR_Token.GUID_Token = func_Token_Wichtige_Ereignisse_1.GUID_Wichtige_Ereignisse

WHERE     (ImageGraphic_To_ObjectReference.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (ImageGraphic_To_File.GUID_RelationType = @GUID_RelationType_belongingSource) AND 

                      (func_Token_Images__Graphic__1.GUID_Images__Graphic_ = @GUID_Image)

ORDER BY ImageGraphic_To_ObjectReference.OrderID, func_Token_Images__Graphic__1.Name_Images__Graphic_



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Images_And_References]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE dbg_Images_And_References

	-- Add the parameters for the stored procedure here

	 

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Type_ImageGraphic			uniqueidentifier

	DECLARE @GUID_RelationType_belongsTo	uniqueidentifier

	

	SET @GUID_Type_ImageGraphic			= dbo.dbg_Type_Images__Graphic_()

	SET @GUID_RelationType_belongsTo	= dbo.dbg_RelationType_belongs_to()

	

	PRINT @GUID_Type_ImageGraphic		

	PRINT @GUID_RelationType_belongsTo	

    -- Insert statements for procedure here

	SELECT     func_Token_Images__Graphic__1.GUID_Images__Graphic_, func_Token_Images__Graphic__1.Name_Images__Graphic_, 

                      func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, semfunc_ObjectReference_1.Name_Token, semfunc_ObjectReference_1.GUID_Ref, 

                      semfunc_ObjectReference_1.GUID_ItemType

FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 INNER JOIN

                      semtbl_Token_OR ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = semtbl_Token_OR.GUID_Token_Left INNER JOIN

                      dbo.semfunc_ObjectReference() AS semfunc_ObjectReference_1 ON 

                      semtbl_Token_OR.GUID_ObjectReference = semfunc_ObjectReference_1.GUID_ObjectReference

WHERE     (semtbl_Token_OR.GUID_RelationType = @GUID_RelationType_belongsTo)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_PDF_Of_Or]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_PDF_Of_Or] 

	-- Add the parameters for the stored procedure here

	@GUID_Type_PDF_Documents				uniqueidentifier,

	@GUID_Type_File						uniqueidentifier,

	@GUID_RelationType_belongsTo		uniqueidentifier,

	@GUID_RelationType_belongingSource	uniqueidentifier,

	@GUID_ObjectReference				uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

SELECT     PDF_Documents_To_ObjectReference.OrderID, func_Token_PDF_Documents_1.GUID_PDF_Documents, func_Token_PDF_Documents_1.Name_PDF_Documents, 

                      func_Token_PDF_Documents_1.GUID_Type_PDF_Documents, PDF_Documents_To_File.GUID_RelationType, 

                      PDF_Documents_To_ObjectReference.GUID_ObjectReference, func_Token_File_1.GUID_File, func_Token_File_1.Name_File, 

                      func_Token_File_1.GUID_Type_File

FROM         semtbl_Token_OR AS PDF_Documents_To_ObjectReference INNER JOIN

                      dbo.func_Token_PDF_Documents(@GUID_Type_PDF_Documents) AS func_Token_PDF_Documents_1 ON 

                      PDF_Documents_To_ObjectReference.GUID_Token_Left = func_Token_PDF_Documents_1.GUID_PDF_Documents INNER JOIN

                      semtbl_Token_Token AS PDF_Documents_To_File ON 

                      func_Token_PDF_Documents_1.GUID_PDF_Documents = PDF_Documents_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON PDF_Documents_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

WHERE     (PDF_Documents_To_ObjectReference.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (PDF_Documents_To_ObjectReference.GUID_ObjectReference = @GUID_ObjectReference) AND 

                      (PDF_Documents_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

ORDER BY PDF_Documents_To_ObjectReference.OrderID



END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_MediaItem_Of_Or]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_MediaItem_Of_Or] 

	-- Add the parameters for the stored procedure here

	@GUID_Type_MediaItem				uniqueidentifier,

	@GUID_Type_File						uniqueidentifier,

	@GUID_Type_Bookmark					uniqueidentifier,

	@GUID_RelationType_belongsTo		uniqueidentifier,

	@GUID_RelationType_belongingSource	uniqueidentifier,

	@GUID_ObjectReference				uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     MediaItem_To_ObjectReference.OrderID, func_Token_MediaItem_1.GUID_Media_Item, func_Token_MediaItem_1.Name_Media_Item, 

                      func_Token_MediaItem_1.GUID_Type_Media_Item, MediaItem_To_File.GUID_RelationType, MediaItem_To_ObjectReference.GUID_ObjectReference, 

                      func_Token_File_1.GUID_File, func_Token_File_1.Name_File, func_Token_File_1.GUID_Type_File, RAND(ABS(CONVERT(INT, CONVERT(binary(4), NEWID())))) AS Random, ISNULL(Count_Bookmarks,0) AS Count_Bookmarks

FROM         semtbl_Token_OR AS MediaItem_To_ObjectReference INNER JOIN

                      dbo.func_Token_Media_Item(@GUID_Type_MediaItem) AS func_Token_MediaItem_1 ON 

                      MediaItem_To_ObjectReference.GUID_Token_Left = func_Token_MediaItem_1.GUID_Media_Item INNER JOIN

                      semtbl_Token_Token AS MediaItem_To_File ON func_Token_MediaItem_1.GUID_Media_Item = MediaItem_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON MediaItem_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

                      LEFT OUTER JOIN (SELECT     Bookmark_To_MediaItem.GUID_Token_Right, COUNT(*) AS Count_Bookmarks

FROM         dbo.func_Token_Media_Item_Bookmark(@GUID_Type_Bookmark) AS func_Token_Media_Item_Bookmark_1 INNER JOIN

                      semtbl_Token_Token AS Bookmark_To_MediaItem ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = Bookmark_To_MediaItem.GUID_Token_Left

WHERE     (Bookmark_To_MediaItem.GUID_RelationType = @GUID_RelationType_belongsTo)

GROUP BY Bookmark_To_MediaItem.GUID_Token_Right) AS Bookmarks ON func_Token_MediaItem_1.GUID_Media_Item = Bookmarks.GUID_Token_Right

WHERE     (MediaItem_To_ObjectReference.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (MediaItem_To_ObjectReference.GUID_ObjectReference = @GUID_ObjectReference) AND 

                      (MediaItem_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

ORDER BY MediaItem_To_ObjectReference.OrderID, func_Token_MediaItem_1.Name_Media_Item





END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Related_Of_ImageObjects]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Related_Of_ImageObjects]

	-- Add the parameters for the stored procedure here

	  @GUID_Token_NoRelation		uniqueidentifier

	 ,@GUID_Type_Related			uniqueidentifier

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Type_ImageObject		uniqueidentifier

	DECLARE @GUID_RelationType_Is		uniqueidentifier

	

	SET @GUID_Type_ImageObject		= dbo.dbg_Type_Image_Objects()

	SET @GUID_RelationType_Is		= dbo.dbg_RelationType_is()

	

	PRINT @GUID_Type_ImageObject		

	PRINT @GUID_RelationType_Is		

    -- Insert statements for procedure here

	SELECT  DISTINCT   Related.GUID_Token, Related.Name_Token, Related.GUID_Type

FROM         dbo.func_Token_Image_Objects(@GUID_Type_ImageObject) AS func_Token_Image_Objects_1 INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_Related ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_To_Related.GUID_Token_Left INNER JOIN

                      semtbl_Token AS Related ON ImageObject_To_Related.GUID_Token_Right = Related.GUID_Token

WHERE     (ImageObject_To_Related.GUID_RelationType = @GUID_RelationType_Is) AND (Related.GUID_Type = @GUID_Type_Related) AND 

                      (NOT (Related.GUID_Token = @GUID_Token_NoRelation))

ORDER BY Name_Token

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Image_Of_Or_ImportantEvents]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Image_Of_Or_ImportantEvents] 

	-- Add the parameters for the stored procedure here

	 @GUID_Type_ImageGraphic				uniqueidentifier

	,@GUID_Type_File						uniqueidentifier

	,@GUID_Type_ImportantEvent				uniqueidentifier

	,@GUID_RelationType_belongsTo			uniqueidentifier

	,@GUID_RelationType_belongingSource		uniqueidentifier

	,@GUID_Image							uniqueidentifier	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

    -- Insert statements for procedure here

	SELECT     ImageGraphic_To_ObjectReference.OrderID, func_Token_Images__Graphic__1.GUID_Images__Graphic_, 

                      func_Token_Images__Graphic__1.Name_Images__Graphic_, func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, 

                      ImageGraphic_To_File.GUID_RelationType, ImageGraphic_To_ObjectReference.GUID_ObjectReference, func_Token_File_1.GUID_File, func_Token_File_1.Name_File, 

                      func_Token_File_1.GUID_Type_File, func_Token_Wichtige_Ereignisse_1.GUID_Wichtige_Ereignisse, 

                      func_Token_Wichtige_Ereignisse_1.Name_Wichtige_Ereignisse, func_Token_Wichtige_Ereignisse_1.GUID_Type_Wichtige_Ereignisse

FROM         semtbl_Token_OR AS ImageGraphic_To_ObjectReference INNER JOIN

                      dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 ON 

                      ImageGraphic_To_ObjectReference.GUID_Token_Left = func_Token_Images__Graphic__1.GUID_Images__Graphic_ INNER JOIN

                      semtbl_Token_Token AS ImageGraphic_To_File ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = ImageGraphic_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON ImageGraphic_To_File.GUID_Token_Right = func_Token_File_1.GUID_File INNER JOIN

                      semtbl_OR_Token ON ImageGraphic_To_ObjectReference.GUID_ObjectReference = semtbl_OR_Token.GUID_ObjectReference INNER JOIN

                      dbo.func_Token_Wichtige_Ereignisse(@GUID_Type_ImportantEvent) AS func_Token_Wichtige_Ereignisse_1 ON 

                      semtbl_OR_Token.GUID_Token = func_Token_Wichtige_Ereignisse_1.GUID_Wichtige_Ereignisse

WHERE     (ImageGraphic_To_ObjectReference.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (ImageGraphic_To_File.GUID_RelationType = @GUID_RelationType_belongingSource) AND 

                      (func_Token_Images__Graphic__1.GUID_Images__Graphic_ = @GUID_Image)

ORDER BY ImageGraphic_To_ObjectReference.OrderID, func_Token_Images__Graphic__1.Name_Images__Graphic_



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Images_And_References]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_Images_And_References

	-- Add the parameters for the stored procedure here

	 @GUID_Type_ImageGraphic		uniqueidentifier

	,@GUID_RelationType_belongsTo	uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     func_Token_Images__Graphic__1.GUID_Images__Graphic_, func_Token_Images__Graphic__1.Name_Images__Graphic_, 

                      func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, semfunc_ObjectReference_1.Name_Token, semfunc_ObjectReference_1.GUID_Ref, 

                      semfunc_ObjectReference_1.GUID_ItemType

FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 INNER JOIN

                      semtbl_Token_OR ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = semtbl_Token_OR.GUID_Token_Left INNER JOIN

                      dbo.semfunc_ObjectReference() AS semfunc_ObjectReference_1 ON 

                      semtbl_Token_OR.GUID_ObjectReference = semfunc_ObjectReference_1.GUID_ObjectReference

WHERE     (semtbl_Token_OR.GUID_RelationType = @GUID_RelationType_belongsTo)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_MediaItems_And_Files]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE proc_MediaItems_And_Files

	-- Add the parameters for the stored procedure here

	 @GUID_Type_MediaItem				uniqueidentifier

	,@GUID_Type_File					uniqueidentifier

	,@GUID_RelationType_belongingSource	uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     func_Token_Media_Item_1.GUID_Media_Item, func_Token_Media_Item_1.Name_Media_Item, func_Token_Media_Item_1.GUID_Type_Media_Item, 

                      func_Token_File_1.GUID_File, func_Token_File_1.Name_File, func_Token_File_1.GUID_Type_File

FROM         dbo.func_Token_Media_Item(@GUID_Type_MediaItem) AS func_Token_Media_Item_1 INNER JOIN

                      semtbl_Token_Token AS MediaItem_To_File ON func_Token_Media_Item_1.GUID_Media_Item = MediaItem_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON MediaItem_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

WHERE     (MediaItem_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)	

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Image_Of_Or]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Image_Of_Or] 

	-- Add the parameters for the stored procedure here

	

	@GUID_ObjectReference				uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

	DECLARE @GUID_Type_ImageGraphic				uniqueidentifier;

	DECLARE @GUID_Type_File						uniqueidentifier

	DECLARE @GUID_RelationType_belongsTo		uniqueidentifier;

	DECLARE @GUID_RelationType_belongingSource	uniqueidentifier;

	

	SET @GUID_Type_ImageGraphic				= dbo.dbg_Type_Images__Graphic_();

	SET @GUID_Type_File						= dbo.dbg_Type_File()

	SET @GUID_RelationType_belongsTo		= dbo.dbg_RelationType_belongs_to();

	SET @GUID_RelationType_belongingSource	= dbo.dbg_RelationType_belonging_Source();

	

	PRINT @GUID_Type_ImageGraphic;

	PRINT @GUID_Type_File

	PRINT @GUID_RelationType_belongsTo;

	PRINT @GUID_RelationType_belongingSource;

	

    -- Insert statements for procedure here

	SELECT     ImageGraphic_To_ObjectReference.OrderID, func_Token_Images__Graphic__1.GUID_Images__Graphic_, 

                      func_Token_Images__Graphic__1.Name_Images__Graphic_, func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, 

                      ImageGraphic_To_File.GUID_RelationType, ImageGraphic_To_ObjectReference.GUID_ObjectReference, func_Token_File_1.GUID_File, func_Token_File_1.Name_File, 

                      func_Token_File_1.GUID_Type_File

FROM         semtbl_Token_OR AS ImageGraphic_To_ObjectReference INNER JOIN

                      dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 ON 

                      ImageGraphic_To_ObjectReference.GUID_Token_Left = func_Token_Images__Graphic__1.GUID_Images__Graphic_ INNER JOIN

                      semtbl_Token_Token AS ImageGraphic_To_File ON func_Token_Images__Graphic__1.GUID_Images__Graphic_ = ImageGraphic_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON ImageGraphic_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

WHERE     (ImageGraphic_To_ObjectReference.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (ImageGraphic_To_ObjectReference.GUID_ObjectReference = @GUID_ObjectReference) AND 

                      (ImageGraphic_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

ORDER BY ImageGraphic_To_ObjectReference.OrderID



END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Months]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION func_Months 

(	

	-- Add the parameters for the function here

	 @GUID_Type_Month		uniqueidentifier

	,@GUID_Attribute_ID	uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     func_Token_Month_1.GUID_Month, Month__ID_Val.GUID_TokenAttribute AS GUID_TokenAttribute_Month, Month__ID_Val.val AS Month

	FROM         dbo.func_Token_Month(@GUID_Type_Month) AS func_Token_Month_1 INNER JOIN

						  semtbl_Token_Attribute AS Month__ID ON func_Token_Month_1.GUID_Month = Month__ID.GUID_Token INNER JOIN

						  semtbl_Token_Attribute_Int AS Month__ID_Val ON Month__ID.GUID_TokenAttribute = Month__ID_Val.GUID_TokenAttribute

	WHERE     (Month__ID.GUID_Attribute = @GUID_Attribute_ID)

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Genre]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE dbg_Genre

	-- Add the parameters for the stored procedure here

	

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

	DECLARE @GUID_Type_Genre		uniqueidentifier

	DECLARE @GUID_Attribute_ID		uniqueidentifier

	

	SET @GUID_Type_Genre		= dbo.dbg_Type_Genre()

	SET @GUID_Attribute_ID		= dbo.dbg_AttributeType_ID()

	

	PRINT @GUID_Type_Genre		

	PRINT @GUID_Attribute_ID	



    -- Insert statements for procedure here

	SELECT     func_Token_Genre_1.GUID_Genre, func_Token_Genre_1.Name_Genre, func_Token_Genre_1.GUID_Type_Genre, 

                      Genre__ID_Val.GUID_TokenAttribute AS GUID_TokenAttribute_ID, Genre__ID_Val.val AS ID

FROM         dbo.func_Token_Genre(@GUID_Type_Genre) AS func_Token_Genre_1 INNER JOIN

                      semtbl_Token_Attribute AS Genre__ID ON func_Token_Genre_1.GUID_Genre = Genre__ID.GUID_Token INNER JOIN

                      semtbl_Token_Attribute_Int AS Genre__ID_Val ON Genre__ID.GUID_TokenAttribute = Genre__ID_Val.GUID_TokenAttribute

WHERE     (Genre__ID.GUID_Attribute = @GUID_Attribute_ID)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Images_Of_Partner]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE dbg_Images_Of_Partner

	-- Add the parameters for the stored procedure here

	 

	@GUID_Partner					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Type_Partner				uniqueidentifier

	DECLARE @GUID_RelationType_is			uniqueidentifier

	DECLARE @GUID_RelationType_locatedIn	uniqueidentifier

	

	SET @GUID_Type_Partner				= dbo.dbg_Type_Partner()

	SET @GUID_RelationType_is			= dbo.dbg_RelationType_is()

	SET @GUID_RelationType_locatedIn	= dbo.dbg_RelationType_located_in()

	

	PRINT @GUID_Type_Partner				

	PRINT @GUID_RelationType_is			

	PRINT @GUID_RelationType_locatedIn	



    -- Insert statements for procedure here

	SELECT     ImageObject_To_Images.GUID_Token_Right AS GUID_Item

FROM         semtbl_Token AS Partner INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_Partner ON Partner.GUID_Token = ImageObject_To_Partner.GUID_Token_Right INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_Images ON ImageObject_To_Partner.GUID_Token_Left = ImageObject_To_Images.GUID_Token_Left

WHERE     (Partner.GUID_Type = @GUID_Type_Partner) AND (Partner.GUID_Token = @GUID_Partner) AND 

                      (ImageObject_To_Partner.GUID_RelationType = @GUID_RelationType_is) AND (ImageObject_To_Images.GUID_RelationType = @GUID_RelationType_locatedIn)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Images_Of_NamedRelated]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Images_Of_NamedRelated]

	-- Add the parameters for the stored procedure here

	 @GUID_Type_ImageObjects			uniqueidentifier

	,@GUID_Type_File					uniqueidentifier

	,@GUID_Type_Image					uniqueidentifier

	,@GUID_RelationType_belongingSource	uniqueidentifier

	,@GUID_RelationType_locatedIn		uniqueidentifier

	,@GUID_RelationType_Is				uniqueidentifier

	,@GUID_Related						uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     ImageObject_To_Image.OrderID, func_Token_Images__Graphic__1.GUID_Images__Graphic_, func_Token_Images__Graphic__1.Name_Images__Graphic_, 

                      func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, ImageObject_To_Image.GUID_RelationType, func_Token_File_1.GUID_File, 

                      func_Token_File_1.Name_File, func_Token_File_1.GUID_Type_File, ImageObject_To_Partner.GUID_Token_Right

FROM         semtbl_Token_Token AS ImageObject_To_Image INNER JOIN

                      dbo.func_Token_Image_Objects(@GUID_Type_ImageObjects) AS func_Token_Image_Objects_1 ON 

                      ImageObject_To_Image.GUID_Token_Left = func_Token_Image_Objects_1.GUID_Image_Objects INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_File ON func_Token_File_1.GUID_File = ImageObject_To_File.GUID_Token_Right INNER JOIN

                      dbo.func_Token_Images__Graphic_(@GUID_Type_Image) AS func_Token_Images__Graphic__1 ON 

                      ImageObject_To_File.GUID_Token_Left = func_Token_Images__Graphic__1.GUID_Images__Graphic_ ON 

                      ImageObject_To_Image.GUID_Token_Right = func_Token_Images__Graphic__1.GUID_Images__Graphic_ INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_Partner ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_To_Partner.GUID_Token_Left

WHERE     (ImageObject_To_File.GUID_RelationType = @GUID_RelationType_belongingSource) AND 

                      (ImageObject_To_Image.GUID_RelationType = @GUID_RelationType_locatedIn) AND (ImageObject_To_Partner.GUID_RelationType = @GUID_RelationType_Is) AND 

                      (ImageObject_To_Partner.GUID_Token_Right = @GUID_Related)

ORDER BY ImageObject_To_Image.OrderID, func_Token_Images__Graphic__1.Name_Images__Graphic_

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Related_Of_ImageObjects]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Related_Of_ImageObjects]

	-- Add the parameters for the stored procedure here

	 @GUID_Token_NoRelation		uniqueidentifier

	,@GUID_Type_ImageObject		uniqueidentifier

	,@GUID_Type_Related			uniqueidentifier

	,@GUID_RelationType_Is		uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT  DISTINCT   Related.GUID_Token, Related.Name_Token, Related.GUID_Type

FROM         dbo.func_Token_Image_Objects(@GUID_Type_ImageObject) AS func_Token_Image_Objects_1 INNER JOIN

                      semtbl_Token_Token AS ImageObject_To_Related ON func_Token_Image_Objects_1.GUID_Image_Objects = ImageObject_To_Related.GUID_Token_Left INNER JOIN

                      semtbl_Token AS Related ON ImageObject_To_Related.GUID_Token_Right = Related.GUID_Token

WHERE     (ImageObject_To_Related.GUID_RelationType = @GUID_RelationType_Is) AND (Related.GUID_Type = @GUID_Type_Related) AND 

                      (NOT (Related.GUID_Token = @GUID_Token_NoRelation))

ORDER BY Name_Token

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Medias_Chrono]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION [dbo].[func_Medias_Chrono]

(	

	-- Add the parameters for the function here

	 @GUID_Attribute_ID			uniqueidentifier

	,@GUID_Type_Year				uniqueidentifier

	,@GUID_Type_Month			uniqueidentifier

	,@GUID_Type_Day				uniqueidentifier

	,@GUID_Type_ImageGraphic		uniqueidentifier

	,@GUID_RelationType_takingAt	uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     func_Token_Images__Graphic__1.GUID_Images__Graphic_, func_Token_Images__Graphic__1.Name_Images__Graphic_, 

                      func_Token_Images__Graphic__1.GUID_Type_Images__Graphic_, Years_1.Year, Month.Month, Days_1.Day, GUID_Year, GUID_Month, GUID_Day,

                      DATENAME(month,

							CAST(CAST(Days_1.Day AS VARCHAR(2)) 

							+ ''.'' 

							+ CAST(Month.Month AS VARCHAR(2)) 

							+ ''.'' + CAST(Years_1.Year AS VARCHAR(4)) AS DATETIME)) AS NameOfMonth,

                      DATENAME(dw,

							CAST(CAST(Days_1.Day AS VARCHAR(2)) 

							+ ''.'' 

							+ CAST(Month.Month AS VARCHAR(2)) 

							+ ''.'' + CAST(Years_1.Year AS VARCHAR(4)) AS DATETIME)) AS NameOfDay,

							CAST(CAST(Days_1.Day AS VARCHAR(2)) 

							+ ''.'' 

							+ CAST(Month.Month AS VARCHAR(2)) 

							+ ''.'' + CAST(Years_1.Year AS VARCHAR(4)) AS DATETIME) AS DateOfPhoto

FROM         dbo.func_Token_Images__Graphic_(@GUID_Type_ImageGraphic) AS func_Token_Images__Graphic__1 LEFT OUTER JOIN

                          (SELECT     semtbl_Token_Token_2.GUID_Token_Left, Days.GUID_Day, Days.Day

                            FROM          dbo.func_Days(@GUID_Type_Day, @GUID_Attribute_ID) AS Days INNER JOIN

                                                   semtbl_Token_Token AS semtbl_Token_Token_2 ON semtbl_Token_Token_2.GUID_Token_Right = Days.GUID_Day) AS Days_1 ON 

                      func_Token_Images__Graphic__1.GUID_Images__Graphic_ = Days_1.GUID_Token_Left LEFT OUTER JOIN

                          (SELECT     semtbl_Token_Token_1.GUID_Token_Left, Months.GUID_Month, Months.Month

                            FROM          dbo.func_Months(@GUID_Type_Month, @GUID_Attribute_ID) AS Months INNER JOIN

                                                   semtbl_Token_Token AS semtbl_Token_Token_1 ON semtbl_Token_Token_1.GUID_Token_Right = Months.GUID_Month) AS Month ON 

                      func_Token_Images__Graphic__1.GUID_Images__Graphic_ = Month.GUID_Token_Left LEFT OUTER JOIN

                          (SELECT     semtbl_Token_Token.GUID_Token_Left, Years.GUID_Year, Years.Year

                            FROM          dbo.func_Years(@GUID_Type_Year, @GUID_Attribute_ID) AS Years INNER JOIN

                                                   semtbl_Token_Token ON semtbl_Token_Token.GUID_Token_Right = Years.GUID_Year) AS Years_1 ON 

                      func_Token_Images__Graphic__1.GUID_Images__Graphic_ = Years_1.GUID_Token_Left

)
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Bookmarks_Of_MediaItem]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Bookmarks_Of_MediaItem] 

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_Datetimestamp		uniqueidentifier

	,@GUID_Type_Bookmark				uniqueidentifier

	,@GUID_Type_MediaItem				uniqueidentifier

	,@GUID_Type_Logentry				uniqueidentifier

	,@GUID_Type_User					uniqueidentifier

	,@GUID_RelationType_WasCreatedBy	uniqueidentifier

	,@GUID_RelationType_belongsTo		uniqueidentifier

	,@GUID_RelationType_belongingDone	uniqueidentifier

	,@GUID_MediaItem					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

SELECT     func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark, func_Token_Media_Item_Bookmark_1.Name_Media_Item_Bookmark, 

                      func_Token_Media_Item_Bookmark_1.GUID_Type_Media_Item_Bookmark, func_Token_Media_Item_1.GUID_Media_Item, 

                      func_Token_Media_Item_1.Name_Media_Item, func_Token_Media_Item_1.GUID_Type_Media_Item, 

                      BookMark__MediaPosition_Val.GUID_TokenAttribute AS GUID_TokenAttribute_MediaPosition, BookMark__MediaPosition_Val.val AS MediaPosition, 

                      func_Token_Logentry_1.GUID_Logentry, func_Token_Logentry_1.Name_Logentry, func_Token_Logentry_1.GUID_Type_Logentry, 

                      Logentry__DateTimestamp_Val.val AS Datetimestamp, Logentry__DateTimestamp_Val.GUID_TokenAttribute AS GUID_TokenAttribute_DateTimestamp, 

                      func_User_Of_Logentry_1.GUID_user, func_User_Of_Logentry_1.Name_user, func_User_Of_Logentry_1.GUID_Type_user

FROM         dbo.func_Token_Media_Item_Bookmark(@GUID_Type_Bookmark) AS func_Token_Media_Item_Bookmark_1 INNER JOIN

                      semtbl_Token_Token AS BookMark_To_MediaItem ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark_To_MediaItem.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Media_Item(@GUID_Type_MediaItem) AS func_Token_Media_Item_1 ON 

                      BookMark_To_MediaItem.GUID_Token_Right = func_Token_Media_Item_1.GUID_Media_Item INNER JOIN

                      semtbl_Token_Attribute AS BookMark__MediaPosition ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark__MediaPosition.GUID_Token INNER JOIN

                      semtbl_Token_Attribute_varchar255 AS BookMark__MediaPosition_Val ON 

                      BookMark__MediaPosition.GUID_TokenAttribute = BookMark__MediaPosition_Val.GUID_TokenAttribute INNER JOIN

                      semtbl_Token_Token AS BookMark_To_Logentry ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark_To_Logentry.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Logentry(@GUID_Type_Logentry) AS func_Token_Logentry_1 ON 

                      BookMark_To_Logentry.GUID_Token_Right = func_Token_Logentry_1.GUID_Logentry INNER JOIN

                      semtbl_Token_Attribute AS Logentry__DateTimestamp ON func_Token_Logentry_1.GUID_Logentry = Logentry__DateTimestamp.GUID_Token INNER JOIN

                      semtbl_Token_attribute_datetime AS Logentry__DateTimestamp_Val ON 

                      Logentry__DateTimestamp.GUID_TokenAttribute = Logentry__DateTimestamp_Val.GUID_TokenAttribute LEFT OUTER JOIN

                      dbo.func_User_Of_Logentry(@GUID_Type_User, @GUID_Type_Logentry, @GUID_RelationType_WasCreatedBy) AS func_User_Of_Logentry_1 ON 

                      func_Token_Logentry_1.GUID_Logentry = func_User_Of_Logentry_1.GUID_Logentry

WHERE     (BookMark_To_MediaItem.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (BookMark_To_Logentry.GUID_RelationType = @GUID_RelationType_belongingDone) AND 

                      (Logentry__DateTimestamp.GUID_Attribute = @GUID_Attribute_Datetimestamp) AND (func_Token_Media_Item_1.GUID_Media_Item = @GUID_MediaItem)

ORDER BY Datetimestamp DESC

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Bookmarks_Of_MediaItem_Of_Ref]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Bookmarks_Of_MediaItem_Of_Ref]

	-- Add the parameters for the stored procedure here

	@GUID_Ref							uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

	DECLARE @GUID_Attribute_Datetimestamp		uniqueidentifier

	DECLARE @GUID_Type_Bookmark					uniqueidentifier

	DECLARE @GUID_Type_MediaItem				uniqueidentifier

	DECLARE @GUID_Type_Logentry					uniqueidentifier

	DECLARE @GUID_Type_User						uniqueidentifier

	DECLARE @GUID_RelationType_WasCreatedBy		uniqueidentifier

	DECLARE @GUID_RelationType_belongsTo		uniqueidentifier

	DECLARE @GUID_RelationType_belongingDone	uniqueidentifier

	

	SET @GUID_Attribute_Datetimestamp		= dbo.dbg_AttributeType_DateTimestamp()

	SET @GUID_Type_Bookmark					= dbo.dbg_Type_Media_Item_Bookmark()

	SET @GUID_Type_MediaItem				= dbo.dbg_Type_Media_Item()

	SET @GUID_Type_Logentry					= dbo.dbg_Type_Logentry()

	SET @GUID_Type_User						= dbo.dbg_Type_user()

	SET @GUID_RelationType_WasCreatedBy		= dbo.dbg_RelationType_was_created_by()

	SET @GUID_RelationType_belongsTo		= dbo.dbg_RelationType_belongs_to()

	SET @GUID_RelationType_belongingDone	= dbo.dbg_RelationType_belonging_Done()

	

	PRINT @GUID_Attribute_Datetimestamp		

	PRINT @GUID_Type_Bookmark				

	PRINT @GUID_Type_MediaItem				

	PRINT @GUID_Type_Logentry				

	PRINT @GUID_RelationType_belongsTo		

	PRINT @GUID_RelationType_belongingDone	



    -- Insert statements for procedure here

SELECT     func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark, func_Token_Media_Item_Bookmark_1.Name_Media_Item_Bookmark, 

                      func_Token_Media_Item_Bookmark_1.GUID_Type_Media_Item_Bookmark, func_Token_Media_Item_1.GUID_Media_Item, 

                      func_Token_Media_Item_1.Name_Media_Item, func_Token_Media_Item_1.GUID_Type_Media_Item, 

                      BookMark__MediaPosition_Val.GUID_TokenAttribute AS GUID_TokenAttribute_MediaPosition, BookMark__MediaPosition_Val.val AS MediaPosition, 

                      func_Token_Logentry_1.GUID_Logentry, func_Token_Logentry_1.Name_Logentry, func_Token_Logentry_1.GUID_Type_Logentry, 

                      Logentry__DateTimestamp_Val.val AS Datetimestamp, Logentry__DateTimestamp_Val.GUID_TokenAttribute AS GUID_TokenAttribute_DateTimestamp, 

                      semfunc_ObjectReference_1.GUID_Ref, semfunc_ObjectReference_1.Name_Token, semfunc_ObjectReference_1.GUID_ItemType, MediaItem_To_Ref.OrderID, 

                      func_User_Of_Logentry_1.GUID_user, func_User_Of_Logentry_1.Name_user, func_User_Of_Logentry_1.GUID_Type_user

FROM         dbo.func_Token_Media_Item_Bookmark(@GUID_Type_Bookmark) AS func_Token_Media_Item_Bookmark_1 INNER JOIN

                      semtbl_Token_Token AS BookMark_To_MediaItem ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark_To_MediaItem.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Media_Item(@GUID_Type_MediaItem) AS func_Token_Media_Item_1 ON 

                      BookMark_To_MediaItem.GUID_Token_Right = func_Token_Media_Item_1.GUID_Media_Item INNER JOIN

                      semtbl_Token_Attribute AS BookMark__MediaPosition ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark__MediaPosition.GUID_Token INNER JOIN

                      semtbl_Token_Attribute_varchar255 AS BookMark__MediaPosition_Val ON 

                      BookMark__MediaPosition.GUID_TokenAttribute = BookMark__MediaPosition_Val.GUID_TokenAttribute INNER JOIN

                      semtbl_Token_Token AS BookMark_To_Logentry ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark_To_Logentry.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Logentry(@GUID_Type_Logentry) AS func_Token_Logentry_1 ON 

                      BookMark_To_Logentry.GUID_Token_Right = func_Token_Logentry_1.GUID_Logentry INNER JOIN

                      semtbl_Token_Attribute AS Logentry__DateTimestamp ON func_Token_Logentry_1.GUID_Logentry = Logentry__DateTimestamp.GUID_Token INNER JOIN

                      semtbl_Token_attribute_datetime AS Logentry__DateTimestamp_Val ON 

                      Logentry__DateTimestamp.GUID_TokenAttribute = Logentry__DateTimestamp_Val.GUID_TokenAttribute INNER JOIN

                      semtbl_Token_OR AS MediaItem_To_Ref ON func_Token_Media_Item_1.GUID_Media_Item = MediaItem_To_Ref.GUID_Token_Left INNER JOIN

                      dbo.semfunc_ObjectReference() AS semfunc_ObjectReference_1 ON 

                      MediaItem_To_Ref.GUID_ObjectReference = semfunc_ObjectReference_1.GUID_ObjectReference LEFT OUTER JOIN

                      dbo.func_User_Of_Logentry(@GUID_Type_User, @GUID_Type_LogEntry, @GUID_RelationType_wasCreatedBy) AS func_User_Of_Logentry_1 ON 

                      func_Token_Logentry_1.GUID_Logentry = func_User_Of_Logentry_1.GUID_Logentry

WHERE     (BookMark_To_MediaItem.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (BookMark_To_Logentry.GUID_RelationType = @GUID_RelationType_belongingDone) AND 

                      (Logentry__DateTimestamp.GUID_Attribute = @GUID_Attribute_Datetimestamp) AND (MediaItem_To_Ref.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (semfunc_ObjectReference_1.GUID_Ref = @GUID_Ref)

ORDER BY Datetimestamp DESC

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Bookmarks_Of_MediaItem_Of_Ref]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Bookmarks_Of_MediaItem_Of_Ref]

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_Datetimestamp		uniqueidentifier

	,@GUID_Type_Bookmark				uniqueidentifier

	,@GUID_Type_MediaItem				uniqueidentifier

	,@GUID_Type_Logentry				uniqueidentifier

	,@GUID_Type_User					uniqueidentifier

	,@GUID_RelationType_WasCreatedBy	uniqueidentifier

	,@GUID_RelationType_belongsTo		uniqueidentifier

	,@GUID_RelationType_belongingDone	uniqueidentifier

	,@GUID_Ref							uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

SELECT     func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark, func_Token_Media_Item_Bookmark_1.Name_Media_Item_Bookmark, 

                      func_Token_Media_Item_Bookmark_1.GUID_Type_Media_Item_Bookmark, func_Token_Media_Item_1.GUID_Media_Item, 

                      func_Token_Media_Item_1.Name_Media_Item, func_Token_Media_Item_1.GUID_Type_Media_Item, 

                      BookMark__MediaPosition_Val.GUID_TokenAttribute AS GUID_TokenAttribute_MediaPosition, BookMark__MediaPosition_Val.val AS MediaPosition, 

                      func_Token_Logentry_1.GUID_Logentry, func_Token_Logentry_1.Name_Logentry, func_Token_Logentry_1.GUID_Type_Logentry, 

                      Logentry__DateTimestamp_Val.val AS Datetimestamp, Logentry__DateTimestamp_Val.GUID_TokenAttribute AS GUID_TokenAttribute_DateTimestamp, 

                      semfunc_ObjectReference_1.GUID_Ref, semfunc_ObjectReference_1.Name_Token, semfunc_ObjectReference_1.GUID_ItemType, MediaItem_To_Ref.OrderID, 

                      func_User_Of_Logentry_1.GUID_user, func_User_Of_Logentry_1.Name_user, func_User_Of_Logentry_1.GUID_Type_user

FROM         dbo.func_Token_Media_Item_Bookmark(@GUID_Type_Bookmark) AS func_Token_Media_Item_Bookmark_1 INNER JOIN

                      semtbl_Token_Token AS BookMark_To_MediaItem ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark_To_MediaItem.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Media_Item(@GUID_Type_MediaItem) AS func_Token_Media_Item_1 ON 

                      BookMark_To_MediaItem.GUID_Token_Right = func_Token_Media_Item_1.GUID_Media_Item INNER JOIN

                      semtbl_Token_Attribute AS BookMark__MediaPosition ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark__MediaPosition.GUID_Token INNER JOIN

                      semtbl_Token_Attribute_varchar255 AS BookMark__MediaPosition_Val ON 

                      BookMark__MediaPosition.GUID_TokenAttribute = BookMark__MediaPosition_Val.GUID_TokenAttribute INNER JOIN

                      semtbl_Token_Token AS BookMark_To_Logentry ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark_To_Logentry.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Logentry(@GUID_Type_Logentry) AS func_Token_Logentry_1 ON 

                      BookMark_To_Logentry.GUID_Token_Right = func_Token_Logentry_1.GUID_Logentry INNER JOIN

                      semtbl_Token_Attribute AS Logentry__DateTimestamp ON func_Token_Logentry_1.GUID_Logentry = Logentry__DateTimestamp.GUID_Token INNER JOIN

                      semtbl_Token_attribute_datetime AS Logentry__DateTimestamp_Val ON 

                      Logentry__DateTimestamp.GUID_TokenAttribute = Logentry__DateTimestamp_Val.GUID_TokenAttribute INNER JOIN

                      semtbl_Token_OR AS MediaItem_To_Ref ON func_Token_Media_Item_1.GUID_Media_Item = MediaItem_To_Ref.GUID_Token_Left INNER JOIN

                      dbo.semfunc_ObjectReference() AS semfunc_ObjectReference_1 ON 

                      MediaItem_To_Ref.GUID_ObjectReference = semfunc_ObjectReference_1.GUID_ObjectReference LEFT OUTER JOIN

                      dbo.func_User_Of_Logentry(@GUID_Type_User, @GUID_Type_LogEntry, @GUID_RelationType_wasCreatedBy) AS func_User_Of_Logentry_1 ON 

                      func_Token_Logentry_1.GUID_Logentry = func_User_Of_Logentry_1.GUID_Logentry

WHERE     (BookMark_To_MediaItem.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (BookMark_To_Logentry.GUID_RelationType = @GUID_RelationType_belongingDone) AND 

                      (Logentry__DateTimestamp.GUID_Attribute = @GUID_Attribute_Datetimestamp) AND (MediaItem_To_Ref.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (semfunc_ObjectReference_1.GUID_Ref = @GUID_Ref)

ORDER BY Datetimestamp DESC

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Bookmarks_Of_MediaItem]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Bookmarks_Of_MediaItem] 

	-- Add the parameters for the stored procedure here

	 

	@GUID_MediaItem					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Attribute_Datetimestamp		uniqueidentifier

	DECLARE @GUID_Type_Bookmark					uniqueidentifier

	DECLARE @GUID_Type_MediaItem				uniqueidentifier

	DECLARE @GUID_Type_Logentry					uniqueidentifier

	DECLARE @GUID_Type_User						uniqueidentifier

	DECLARE @GUID_RelationType_WasCreatedBy		uniqueidentifier

	DECLARE @GUID_RelationType_belongsTo		uniqueidentifier

	DECLARE @GUID_RelationType_belongingDone	uniqueidentifier

	

	SET @GUID_Attribute_Datetimestamp		= dbo.dbg_AttributeType_DateTimestamp()

	SET @GUID_Type_Bookmark					= dbo.dbg_Type_Media_Item_Bookmark()

	SET @GUID_Type_MediaItem				= dbo.dbg_Type_Media_Item()

	SET @GUID_Type_Logentry					= dbo.dbg_Type_Logentry()

	SET @GUID_Type_User						= dbo.dbg_Type_user()

	SET @GUID_RelationType_WasCreatedBy		= dbo.dbg_RelationType_was_created_by()

	SET @GUID_RelationType_belongsTo		= dbo.dbg_RelationType_belongs_to()

	SET @GUID_RelationType_belongingDone	= dbo.dbg_RelationType_belonging_Done()

	

	PRINT @GUID_Attribute_Datetimestamp		

	PRINT @GUID_Type_Bookmark				

	PRINT @GUID_Type_MediaItem				

	PRINT @GUID_Type_Logentry				

	PRINT @GUID_Type_User						

	PRINT @GUID_RelationType_WasCreatedBy		

	PRINT @GUID_RelationType_belongsTo		

	PRINT @GUID_RelationType_belongingDone	

    -- Insert statements for procedure here

SELECT     func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark, func_Token_Media_Item_Bookmark_1.Name_Media_Item_Bookmark, 

                      func_Token_Media_Item_Bookmark_1.GUID_Type_Media_Item_Bookmark, func_Token_Media_Item_1.GUID_Media_Item, 

                      func_Token_Media_Item_1.Name_Media_Item, func_Token_Media_Item_1.GUID_Type_Media_Item, 

                      BookMark__MediaPosition_Val.GUID_TokenAttribute AS GUID_TokenAttribute_MediaPosition, BookMark__MediaPosition_Val.val AS MediaPosition, 

                      func_Token_Logentry_1.GUID_Logentry, func_Token_Logentry_1.Name_Logentry, func_Token_Logentry_1.GUID_Type_Logentry, 

                      Logentry__DateTimestamp_Val.val AS Datetimestamp, Logentry__DateTimestamp_Val.GUID_TokenAttribute AS GUID_TokenAttribute_DateTimestamp, 

                      func_User_Of_Logentry_1.GUID_user, func_User_Of_Logentry_1.Name_user, func_User_Of_Logentry_1.GUID_Type_user

FROM         dbo.func_Token_Media_Item_Bookmark(@GUID_Type_Bookmark) AS func_Token_Media_Item_Bookmark_1 INNER JOIN

                      semtbl_Token_Token AS BookMark_To_MediaItem ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark_To_MediaItem.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Media_Item(@GUID_Type_MediaItem) AS func_Token_Media_Item_1 ON 

                      BookMark_To_MediaItem.GUID_Token_Right = func_Token_Media_Item_1.GUID_Media_Item INNER JOIN

                      semtbl_Token_Attribute AS BookMark__MediaPosition ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark__MediaPosition.GUID_Token INNER JOIN

                      semtbl_Token_Attribute_varchar255 AS BookMark__MediaPosition_Val ON 

                      BookMark__MediaPosition.GUID_TokenAttribute = BookMark__MediaPosition_Val.GUID_TokenAttribute INNER JOIN

                      semtbl_Token_Token AS BookMark_To_Logentry ON 

                      func_Token_Media_Item_Bookmark_1.GUID_Media_Item_Bookmark = BookMark_To_Logentry.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Logentry(@GUID_Type_Logentry) AS func_Token_Logentry_1 ON 

                      BookMark_To_Logentry.GUID_Token_Right = func_Token_Logentry_1.GUID_Logentry INNER JOIN

                      semtbl_Token_Attribute AS Logentry__DateTimestamp ON func_Token_Logentry_1.GUID_Logentry = Logentry__DateTimestamp.GUID_Token INNER JOIN

                      semtbl_Token_attribute_datetime AS Logentry__DateTimestamp_Val ON 

                      Logentry__DateTimestamp.GUID_TokenAttribute = Logentry__DateTimestamp_Val.GUID_TokenAttribute LEFT OUTER JOIN

                      dbo.func_User_Of_Logentry(@GUID_Type_User, @GUID_Type_Logentry, @GUID_RelationType_WasCreatedBy) AS func_User_Of_Logentry_1 ON 

                      func_Token_Logentry_1.GUID_Logentry = func_User_Of_Logentry_1.GUID_Logentry

WHERE     (BookMark_To_MediaItem.GUID_RelationType = @GUID_RelationType_belongsTo) AND 

                      (BookMark_To_Logentry.GUID_RelationType = @GUID_RelationType_belongingDone) AND 

                      (Logentry__DateTimestamp.GUID_Attribute = @GUID_Attribute_Datetimestamp) AND (func_Token_Media_Item_1.GUID_Media_Item = @GUID_MediaItem)

ORDER BY Datetimestamp DESC

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Medias_Chrono]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Medias_Chrono]

	-- Add the parameters for the stored procedure here

	@GUID_Type_MediaType		uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Attribute_ID					uniqueidentifier

	DECLARE @GUID_Type_Year						uniqueidentifier

	DECLARE @GUID_Type_Month					uniqueidentifier

	DECLARE @GUID_Type_Day						uniqueidentifier

	DECLARE @GUID_Type_File						uniqueidentifier

	DECLARE @GUID_RelationType_takingAt			uniqueidentifier

	DECLARE @GUID_RelationType_belongingSource	uniqueidentifier

	

	SET @GUID_Attribute_ID					= dbo.dbg_AttributeType_ID()

	SET @GUID_Type_Year						= dbo.dbg_Type_Year()

	SET @GUID_Type_Month					= dbo.dbg_Type_Month()

	SET @GUID_Type_Day						= dbo.dbg_Type_Day()

	SET @GUID_Type_File						= dbo.dbg_Type_File()

	SET @GUID_RelationType_takingAt			= dbo.dbg_RelationType_taking_at()

	SET @GUID_RelationType_belongingSource	= dbo.dbg_RelationType_belonging_Source()	

	

	PRINT @GUID_Attribute_ID

	PRINT @GUID_Type_Year

	PRINT @GUID_Type_Month

	PRINT @GUID_Type_Day

	PRINT @GUID_Type_File

	PRINT @GUID_RelationType_takingAt

	PRINT @GUID_RelationType_belongingSource

	

    -- Insert statements for procedure here

	SELECT     func_Medias_Chrono_1.GUID_Year, func_Medias_Chrono_1.Year, func_Medias_Chrono_1.GUID_Month, func_Medias_Chrono_1.Month, 

                      func_Medias_Chrono_1.GUID_Day, func_Medias_Chrono_1.Day, func_Medias_Chrono_1.GUID_Images__Graphic_, 

                      func_Medias_Chrono_1.Name_Images__Graphic_, func_Medias_Chrono_1.GUID_Type_Images__Graphic_, func_Token_File_1.GUID_File, 

                      func_Token_File_1.Name_File, func_Token_File_1.GUID_Type_File

FROM         dbo.func_Medias_Chrono(@GUID_Attribute_ID, @GUID_Type_Year, @GUID_Type_Month, @GUID_Type_Day, @GUID_Type_MediaType, 

                      @GUID_RelationType_takingAt) AS func_Medias_Chrono_1 INNER JOIN

                      semtbl_Token_Token AS MediaItem_To_File ON func_Medias_Chrono_1.GUID_Images__Graphic_ = MediaItem_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON MediaItem_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

WHERE     (MediaItem_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

	

	

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Medias_Chrono]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'



-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Medias_Chrono]

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_ID					uniqueidentifier

	,@GUID_Type_Year					uniqueidentifier

	,@GUID_Type_Month					uniqueidentifier

	,@GUID_Type_Day						uniqueidentifier

	,@GUID_Type_File					uniqueidentifier

	,@GUID_RelationType_takingAt		uniqueidentifier

	,@GUID_RelationType_belongingSource	uniqueidentifier

	,@GUID_Type_MediaType				uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	

    -- Insert statements for procedure here

	SELECT     func_Medias_Chrono_1.GUID_Year, func_Medias_Chrono_1.Year, func_Medias_Chrono_1.GUID_Month, func_Medias_Chrono_1.Month, 

                      func_Medias_Chrono_1.GUID_Day, func_Medias_Chrono_1.Day, func_Medias_Chrono_1.GUID_Images__Graphic_, 

                      func_Medias_Chrono_1.Name_Images__Graphic_, func_Medias_Chrono_1.GUID_Type_Images__Graphic_, func_Token_File_1.GUID_File, 

                      func_Token_File_1.Name_File, func_Token_File_1.GUID_Type_File

FROM         dbo.func_Medias_Chrono(@GUID_Attribute_ID, @GUID_Type_Year, @GUID_Type_Month, @GUID_Type_Day, @GUID_Type_MediaType, 

                      @GUID_RelationType_takingAt) AS func_Medias_Chrono_1 INNER JOIN

                      semtbl_Token_Token AS MediaItem_To_File ON func_Medias_Chrono_1.GUID_Images__Graphic_ = MediaItem_To_File.GUID_Token_Left INNER JOIN

                      dbo.func_Token_File(@GUID_Type_File) AS func_Token_File_1 ON MediaItem_To_File.GUID_Token_Right = func_Token_File_1.GUID_File

WHERE     (MediaItem_To_File.GUID_RelationType = @GUID_RelationType_belongingSource)

	

	

END




'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Medias_Chrono_DateParts]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Medias_Chrono_DateParts]

	-- Add the parameters for the stored procedure here

	@GUID_Type_MediaType		uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Attribute_ID			uniqueidentifier

	DECLARE @GUID_Type_Year				uniqueidentifier

	DECLARE @GUID_Type_Month			uniqueidentifier

	DECLARE @GUID_Type_Day				uniqueidentifier

	DECLARE @GUID_RelationType_takingAt	uniqueidentifier

	

	SET @GUID_Attribute_ID			= dbo.dbg_AttributeType_ID()

	SET @GUID_Type_Year				= dbo.dbg_Type_Year()

	SET @GUID_Type_Month			= dbo.dbg_Type_Month()

	SET @GUID_Type_Day				= dbo.dbg_Type_Day()

	SET @GUID_RelationType_takingAt	= dbo.dbg_RelationType_taking_at()

	

	PRINT @GUID_Attribute_ID

	PRINT @GUID_Type_Year

	PRINT @GUID_Type_Month

	PRINT @GUID_Type_Day

	PRINT @GUID_RelationType_takingAt

	

    -- Insert statements for procedure here

	SELECT     GUID_Year, Year, GUID_Month, Month, NameOfMonth, GUID_Day, Day, NameOfDay, DateOfPhoto

FROM         dbo.func_Medias_Chrono(@GUID_Attribute_ID			

	,@GUID_Type_Year				

	,@GUID_Type_Month			

	,@GUID_Type_Day				

	,@GUID_Type_MediaType		

	,@GUID_RelationType_takingAt	) AS func_Medias_Chrono_1

GROUP BY Year, Month, Day, GUID_Year, GUID_Month, GUID_Day, NameOfMonth, NameOfDay, DateOfPhoto

ORDER BY Year, Month, Day

	

	

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Medias_Chrono_DateParts]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Medias_Chrono_DateParts]

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_ID			uniqueidentifier

	,@GUID_Type_Year				uniqueidentifier

	,@GUID_Type_Month			uniqueidentifier

	,@GUID_Type_Day				uniqueidentifier

	,@GUID_RelationType_takingAt	uniqueidentifier

	,@GUID_Type_MediaType		uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	

    -- Insert statements for procedure here

	SELECT     GUID_Year, Year, GUID_Month, Month, NameOfMonth, GUID_Day, Day, NameOfDay

FROM         dbo.func_Medias_Chrono(@GUID_Attribute_ID			

	,@GUID_Type_Year				

	,@GUID_Type_Month			

	,@GUID_Type_Day				

	,@GUID_Type_MediaType		

	,@GUID_RelationType_takingAt	) AS func_Medias_Chrono_1

GROUP BY Year, Month, Day, GUID_Year, GUID_Month, GUID_Day, NameOfMonth, NameOfDay

ORDER BY Year, Month, Day

	

	

END


'
END
GO
EXEC sp_addextendedproperty 
		@name = SchemaVersion, @value = '0.0.0.5';
GO
EXEC sp_addextendedproperty 
		@name = SemDB, @value = 'Yes';
GO
