execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'') = 0
	insert into semtbl_Attribute VALUES(''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'',''db_postfix'',''065e644e-c7df-4007-8672-aa5414131c78'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''daf53cbc-2cb4-42ed-8722-ee85f6b33512'') = 0
	insert into semtbl_Attribute VALUES(''daf53cbc-2cb4-42ed-8722-ee85f6b33512'',''Menge'',''a1244d0e-187f-46ee-8574-2fc334077b7d'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''0b183be9-c13d-4157-989b-63b0362aeee6'') = 0
	insert into semtbl_Attribute VALUES(''0b183be9-c13d-4157-989b-63b0362aeee6'',''ID'',''3a4f5b7b-da75-4980-933e-fbc33cc51439'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'') = 0
	insert into semtbl_Attribute VALUES(''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'',''factor'',''a1244d0e-187f-46ee-8574-2fc334077b7d'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''54aebd25-9ade-45c7-9f23-cd3496e667d0'')=0
	insert into semtbl_RelationType VALUES(''54aebd25-9ade-45c7-9f23-cd3496e667d0'',''y'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''9996494a-ef6a-4357-a6ef-71a92b5ff596'')=0
	insert into semtbl_RelationType VALUES(''9996494a-ef6a-4357-a6ef-71a92b5ff596'',''is of Type'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''0330361a-c81b-4895-a0c9-498397059368'')=0
	insert into semtbl_RelationType VALUES(''0330361a-c81b-4895-a0c9-498397059368'',''x'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''b57a0de7-25b7-4de2-964e-0fcf12346028'')=0
	insert into semtbl_RelationType VALUES(''b57a0de7-25b7-4de2-964e-0fcf12346028'',''z'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''f77ee633-19d8-4ea6-947f-9fb6efad3547'')=0
	insert into semtbl_RelationType VALUES(''f77ee633-19d8-4ea6-947f-9fb6efad3547'',''is partner of'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''c9670b90-e5f0-4e30-a26d-ad3d6576ceac'')=0
	insert into semtbl_RelationType VALUES(''c9670b90-e5f0-4e30-a26d-ad3d6576ceac'',''contact'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''5d8f540c-3e92-4999-a710-ce7f2dd611de'')=0
	insert into semtbl_RelationType VALUES(''5d8f540c-3e92-4999-a710-ce7f2dd611de'',''Base'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	insert into semtbl_RelationType VALUES(''e9711603-47db-44d8-a476-fe88290639a4'',''contains'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''fafc1464-815f-4596-9737-bcbc96bd744a'')=0
	insert into semtbl_RelationType VALUES(''fafc1464-815f-4596-9737-bcbc96bd744a'',''needs'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''408db9f1-ae42-4807-b656-729270646f0a'')=0
	insert into semtbl_RelationType VALUES(''408db9f1-ae42-4807-b656-729270646f0a'',''is subordinated'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	insert into semtbl_RelationType VALUES(''e07469d9-766c-443e-8526-6d9c684f944f'',''belongs to'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type=''49fdcd27-e105-4770-941d-7485dcad08c1'') = 0
	insert into semtbl_Type (GUID_Type,Name_Type) VALUES(''49fdcd27-e105-4770-941d-7485dcad08c1'',''Root'')'
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='73e32abf-e577-4d31-9a46-bc07e9e15de3') = 0
	insert into semtbl_Type VALUES('73e32abf-e577-4d31-9a46-bc07e9e15de3','Software-Management','49fdcd27-e105-4770-941d-7485dcad08c1')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='71415eeb-ce46-4b2c-b0a2-f72116b55438') = 0
	insert into semtbl_Type VALUES('71415eeb-ce46-4b2c-b0a2-f72116b55438','Software-Development','73e32abf-e577-4d31-9a46-bc07e9e15de3')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='c6c9bcb8-0ac9-4713-9417-eeec1453026c') = 0
	insert into semtbl_Type VALUES('c6c9bcb8-0ac9-4713-9417-eeec1453026c','Development-Config','71415eeb-ce46-4b2c-b0a2-f72116b55438')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='13c09f11-175c-4eef-bc8a-0fd8e86d557f') = 0
	insert into semtbl_Type VALUES('13c09f11-175c-4eef-bc8a-0fd8e86d557f','Development-ConfigItem','c6c9bcb8-0ac9-4713-9417-eeec1453026c')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='7d0178e2-9c04-4485-b81c-6d79253c6f64') = 0
	insert into semtbl_Type VALUES('7d0178e2-9c04-4485-b81c-6d79253c6f64','Localization-Management','49fdcd27-e105-4770-941d-7485dcad08c1')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='8aa50712-fda9-4222-a350-6378f36e49f8') = 0
	insert into semtbl_Type VALUES('8aa50712-fda9-4222-a350-6378f36e49f8','Formats','7d0178e2-9c04-4485-b81c-6d79253c6f64')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='c9a01318-6258-46eb-8efd-ddddd9f8ab08') = 0
	insert into semtbl_Type VALUES('c9a01318-6258-46eb-8efd-ddddd9f8ab08','Datetime','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='83f136c4-cb76-4029-88ab-5ab8f10c1532') = 0
	insert into semtbl_Type VALUES('83f136c4-cb76-4029-88ab-5ab8f10c1532','Year','c9a01318-6258-46eb-8efd-ddddd9f8ab08')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='759bb22d-20b5-42ff-8079-813c2496946d') = 0
	insert into semtbl_Type VALUES('759bb22d-20b5-42ff-8079-813c2496946d','Month','c9a01318-6258-46eb-8efd-ddddd9f8ab08')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='3f7f258e-76b2-49ae-b5cc-25184f39899f') = 0
	insert into semtbl_Type VALUES('3f7f258e-76b2-49ae-b5cc-25184f39899f','Day','c9a01318-6258-46eb-8efd-ddddd9f8ab08')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='5f7a0238-859e-4eec-9f69-3038192cf56f') = 0
	insert into semtbl_Type VALUES('5f7a0238-859e-4eec-9f69-3038192cf56f','Menge','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='ac1b0479-188c-4e31-81f1-e3453fede26e') = 0
	insert into semtbl_Type VALUES('ac1b0479-188c-4e31-81f1-e3453fede26e','Fläche','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='d88808d0-0473-4594-a8f9-6c4cb3439297') = 0
	insert into semtbl_Type VALUES('d88808d0-0473-4594-a8f9-6c4cb3439297','Einheit','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='3617cfd1-c359-4da7-b306-1c1b780247bc') = 0
	insert into semtbl_Type VALUES('3617cfd1-c359-4da7-b306-1c1b780247bc','Volumen','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='2a127013-81ca-42a4-bcf3-c3f28d62bf1c') = 0
	insert into semtbl_Type VALUES('2a127013-81ca-42a4-bcf3-c3f28d62bf1c','Adress-Management','49fdcd27-e105-4770-941d-7485dcad08c1')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='a2d7d0fe-0495-4afe-85e1-1dcb88a27546') = 0
	insert into semtbl_Type VALUES('a2d7d0fe-0495-4afe-85e1-1dcb88a27546','Partner','2a127013-81ca-42a4-bcf3-c3f28d62bf1c')
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''c82f016f-67d5-4522-98a7-2f18193bfb73'') = 0
	insert into semtbl_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''OrganizationalTransaction_Module'',''c6c9bcb8-0ac9-4713-9417-eeec1453026c'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''34fec720-9627-4e36-8220-cfbfc84ec4aa'') = 0
	insert into semtbl_Token VALUES(''34fec720-9627-4e36-8220-cfbfc84ec4aa'',''OrganizationalTransaction_Module'',''71415eeb-ce46-4b2c-b0a2-f72116b55438'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''fb9503c0-b884-434e-af8a-0066c7a6c40f'') = 0
	insert into semtbl_Token VALUES(''fb9503c0-b884-434e-af8a-0066c7a6c40f'',''Type_Year'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''f2aca284-8ee0-4150-938b-09a43e7eafb7'') = 0
	insert into semtbl_Token VALUES(''f2aca284-8ee0-4150-938b-09a43e7eafb7'',''Attribute_Menge'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''e8305ca1-2e88-4267-b33d-1ae571916997'') = 0
	insert into semtbl_Token VALUES(''e8305ca1-2e88-4267-b33d-1ae571916997'',''Type_Menge'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''375c73ad-9a93-4775-a2ba-2fb097efb6ba'') = 0
	insert into semtbl_Token VALUES(''375c73ad-9a93-4775-a2ba-2fb097efb6ba'',''Type_Month'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''60dac2f0-947c-47cd-9933-4a4e69681176'') = 0
	insert into semtbl_Token VALUES(''60dac2f0-947c-47cd-9933-4a4e69681176'',''Attribute_ID'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''009a0ba6-515b-48c1-a1d9-66949d6f8dc6'') = 0
	insert into semtbl_Token VALUES(''009a0ba6-515b-48c1-a1d9-66949d6f8dc6'',''RelationType_y'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'') = 0
	insert into semtbl_Token VALUES(''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'',''attribute_dbPostfix'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''6e494944-f602-4dcb-906f-70e5efe8f1dd'') = 0
	insert into semtbl_Token VALUES(''6e494944-f602-4dcb-906f-70e5efe8f1dd'',''RelationType_is_of_Type'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''cb9a150e-0098-46ae-bd41-7799ad6fcd90'') = 0
	insert into semtbl_Token VALUES(''cb9a150e-0098-46ae-bd41-7799ad6fcd90'',''RelationType_x'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''54ee77fa-3d84-4564-a2d8-7a484c66c0e8'') = 0
	insert into semtbl_Token VALUES(''54ee77fa-3d84-4564-a2d8-7a484c66c0e8'',''Type_Day'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''32df0e2f-a562-4590-b38f-ada1fd1bf33b'') = 0
	insert into semtbl_Token VALUES(''32df0e2f-a562-4590-b38f-ada1fd1bf33b'',''Type_Fl_che'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''182cb7bc-21ae-4b32-9e14-bfc1f43ccf6f'') = 0
	insert into semtbl_Token VALUES(''182cb7bc-21ae-4b32-9e14-bfc1f43ccf6f'',''Type_Einheit'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''c11b34ce-41c9-485b-a0f2-e5c781f58850'') = 0
	insert into semtbl_Token VALUES(''c11b34ce-41c9-485b-a0f2-e5c781f58850'',''RelationType_z'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''92121dac-d796-4dac-acc8-ea779f9cb1cd'') = 0
	insert into semtbl_Token VALUES(''92121dac-d796-4dac-acc8-ea779f9cb1cd'',''Type_Partner'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''4a1bd2dd-c728-463b-b52b-f44837db66b6'') = 0
	insert into semtbl_Token VALUES(''4a1bd2dd-c728-463b-b52b-f44837db66b6'',''Type_Volumen'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''fb9503c0-b884-434e-af8a-0066c7a6c40f'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''fb9503c0-b884-434e-af8a-0066c7a6c40f'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''f2aca284-8ee0-4150-938b-09a43e7eafb7'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''f2aca284-8ee0-4150-938b-09a43e7eafb7'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''e8305ca1-2e88-4267-b33d-1ae571916997'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''e8305ca1-2e88-4267-b33d-1ae571916997'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''375c73ad-9a93-4775-a2ba-2fb097efb6ba'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''375c73ad-9a93-4775-a2ba-2fb097efb6ba'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''60dac2f0-947c-47cd-9933-4a4e69681176'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''60dac2f0-947c-47cd-9933-4a4e69681176'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''009a0ba6-515b-48c1-a1d9-66949d6f8dc6'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''009a0ba6-515b-48c1-a1d9-66949d6f8dc6'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''6e494944-f602-4dcb-906f-70e5efe8f1dd'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''6e494944-f602-4dcb-906f-70e5efe8f1dd'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''cb9a150e-0098-46ae-bd41-7799ad6fcd90'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''cb9a150e-0098-46ae-bd41-7799ad6fcd90'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''54ee77fa-3d84-4564-a2d8-7a484c66c0e8'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''54ee77fa-3d84-4564-a2d8-7a484c66c0e8'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''32df0e2f-a562-4590-b38f-ada1fd1bf33b'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''32df0e2f-a562-4590-b38f-ada1fd1bf33b'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''182cb7bc-21ae-4b32-9e14-bfc1f43ccf6f'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''182cb7bc-21ae-4b32-9e14-bfc1f43ccf6f'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''c11b34ce-41c9-485b-a0f2-e5c781f58850'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''c11b34ce-41c9-485b-a0f2-e5c781f58850'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''92121dac-d796-4dac-acc8-ea779f9cb1cd'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''92121dac-d796-4dac-acc8-ea779f9cb1cd'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_Token_Right=''4a1bd2dd-c728-463b-b52b-f44837db66b6'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c82f016f-67d5-4522-98a7-2f18193bfb73'',''4a1bd2dd-c728-463b-b52b-f44837db66b6'',''e9711603-47db-44d8-a476-fe88290639a4'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''34fec720-9627-4e36-8220-cfbfc84ec4aa'' AND GUID_Token_Right=''c82f016f-67d5-4522-98a7-2f18193bfb73'' AND GUID_RelationType=''fafc1464-815f-4596-9737-bcbc96bd744a'')=0
	INSERT INTO semtbl_Token_Token VALUES(''34fec720-9627-4e36-8220-cfbfc84ec4aa'',''c82f016f-67d5-4522-98a7-2f18193bfb73'',''fafc1464-815f-4596-9737-bcbc96bd744a'',1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Attribute=''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'',0,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''83f136c4-cb76-4029-88ab-5ab8f10c1532'' AND GUID_Attribute=''0b183be9-c13d-4157-989b-63b0362aeee6'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''83f136c4-cb76-4029-88ab-5ab8f10c1532'',''0b183be9-c13d-4157-989b-63b0362aeee6'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_Attribute=''daf53cbc-2cb4-42ed-8722-ee85f6b33512'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''5f7a0238-859e-4eec-9f69-3038192cf56f'',''daf53cbc-2cb4-42ed-8722-ee85f6b33512'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''759bb22d-20b5-42ff-8079-813c2496946d'' AND GUID_Attribute=''0b183be9-c13d-4157-989b-63b0362aeee6'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''759bb22d-20b5-42ff-8079-813c2496946d'',''0b183be9-c13d-4157-989b-63b0362aeee6'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''3f7f258e-76b2-49ae-b5cc-25184f39899f'' AND GUID_Attribute=''0b183be9-c13d-4157-989b-63b0362aeee6'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''3f7f258e-76b2-49ae-b5cc-25184f39899f'',''0b183be9-c13d-4157-989b-63b0362aeee6'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''d88808d0-0473-4594-a8f9-6c4cb3439297'' AND GUID_Attribute=''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''d88808d0-0473-4594-a8f9-6c4cb3439297'',''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'',0,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3617cfd1-c359-4da7-b306-1c1b780247bc'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''b57a0de7-25b7-4de2-964e-0fcf12346028'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3617cfd1-c359-4da7-b306-1c1b780247bc'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''b57a0de7-25b7-4de2-964e-0fcf12346028'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3617cfd1-c359-4da7-b306-1c1b780247bc'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''0330361a-c81b-4895-a0c9-498397059368'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3617cfd1-c359-4da7-b306-1c1b780247bc'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''0330361a-c81b-4895-a0c9-498397059368'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3617cfd1-c359-4da7-b306-1c1b780247bc'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''54aebd25-9ade-45c7-9f23-cd3496e667d0'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3617cfd1-c359-4da7-b306-1c1b780247bc'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''54aebd25-9ade-45c7-9f23-cd3496e667d0'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'' AND GUID_Type_Right=''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'' AND GUID_RelationType=''f77ee633-19d8-4ea6-947f-9fb6efad3547'')=0
	INSERT INTO semtbl_Type_Type VALUES(''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'',''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'',''f77ee633-19d8-4ea6-947f-9fb6efad3547'',0,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'' AND GUID_Type_Right=''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'' AND GUID_RelationType=''c9670b90-e5f0-4e30-a26d-ad3d6576ceac'')=0
	INSERT INTO semtbl_Type_Type VALUES(''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'',''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'',''c9670b90-e5f0-4e30-a26d-ad3d6576ceac'',0,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_Type_Right=''d88808d0-0473-4594-a8f9-6c4cb3439297'' AND GUID_RelationType=''9996494a-ef6a-4357-a6ef-71a92b5ff596'')=0
	INSERT INTO semtbl_Type_Type VALUES(''5f7a0238-859e-4eec-9f69-3038192cf56f'',''d88808d0-0473-4594-a8f9-6c4cb3439297'',''9996494a-ef6a-4357-a6ef-71a92b5ff596'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''d88808d0-0473-4594-a8f9-6c4cb3439297'' AND GUID_Type_Right=''d88808d0-0473-4594-a8f9-6c4cb3439297'' AND GUID_RelationType=''5d8f540c-3e92-4999-a710-ce7f2dd611de'')=0
	INSERT INTO semtbl_Type_Type VALUES(''d88808d0-0473-4594-a8f9-6c4cb3439297'',''d88808d0-0473-4594-a8f9-6c4cb3439297'',''5d8f540c-3e92-4999-a710-ce7f2dd611de'',0,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''ac1b0479-188c-4e31-81f1-e3453fede26e'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''0330361a-c81b-4895-a0c9-498397059368'')=0
	INSERT INTO semtbl_Type_Type VALUES(''ac1b0479-188c-4e31-81f1-e3453fede26e'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''0330361a-c81b-4895-a0c9-498397059368'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''ac1b0479-188c-4e31-81f1-e3453fede26e'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''54aebd25-9ade-45c7-9f23-cd3496e667d0'')=0
	INSERT INTO semtbl_Type_Type VALUES(''ac1b0479-188c-4e31-81f1-e3453fede26e'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''54aebd25-9ade-45c7-9f23-cd3496e667d0'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''c6c9bcb8-0ac9-4713-9417-eeec1453026c'' AND GUID_Type_Right=''13c09f11-175c-4eef-bc8a-0fd8e86d557f'' AND GUID_RelationType=''e9711603-47db-44d8-a476-fe88290639a4'')=0
	INSERT INTO semtbl_Type_Type VALUES(''c6c9bcb8-0ac9-4713-9417-eeec1453026c'',''13c09f11-175c-4eef-bc8a-0fd8e86d557f'',''e9711603-47db-44d8-a476-fe88290639a4'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''c6c9bcb8-0ac9-4713-9417-eeec1453026c'' AND GUID_RelationType=''fafc1464-815f-4596-9737-bcbc96bd744a'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''c6c9bcb8-0ac9-4713-9417-eeec1453026c'',''fafc1464-815f-4596-9737-bcbc96bd744a'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_RelationType=''408db9f1-ae42-4807-b656-729270646f0a'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''408db9f1-ae42-4807-b656-729270646f0a'',0,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_Type_Right=''71415eeb-ce46-4b2c-b0a2-f72116b55438'' AND GUID_RelationType=''fafc1464-815f-4596-9737-bcbc96bd744a'')=0
	INSERT INTO semtbl_Type_Type VALUES(''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''71415eeb-ce46-4b2c-b0a2-f72116b55438'',''fafc1464-815f-4596-9737-bcbc96bd744a'',0,-1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute WHERE GUID_TokenAttribute=''f7beb470-624c-42b2-8054-b461838e2e6c'' )=0
	INSERT INTO semtbl_Token_Attribute VALUES(''f7beb470-624c-42b2-8054-b461838e2e6c'',''34fec720-9627-4e36-8220-cfbfc84ec4aa'',''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute_Varchar255 WHERE GUID_TokenAttribute=''f7beb470-624c-42b2-8054-b461838e2e6c'' )=0
	INSERT INTO semtbl_Token_Attribute_Varchar255 VALUES(''f7beb470-624c-42b2-8054-b461838e2e6c'',''organizationalTransaction_module'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''6d57eeab-0eab-4a49-affd-c80a89322a43'')=0
	INSERT INTO semtbl_OR VALUES(''6d57eeab-0eab-4a49-affd-c80a89322a43'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''32d040af-504c-436a-8839-b57db67d158a'')=0
	INSERT INTO semtbl_OR VALUES(''32d040af-504c-436a-8839-b57db67d158a'',''66a7f5c9-bff6-40dc-a893-15bdb65dbf26'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''6564fe74-1e10-4042-8266-fb870071fc84'')=0
	INSERT INTO semtbl_OR VALUES(''6564fe74-1e10-4042-8266-fb870071fc84'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''71589523-ca58-4004-a5d8-fc1ef2518b6a'')=0
	INSERT INTO semtbl_OR VALUES(''71589523-ca58-4004-a5d8-fc1ef2518b6a'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''6c3f2ea4-031d-4529-8086-d582b82ee951'')=0
	INSERT INTO semtbl_OR VALUES(''6c3f2ea4-031d-4529-8086-d582b82ee951'',''66a7f5c9-bff6-40dc-a893-15bdb65dbf26'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''08d4565c-f349-44c4-b23c-9da71896ec33'')=0
	INSERT INTO semtbl_OR VALUES(''08d4565c-f349-44c4-b23c-9da71896ec33'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'')=0
	INSERT INTO semtbl_OR VALUES(''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'',''66a7f5c9-bff6-40dc-a893-15bdb65dbf26'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''008817a6-14e7-4295-9a69-6835575ae53b'')=0
	INSERT INTO semtbl_OR VALUES(''008817a6-14e7-4295-9a69-6835575ae53b'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''69babed9-216a-461e-9a48-2d77a92098b8'')=0
	INSERT INTO semtbl_OR VALUES(''69babed9-216a-461e-9a48-2d77a92098b8'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''8765f75d-d6eb-420a-bcc0-f19e7f9f0ef9'')=0
	INSERT INTO semtbl_OR VALUES(''8765f75d-d6eb-420a-bcc0-f19e7f9f0ef9'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''e50192e1-c6c7-4be5-9c31-6135b7bdde21'')=0
	INSERT INTO semtbl_OR VALUES(''e50192e1-c6c7-4be5-9c31-6135b7bdde21'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''9c9b2aba-8dbe-41eb-9ceb-3102b24a1cbd'')=0
	INSERT INTO semtbl_OR VALUES(''9c9b2aba-8dbe-41eb-9ceb-3102b24a1cbd'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''13a9f067-b980-4f06-a3ec-a1a52041af96'')=0
	INSERT INTO semtbl_OR VALUES(''13a9f067-b980-4f06-a3ec-a1a52041af96'',''761b8a7e-e65c-428a-804b-8e1d3def7c4b'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''a8abe90f-6ac3-42e4-a3a7-4144e836f8a6'')=0
	INSERT INTO semtbl_OR VALUES(''a8abe90f-6ac3-42e4-a3a7-4144e836f8a6'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR WHERE GUID_ObjectReference=''b5822536-4689-4283-9bb5-5dd8f86e8760'')=0
	INSERT INTO semtbl_OR VALUES(''b5822536-4689-4283-9bb5-5dd8f86e8760'',''5c78451d-fe48-48cc-bd49-0a47f947dfc6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''6d57eeab-0eab-4a49-affd-c80a89322a43'')=0
	INSERT INTO semtbl_OR_Type VALUES(''6d57eeab-0eab-4a49-affd-c80a89322a43'',''83f136c4-cb76-4029-88ab-5ab8f10c1532'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''6564fe74-1e10-4042-8266-fb870071fc84'')=0
	INSERT INTO semtbl_OR_Type VALUES(''6564fe74-1e10-4042-8266-fb870071fc84'',''5f7a0238-859e-4eec-9f69-3038192cf56f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''71589523-ca58-4004-a5d8-fc1ef2518b6a'')=0
	INSERT INTO semtbl_OR_Type VALUES(''71589523-ca58-4004-a5d8-fc1ef2518b6a'',''759bb22d-20b5-42ff-8079-813c2496946d'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''8765f75d-d6eb-420a-bcc0-f19e7f9f0ef9'')=0
	INSERT INTO semtbl_OR_Type VALUES(''8765f75d-d6eb-420a-bcc0-f19e7f9f0ef9'',''3f7f258e-76b2-49ae-b5cc-25184f39899f'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''e50192e1-c6c7-4be5-9c31-6135b7bdde21'')=0
	INSERT INTO semtbl_OR_Type VALUES(''e50192e1-c6c7-4be5-9c31-6135b7bdde21'',''ac1b0479-188c-4e31-81f1-e3453fede26e'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''9c9b2aba-8dbe-41eb-9ceb-3102b24a1cbd'')=0
	INSERT INTO semtbl_OR_Type VALUES(''9c9b2aba-8dbe-41eb-9ceb-3102b24a1cbd'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''a8abe90f-6ac3-42e4-a3a7-4144e836f8a6'')=0
	INSERT INTO semtbl_OR_Type VALUES(''a8abe90f-6ac3-42e4-a3a7-4144e836f8a6'',''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Type WHERE GUID_ObjectReference=''b5822536-4689-4283-9bb5-5dd8f86e8760'')=0
	INSERT INTO semtbl_OR_Type VALUES(''b5822536-4689-4283-9bb5-5dd8f86e8760'',''3617cfd1-c359-4da7-b306-1c1b780247bc'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Attribute WHERE GUID_ObjectReference=''32d040af-504c-436a-8839-b57db67d158a'')=0
	INSERT INTO semtbl_OR_Attribute VALUES(''32d040af-504c-436a-8839-b57db67d158a'',''daf53cbc-2cb4-42ed-8722-ee85f6b33512'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Attribute WHERE GUID_ObjectReference=''6c3f2ea4-031d-4529-8086-d582b82ee951'')=0
	INSERT INTO semtbl_OR_Attribute VALUES(''6c3f2ea4-031d-4529-8086-d582b82ee951'',''0b183be9-c13d-4157-989b-63b0362aeee6'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_Attribute WHERE GUID_ObjectReference=''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'')=0
	INSERT INTO semtbl_OR_Attribute VALUES(''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'',''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''08d4565c-f349-44c4-b23c-9da71896ec33'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''08d4565c-f349-44c4-b23c-9da71896ec33'',''54aebd25-9ade-45c7-9f23-cd3496e667d0'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''008817a6-14e7-4295-9a69-6835575ae53b'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''008817a6-14e7-4295-9a69-6835575ae53b'',''9996494a-ef6a-4357-a6ef-71a92b5ff596'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''69babed9-216a-461e-9a48-2d77a92098b8'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''69babed9-216a-461e-9a48-2d77a92098b8'',''0330361a-c81b-4895-a0c9-498397059368'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_OR_RelationType WHERE GUID_ObjectReference=''13a9f067-b980-4f06-a3ec-a1a52041af96'')=0
	INSERT INTO semtbl_OR_RelationType VALUES(''13a9f067-b980-4f06-a3ec-a1a52041af96'',''b57a0de7-25b7-4de2-964e-0fcf12346028'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''fb9503c0-b884-434e-af8a-0066c7a6c40f'' AND GUID_ObjectReference=''6d57eeab-0eab-4a49-affd-c80a89322a43'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''fb9503c0-b884-434e-af8a-0066c7a6c40f'',''6d57eeab-0eab-4a49-affd-c80a89322a43'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''f2aca284-8ee0-4150-938b-09a43e7eafb7'' AND GUID_ObjectReference=''32d040af-504c-436a-8839-b57db67d158a'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''f2aca284-8ee0-4150-938b-09a43e7eafb7'',''32d040af-504c-436a-8839-b57db67d158a'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''e8305ca1-2e88-4267-b33d-1ae571916997'' AND GUID_ObjectReference=''6564fe74-1e10-4042-8266-fb870071fc84'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''e8305ca1-2e88-4267-b33d-1ae571916997'',''6564fe74-1e10-4042-8266-fb870071fc84'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''375c73ad-9a93-4775-a2ba-2fb097efb6ba'' AND GUID_ObjectReference=''71589523-ca58-4004-a5d8-fc1ef2518b6a'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''375c73ad-9a93-4775-a2ba-2fb097efb6ba'',''71589523-ca58-4004-a5d8-fc1ef2518b6a'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''60dac2f0-947c-47cd-9933-4a4e69681176'' AND GUID_ObjectReference=''6c3f2ea4-031d-4529-8086-d582b82ee951'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''60dac2f0-947c-47cd-9933-4a4e69681176'',''6c3f2ea4-031d-4529-8086-d582b82ee951'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''009a0ba6-515b-48c1-a1d9-66949d6f8dc6'' AND GUID_ObjectReference=''08d4565c-f349-44c4-b23c-9da71896ec33'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''009a0ba6-515b-48c1-a1d9-66949d6f8dc6'',''08d4565c-f349-44c4-b23c-9da71896ec33'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'' AND GUID_ObjectReference=''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''8ca3c197-69bd-4d3c-bb3b-6b8e4483eb0d'',''88e201d4-a2fd-4b5e-93ba-c3f6241a3f92'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''6e494944-f602-4dcb-906f-70e5efe8f1dd'' AND GUID_ObjectReference=''008817a6-14e7-4295-9a69-6835575ae53b'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''6e494944-f602-4dcb-906f-70e5efe8f1dd'',''008817a6-14e7-4295-9a69-6835575ae53b'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''cb9a150e-0098-46ae-bd41-7799ad6fcd90'' AND GUID_ObjectReference=''69babed9-216a-461e-9a48-2d77a92098b8'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''cb9a150e-0098-46ae-bd41-7799ad6fcd90'',''69babed9-216a-461e-9a48-2d77a92098b8'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''54ee77fa-3d84-4564-a2d8-7a484c66c0e8'' AND GUID_ObjectReference=''8765f75d-d6eb-420a-bcc0-f19e7f9f0ef9'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''54ee77fa-3d84-4564-a2d8-7a484c66c0e8'',''8765f75d-d6eb-420a-bcc0-f19e7f9f0ef9'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''32df0e2f-a562-4590-b38f-ada1fd1bf33b'' AND GUID_ObjectReference=''e50192e1-c6c7-4be5-9c31-6135b7bdde21'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''32df0e2f-a562-4590-b38f-ada1fd1bf33b'',''e50192e1-c6c7-4be5-9c31-6135b7bdde21'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''182cb7bc-21ae-4b32-9e14-bfc1f43ccf6f'' AND GUID_ObjectReference=''9c9b2aba-8dbe-41eb-9ceb-3102b24a1cbd'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''182cb7bc-21ae-4b32-9e14-bfc1f43ccf6f'',''9c9b2aba-8dbe-41eb-9ceb-3102b24a1cbd'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''c11b34ce-41c9-485b-a0f2-e5c781f58850'' AND GUID_ObjectReference=''13a9f067-b980-4f06-a3ec-a1a52041af96'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''c11b34ce-41c9-485b-a0f2-e5c781f58850'',''13a9f067-b980-4f06-a3ec-a1a52041af96'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''92121dac-d796-4dac-acc8-ea779f9cb1cd'' AND GUID_ObjectReference=''a8abe90f-6ac3-42e4-a3a7-4144e836f8a6'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''92121dac-d796-4dac-acc8-ea779f9cb1cd'',''a8abe90f-6ac3-42e4-a3a7-4144e836f8a6'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_OR WHERE GUID_Token_Left=''4a1bd2dd-c728-463b-b52b-f44837db66b6'' AND GUID_ObjectReference=''b5822536-4689-4283-9bb5-5dd8f86e8760'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Token_OR VALUES(''4a1bd2dd-c728-463b-b52b-f44837db66b6'',''b5822536-4689-4283-9bb5-5dd8f86e8760'',''e07469d9-766c-443e-8526-6d9c684f944f'',0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_OR WHERE GUID_Type=''13c09f11-175c-4eef-bc8a-0fd8e86d557f'' AND GUID_RelationType=''e07469d9-766c-443e-8526-6d9c684f944f'')=0
	INSERT INTO semtbl_Type_OR VALUES(''13c09f11-175c-4eef-bc8a-0fd8e86d557f'',''e07469d9-766c-443e-8526-6d9c684f944f'',1,1)'
GO
