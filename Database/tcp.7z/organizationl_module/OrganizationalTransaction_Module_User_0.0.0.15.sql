use [sem_db_tcp]
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''daf53cbc-2cb4-42ed-8722-ee85f6b33512'') = 0
	insert into semtbl_Attribute VALUES(''daf53cbc-2cb4-42ed-8722-ee85f6b33512'',''Menge'',''a1244d0e-187f-46ee-8574-2fc334077b7d'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''0b183be9-c13d-4157-989b-63b0362aeee6'') = 0
	insert into semtbl_Attribute VALUES(''0b183be9-c13d-4157-989b-63b0362aeee6'',''ID'',''3a4f5b7b-da75-4980-933e-fbc33cc51439'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'') = 0
	insert into semtbl_Attribute VALUES(''64cf93ce-5b71-4a5c-b2cc-1b9638949cfe'',''db_postfix'',''065e644e-c7df-4007-8672-aa5414131c78'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Attribute WHERE GUID_Attribute=''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'') = 0
	insert into semtbl_Attribute VALUES(''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'',''factor'',''a1244d0e-187f-46ee-8574-2fc334077b7d'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''54aebd25-9ade-45c7-9f23-cd3496e667d0'')=0
	insert into semtbl_RelationType VALUES(''54aebd25-9ade-45c7-9f23-cd3496e667d0'',''y'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''9996494a-ef6a-4357-a6ef-71a92b5ff596'')=0
	insert into semtbl_RelationType VALUES(''9996494a-ef6a-4357-a6ef-71a92b5ff596'',''is of Type'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''0330361a-c81b-4895-a0c9-498397059368'')=0
	insert into semtbl_RelationType VALUES(''0330361a-c81b-4895-a0c9-498397059368'',''x'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''b57a0de7-25b7-4de2-964e-0fcf12346028'')=0
	insert into semtbl_RelationType VALUES(''b57a0de7-25b7-4de2-964e-0fcf12346028'',''z'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''f77ee633-19d8-4ea6-947f-9fb6efad3547'')=0
	insert into semtbl_RelationType VALUES(''f77ee633-19d8-4ea6-947f-9fb6efad3547'',''is partner of'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''c9670b90-e5f0-4e30-a26d-ad3d6576ceac'')=0
	insert into semtbl_RelationType VALUES(''c9670b90-e5f0-4e30-a26d-ad3d6576ceac'',''contact'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_RelationType WHERE GUID_RelationType=''5d8f540c-3e92-4999-a710-ce7f2dd611de'')=0
	insert into semtbl_RelationType VALUES(''5d8f540c-3e92-4999-a710-ce7f2dd611de'',''Base'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type=''49fdcd27-e105-4770-941d-7485dcad08c1'') = 0
	insert into semtbl_Type (GUID_Type,Name_Type) VALUES(''49fdcd27-e105-4770-941d-7485dcad08c1'',''Root'')'
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='7d0178e2-9c04-4485-b81c-6d79253c6f64') = 0
	insert into semtbl_Type VALUES('7d0178e2-9c04-4485-b81c-6d79253c6f64','Localization-Management','49fdcd27-e105-4770-941d-7485dcad08c1')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='8aa50712-fda9-4222-a350-6378f36e49f8') = 0
	insert into semtbl_Type VALUES('8aa50712-fda9-4222-a350-6378f36e49f8','Formats','7d0178e2-9c04-4485-b81c-6d79253c6f64')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='c9a01318-6258-46eb-8efd-ddddd9f8ab08') = 0
	insert into semtbl_Type VALUES('c9a01318-6258-46eb-8efd-ddddd9f8ab08','Datetime','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='83f136c4-cb76-4029-88ab-5ab8f10c1532') = 0
	insert into semtbl_Type VALUES('83f136c4-cb76-4029-88ab-5ab8f10c1532','Year','c9a01318-6258-46eb-8efd-ddddd9f8ab08')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='759bb22d-20b5-42ff-8079-813c2496946d') = 0
	insert into semtbl_Type VALUES('759bb22d-20b5-42ff-8079-813c2496946d','Month','c9a01318-6258-46eb-8efd-ddddd9f8ab08')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='3f7f258e-76b2-49ae-b5cc-25184f39899f') = 0
	insert into semtbl_Type VALUES('3f7f258e-76b2-49ae-b5cc-25184f39899f','Day','c9a01318-6258-46eb-8efd-ddddd9f8ab08')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='5f7a0238-859e-4eec-9f69-3038192cf56f') = 0
	insert into semtbl_Type VALUES('5f7a0238-859e-4eec-9f69-3038192cf56f','Menge','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='ac1b0479-188c-4e31-81f1-e3453fede26e') = 0
	insert into semtbl_Type VALUES('ac1b0479-188c-4e31-81f1-e3453fede26e','Fläche','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='d88808d0-0473-4594-a8f9-6c4cb3439297') = 0
	insert into semtbl_Type VALUES('d88808d0-0473-4594-a8f9-6c4cb3439297','Einheit','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='3617cfd1-c359-4da7-b306-1c1b780247bc') = 0
	insert into semtbl_Type VALUES('3617cfd1-c359-4da7-b306-1c1b780247bc','Volumen','8aa50712-fda9-4222-a350-6378f36e49f8')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='2a127013-81ca-42a4-bcf3-c3f28d62bf1c') = 0
	insert into semtbl_Type VALUES('2a127013-81ca-42a4-bcf3-c3f28d62bf1c','Adress-Management','49fdcd27-e105-4770-941d-7485dcad08c1')
GO
IF (SELECT COUNT(*) FROM semtbl_Type WHERE GUID_Type='a2d7d0fe-0495-4afe-85e1-1dcb88a27546') = 0
	insert into semtbl_Type VALUES('a2d7d0fe-0495-4afe-85e1-1dcb88a27546','Partner','2a127013-81ca-42a4-bcf3-c3f28d62bf1c')
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''6118968c-7f55-45e4-836c-3b676336f14e'') = 0
	insert into semtbl_Token VALUES(''6118968c-7f55-45e4-836c-3b676336f14e'',''%'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'') = 0
	insert into semtbl_Token VALUES(''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'',''Byte'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''bc88f617-123c-4d85-abea-4cf1d4a8ac42'') = 0
	insert into semtbl_Token VALUES(''bc88f617-123c-4d85-abea-4cf1d4a8ac42'',''g'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''96d35b3b-b61a-482c-91bb-06dda6553cf3'') = 0
	insert into semtbl_Token VALUES(''96d35b3b-b61a-482c-91bb-06dda6553cf3'',''GB'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''389e95dd-9eda-4717-8c50-6e8dbc99b417'') = 0
	insert into semtbl_Token VALUES(''389e95dd-9eda-4717-8c50-6e8dbc99b417'',''KB'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''5cdf3708-8444-4b29-9323-c829e6494189'') = 0
	insert into semtbl_Token VALUES(''5cdf3708-8444-4b29-9323-c829e6494189'',''MB'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''b7ff5fe4-cbff-4793-929f-f7c033658768'') = 0
	insert into semtbl_Token VALUES(''b7ff5fe4-cbff-4793-929f-f7c033658768'',''ml'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''bcd3f4d3-2c37-47c5-90b3-6f2ea40b0f6d'') = 0
	insert into semtbl_Token VALUES(''bcd3f4d3-2c37-47c5-90b3-6f2ea40b0f6d'',''Stück'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token WHERE GUID_Token=''c08a41df-d9b0-40c0-8f55-3a8d3a24778e'') = 0
	insert into semtbl_Token VALUES(''c08a41df-d9b0-40c0-8f55-3a8d3a24778e'',''TB'',''d88808d0-0473-4594-a8f9-6c4cb3439297'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''96d35b3b-b61a-482c-91bb-06dda6553cf3'' AND GUID_Token_Right=''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'' AND GUID_RelationType=''5d8f540c-3e92-4999-a710-ce7f2dd611de'')=0
	INSERT INTO semtbl_Token_Token VALUES(''96d35b3b-b61a-482c-91bb-06dda6553cf3'',''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'',''5d8f540c-3e92-4999-a710-ce7f2dd611de'',1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''389e95dd-9eda-4717-8c50-6e8dbc99b417'' AND GUID_Token_Right=''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'' AND GUID_RelationType=''5d8f540c-3e92-4999-a710-ce7f2dd611de'')=0
	INSERT INTO semtbl_Token_Token VALUES(''389e95dd-9eda-4717-8c50-6e8dbc99b417'',''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'',''5d8f540c-3e92-4999-a710-ce7f2dd611de'',1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''5cdf3708-8444-4b29-9323-c829e6494189'' AND GUID_Token_Right=''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'' AND GUID_RelationType=''5d8f540c-3e92-4999-a710-ce7f2dd611de'')=0
	INSERT INTO semtbl_Token_Token VALUES(''5cdf3708-8444-4b29-9323-c829e6494189'',''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'',''5d8f540c-3e92-4999-a710-ce7f2dd611de'',1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Token WHERE GUID_Token_Left=''c08a41df-d9b0-40c0-8f55-3a8d3a24778e'' AND GUID_Token_Right=''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'' AND GUID_RelationType=''5d8f540c-3e92-4999-a710-ce7f2dd611de'')=0
	INSERT INTO semtbl_Token_Token VALUES(''c08a41df-d9b0-40c0-8f55-3a8d3a24778e'',''bfbc1e96-4016-4ecf-acf3-87ebcbf48df1'',''5d8f540c-3e92-4999-a710-ce7f2dd611de'',1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''83f136c4-cb76-4029-88ab-5ab8f10c1532'' AND GUID_Attribute=''0b183be9-c13d-4157-989b-63b0362aeee6'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''83f136c4-cb76-4029-88ab-5ab8f10c1532'',''0b183be9-c13d-4157-989b-63b0362aeee6'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_Attribute=''daf53cbc-2cb4-42ed-8722-ee85f6b33512'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''5f7a0238-859e-4eec-9f69-3038192cf56f'',''daf53cbc-2cb4-42ed-8722-ee85f6b33512'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''759bb22d-20b5-42ff-8079-813c2496946d'' AND GUID_Attribute=''0b183be9-c13d-4157-989b-63b0362aeee6'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''759bb22d-20b5-42ff-8079-813c2496946d'',''0b183be9-c13d-4157-989b-63b0362aeee6'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''3f7f258e-76b2-49ae-b5cc-25184f39899f'' AND GUID_Attribute=''0b183be9-c13d-4157-989b-63b0362aeee6'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''3f7f258e-76b2-49ae-b5cc-25184f39899f'',''0b183be9-c13d-4157-989b-63b0362aeee6'',1,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Attribute WHERE GUID_Type=''d88808d0-0473-4594-a8f9-6c4cb3439297'' AND GUID_Attribute=''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'')=0
	INSERT INTO semtbl_Type_Attribute VALUES(''d88808d0-0473-4594-a8f9-6c4cb3439297'',''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'',0,1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3617cfd1-c359-4da7-b306-1c1b780247bc'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''b57a0de7-25b7-4de2-964e-0fcf12346028'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3617cfd1-c359-4da7-b306-1c1b780247bc'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''b57a0de7-25b7-4de2-964e-0fcf12346028'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3617cfd1-c359-4da7-b306-1c1b780247bc'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''0330361a-c81b-4895-a0c9-498397059368'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3617cfd1-c359-4da7-b306-1c1b780247bc'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''0330361a-c81b-4895-a0c9-498397059368'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''3617cfd1-c359-4da7-b306-1c1b780247bc'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''54aebd25-9ade-45c7-9f23-cd3496e667d0'')=0
	INSERT INTO semtbl_Type_Type VALUES(''3617cfd1-c359-4da7-b306-1c1b780247bc'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''54aebd25-9ade-45c7-9f23-cd3496e667d0'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'' AND GUID_Type_Right=''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'' AND GUID_RelationType=''f77ee633-19d8-4ea6-947f-9fb6efad3547'')=0
	INSERT INTO semtbl_Type_Type VALUES(''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'',''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'',''f77ee633-19d8-4ea6-947f-9fb6efad3547'',0,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'' AND GUID_Type_Right=''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'' AND GUID_RelationType=''c9670b90-e5f0-4e30-a26d-ad3d6576ceac'')=0
	INSERT INTO semtbl_Type_Type VALUES(''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'',''a2d7d0fe-0495-4afe-85e1-1dcb88a27546'',''c9670b90-e5f0-4e30-a26d-ad3d6576ceac'',0,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_Type_Right=''d88808d0-0473-4594-a8f9-6c4cb3439297'' AND GUID_RelationType=''9996494a-ef6a-4357-a6ef-71a92b5ff596'')=0
	INSERT INTO semtbl_Type_Type VALUES(''5f7a0238-859e-4eec-9f69-3038192cf56f'',''d88808d0-0473-4594-a8f9-6c4cb3439297'',''9996494a-ef6a-4357-a6ef-71a92b5ff596'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''d88808d0-0473-4594-a8f9-6c4cb3439297'' AND GUID_Type_Right=''d88808d0-0473-4594-a8f9-6c4cb3439297'' AND GUID_RelationType=''5d8f540c-3e92-4999-a710-ce7f2dd611de'')=0
	INSERT INTO semtbl_Type_Type VALUES(''d88808d0-0473-4594-a8f9-6c4cb3439297'',''d88808d0-0473-4594-a8f9-6c4cb3439297'',''5d8f540c-3e92-4999-a710-ce7f2dd611de'',0,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''ac1b0479-188c-4e31-81f1-e3453fede26e'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''0330361a-c81b-4895-a0c9-498397059368'')=0
	INSERT INTO semtbl_Type_Type VALUES(''ac1b0479-188c-4e31-81f1-e3453fede26e'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''0330361a-c81b-4895-a0c9-498397059368'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Type_Type WHERE GUID_Type_Left=''ac1b0479-188c-4e31-81f1-e3453fede26e'' AND GUID_Type_Right=''5f7a0238-859e-4eec-9f69-3038192cf56f'' AND GUID_RelationType=''54aebd25-9ade-45c7-9f23-cd3496e667d0'')=0
	INSERT INTO semtbl_Type_Type VALUES(''ac1b0479-188c-4e31-81f1-e3453fede26e'',''5f7a0238-859e-4eec-9f69-3038192cf56f'',''54aebd25-9ade-45c7-9f23-cd3496e667d0'',1,1,-1)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute WHERE GUID_TokenAttribute=''8b6c6c54-202c-4170-82d9-000f18cb1f83'' )=0
	INSERT INTO semtbl_Token_Attribute VALUES(''8b6c6c54-202c-4170-82d9-000f18cb1f83'',''96d35b3b-b61a-482c-91bb-06dda6553cf3'',''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute WHERE GUID_TokenAttribute=''7e5adeca-9423-4369-bf9a-963c41a06433'' )=0
	INSERT INTO semtbl_Token_Attribute VALUES(''7e5adeca-9423-4369-bf9a-963c41a06433'',''389e95dd-9eda-4717-8c50-6e8dbc99b417'',''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute WHERE GUID_TokenAttribute=''1756f9c2-0aa3-4d11-bb2d-1db173c40134'' )=0
	INSERT INTO semtbl_Token_Attribute VALUES(''1756f9c2-0aa3-4d11-bb2d-1db173c40134'',''5cdf3708-8444-4b29-9323-c829e6494189'',''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute WHERE GUID_TokenAttribute=''95cea4ab-3e5e-4f3d-8d72-091a0c5fc469'' )=0
	INSERT INTO semtbl_Token_Attribute VALUES(''95cea4ab-3e5e-4f3d-8d72-091a0c5fc469'',''c08a41df-d9b0-40c0-8f55-3a8d3a24778e'',''b0b91f06-5c33-470b-8b1a-4c5c93d53ea2'')'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute_Real WHERE GUID_TokenAttribute=''8b6c6c54-202c-4170-82d9-000f18cb1f83'' )=0
	INSERT INTO semtbl_Token_Attribute_Real VALUES(''8b6c6c54-202c-4170-82d9-000f18cb1f83'',1073741824,0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute_Real WHERE GUID_TokenAttribute=''7e5adeca-9423-4369-bf9a-963c41a06433'' )=0
	INSERT INTO semtbl_Token_Attribute_Real VALUES(''7e5adeca-9423-4369-bf9a-963c41a06433'',1024,0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute_Real WHERE GUID_TokenAttribute=''1756f9c2-0aa3-4d11-bb2d-1db173c40134'' )=0
	INSERT INTO semtbl_Token_Attribute_Real VALUES(''1756f9c2-0aa3-4d11-bb2d-1db173c40134'',1048576,0)'
GO
execute dbo.sp_executesql @statement = N'IF (SELECT COUNT(*) FROM semtbl_Token_Attribute_Real WHERE GUID_TokenAttribute=''95cea4ab-3e5e-4f3d-8d72-091a0c5fc469'' )=0
	INSERT INTO semtbl_Token_Attribute_Real VALUES(''95cea4ab-3e5e-4f3d-8d72-091a0c5fc469'',1099511627776,0)'
GO
