CREATE DATABASE sem_db_tcp_organizationalTransaction_module
GO
use [sem_db_change]
use [sem_db_tcp_organizationalTransaction_module]
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Time]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_attribute_time] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_attribute_time]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Real]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Real] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Real]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_VARCHARMAX]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_VARCHARMAX] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_VARCHARMAX]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Bit]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Bit] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Bit]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Real]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Real] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Real]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_RelationType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_RelationType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_RelationType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Date]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Date] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Date]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_AttributeType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_AttributeType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_AttributeType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Bit]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Bit] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Bit]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Datetime]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_attribute_datetime] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_attribute_datetime]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Time]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Time] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Time]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Date]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Date] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Date]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type_Type]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type_Type] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type_Type]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Varchar255]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_varchar255] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_varchar255]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_RelationType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_RelationType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_RelationType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_ORType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_ORType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_ORType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Type_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Type_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Type_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_Int]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_Int] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_Int]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Datetime]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Datetime] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Datetime]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Varchar255]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Varchar255] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Varchar255]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token_Attribute_Int]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token_Attribute_Int] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token_Attribute_Int]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_AttributeType]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_AttributeType] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_AttributeType]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Type_Attribute]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Type_Attribute] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Type_Attribute]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_OR_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_OR_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_OR_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Token]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Token] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Token]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[semtbl_Token_Attribute_VarcharMax]') AND type='SN')
BEGIN
execute dbo.sp_executesql @statement = N'CREATE SYNONYM [dbo].[semtbl_Token_Attribute_varcharMAX] FOR [TCP\SQLEXPRESS].[sem_db_tcp].[dbo].[semtbl_Token_Attribute_varcharMAX]'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_db_postfix]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_db_postfix]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''db_postfix'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_partner_of]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_partner_of]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is partner of'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Menge]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Menge] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Menge		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Menge, Name_Token AS Name_Menge, GUID_Type AS GUID_Type_Menge

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Menge)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_x]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_x]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''x'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Fl_che]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Fl_che]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Fläche'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Menge]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Menge]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Menge'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Partner]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Partner] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Partner		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Partner, Name_Token AS Name_Partner, GUID_Type AS GUID_Type_Partner

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Partner)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Partner]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Partner]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Partner'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_z]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_z]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''z'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_Base]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_Base]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''Base'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Einheit]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Einheit]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Einheit'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_contact]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_contact]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''contact'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Type_Volumen]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_Type_Volumen]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	DECLARE @GUID_Type			uniqueidentifier;

	DECLARE @Name_Type			varchar(255);



	SET @Name_Type = ''Volumen'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_Type = (SELECT GUID_Type FROM semtbl_Type WHERE Name_Type=@Name_Type);



	-- Return the result of the function

	RETURN @GUID_Type



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_factor]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_factor]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''factor'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_y]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_y]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''y'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Einheit]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Einheit] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Einheit		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Einheit, Name_Token AS Name_Einheit, GUID_Type AS GUID_Type_Einheit

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Einheit)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Volumen]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Volumen] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Volumen		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Volumen, Name_Token AS Name_Volumen, GUID_Type AS GUID_Type_Volumen

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Volumen)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Token_Fl_che]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[func_Token_Fl_che] 

(	

	-- Add the parameters for the function here

	@GUID_Type_Fl_che		uniqueidentifier

)

RETURNS TABLE 

AS

RETURN 

(

	-- Add the SELECT statement with parameter references here

	SELECT     GUID_Token AS GUID_Fl_che, Name_Token AS Name_Fl_che, GUID_Type AS GUID_Type_Fl_che

FROM         semtbl_Token

WHERE     (GUID_Type = @GUID_Type_Fl_che)

)'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_RelationType_is_of_Type]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_RelationType_is_of_Type]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_RelationType			uniqueidentifier;

	DECLARE @Name_RelationType			varchar(255);



	SET @Name_RelationType = ''is of Type'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_RelationType = (SELECT GUID_RelationType FROM semtbl_RelationType WHERE Name_RelationType=@Name_RelationType);



	-- Return the result of the function

	RETURN @GUID_RelationType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_AttributeType_Menge]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'CREATE FUNCTION [dbo].[dbg_AttributeType_Menge]

(

	-- Add the parameters for the function here

	

)

RETURNS uniqueidentifier

AS

BEGIN

	-- Declare the return variable here

	DECLARE @GUID_AttributeType			uniqueidentifier;

	DECLARE @Name_AttributeType			varchar(255);



	SET @Name_AttributeType = ''Menge'';

	-- Add the T-SQL statements to compute the return value here

	SET @GUID_AttributeType = (SELECT GUID_Attribute FROM semtbl_Attribute WHERE Name_Attribute=@Name_AttributeType);



	-- Return the result of the function

	RETURN @GUID_AttributeType



END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Menge_By_GUID]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION [dbo].[func_Menge_By_GUID] 

(	

	-- Add the parameters for the function here

	 @GUID_Attribute_Menge			uniqueidentifier

	,@GUID_Type_Menge				uniqueidentifier

	,@GUID_Type_Einheit				uniqueidentifier

	,@GUID_RelationType_IsOfType	uniqueidentifier

	,@GUID_Menge					uniqueidentifier = null

)

RETURNS @tmp_Menge TABLE

(

	 GUID_Menge					uniqueidentifier

	,Name_Menge					varchar(255)

	,GUID_Type_Menge			uniqueidentifier

	,GUID_Einheit				uniqueidentifier

	,Name_Einheit				varchar(255)

	,GUID_Type_Einheit			uniqueidentifier

	,GUID_TokenAttribute_Menge	uniqueidentifier

	,Menge						real

) 

AS

BEGIN

	-- Add the SELECT statement with parameter references here

	IF @GUID_Menge IS NULL

	BEGIN

		INSERT INTO @tmp_Menge

		SELECT     func_Token_Menge_1.GUID_Menge, 

					func_Token_Menge_1.Name_Menge, 

					func_Token_Menge_1.GUID_Type_Menge, 

					func_Token_Einheit_1.GUID_Einheit, 

					func_Token_Einheit_1.Name_Einheit, 

					func_Token_Einheit_1.GUID_Type_Einheit, 

					Menge__Menge_Val.GUID_TokenAttribute AS GUID_TokenAttribute_Menge, 

					Menge__Menge_Val.val AS Menge

			FROM         dbo.func_Token_Menge(@GUID_Type_Menge) AS func_Token_Menge_1 INNER JOIN

								  semtbl_Token_Token AS Menge_To_Einheit ON func_Token_Menge_1.GUID_Menge = Menge_To_Einheit.GUID_Token_Left INNER JOIN

								  dbo.func_Token_Einheit(@GUID_Type_Einheit) AS func_Token_Einheit_1 ON Menge_To_Einheit.GUID_Token_Right = func_Token_Einheit_1.GUID_Einheit INNER JOIN

								  semtbl_Token_Attribute AS Menge__Menge ON func_Token_Menge_1.GUID_Menge = Menge__Menge.GUID_Token INNER JOIN

								  semtbl_Token_Attribute_Real AS Menge__Menge_Val ON Menge__Menge.GUID_TokenAttribute = Menge__Menge_Val.GUID_TokenAttribute

			WHERE     (Menge_To_Einheit.GUID_RelationType = @GUID_RelationType_IsOfType) AND 

								  (Menge__Menge.GUID_Attribute = @GUID_Attribute_Menge)

	END

	ELSE

	BEGIN

		INSERT INTO @tmp_Menge

		SELECT     func_Token_Menge_1.GUID_Menge, func_Token_Menge_1.Name_Menge, func_Token_Menge_1.GUID_Type_Menge, func_Token_Einheit_1.GUID_Einheit, 

						  func_Token_Einheit_1.Name_Einheit, func_Token_Einheit_1.GUID_Type_Einheit, Menge__Menge_Val.GUID_TokenAttribute AS GUID_TokenAttribute_Menge, 

						  Menge__Menge_Val.val AS Menge

			FROM         dbo.func_Token_Menge(@GUID_Type_Menge) AS func_Token_Menge_1 INNER JOIN

								  semtbl_Token_Token AS Menge_To_Einheit ON func_Token_Menge_1.GUID_Menge = Menge_To_Einheit.GUID_Token_Left INNER JOIN

								  dbo.func_Token_Einheit(@GUID_Type_Einheit) AS func_Token_Einheit_1 ON Menge_To_Einheit.GUID_Token_Right = func_Token_Einheit_1.GUID_Einheit INNER JOIN

								  semtbl_Token_Attribute AS Menge__Menge ON func_Token_Menge_1.GUID_Menge = Menge__Menge.GUID_Token INNER JOIN

								  semtbl_Token_Attribute_Real AS Menge__Menge_Val ON Menge__Menge.GUID_TokenAttribute = Menge__Menge_Val.GUID_TokenAttribute

			WHERE     (func_Token_Menge_1.GUID_Menge = @GUID_Menge) AND (Menge_To_Einheit.GUID_RelationType = @GUID_RelationType_IsOfType) AND 

								  (Menge__Menge.GUID_Attribute = @GUID_Attribute_Menge)

	END



	RETURN	

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Menge_By_Val_Einheit]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Descripti,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Menge_By_Val_Einheit]

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_Menge			uniqueidentifier

	,@GUID_Type_Menge				uniqueidentifier

	,@GUID_Type_Einheit				uniqueidentifier

	,@GUID_RelationType_isOfType	uniqueidentifier

	,@Name_Einheit					varchar(255)

	,@real_Menge					real

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT     func_Token_Menge_1.GUID_Menge, func_Token_Menge_1.Name_Menge, func_Token_Menge_1.GUID_Type_Menge

FROM         dbo.func_Token_Menge(@GUID_Type_Menge) AS func_Token_Menge_1 INNER JOIN

                      semtbl_Token_Token AS Menge_To_Einheit ON func_Token_Menge_1.GUID_Menge = Menge_To_Einheit.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Einheit(@GUID_Type_Einheit) AS func_Token_Einheit_1 ON Menge_To_Einheit.GUID_Token_Right = func_Token_Einheit_1.GUID_Einheit INNER JOIN

                      semtbl_Token_Attribute AS Menge__Menge ON func_Token_Menge_1.GUID_Menge = Menge__Menge.GUID_Token INNER JOIN

                      semtbl_Token_Attribute_Real AS Menge__Menge_Val ON Menge__Menge.GUID_TokenAttribute = Menge__Menge_Val.GUID_TokenAttribute

WHERE     (Menge_To_Einheit.GUID_RelationType = @GUID_RelationType_isOfType) AND (func_Token_Einheit_1.Name_Einheit = @Name_Einheit) AND 

                      (Menge__Menge.GUID_Attribute = @GUID_Attribute_Menge) AND (Menge__Menge_Val.val = @real_Menge)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Menge_By_Val_Einheit]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Descripti,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Menge_By_Val_Einheit]

	-- Add the parameters for the stored procedure here

	 

	 @Name_Einheit					varchar(255)

	,@real_Menge					real

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Attribute_Menge			uniqueidentifier

	DECLARE @GUID_Type_Menge				uniqueidentifier

	DECLARE @GUID_Type_Einheit				uniqueidentifier

	DECLARE @GUID_RelationType_isOfType		uniqueidentifier

	

	SET @GUID_Attribute_Menge			= dbo.dbg_AttributeType_Menge()

	SET @GUID_Type_Menge				= dbo.dbg_Type_Menge()

	SET @GUID_Type_Einheit				= dbo.dbg_Type_Einheit()

	SET @GUID_RelationType_isOfType		= dbo.dbg_RelationType_is_of_Type()

	

	PRINT @GUID_Attribute_Menge			

	PRINT @GUID_Type_Menge				

	PRINT @GUID_Type_Einheit			

	PRINT @GUID_RelationType_isOfType	

	

    -- Insert statements for procedure here

	SELECT     func_Token_Menge_1.GUID_Menge, func_Token_Menge_1.Name_Menge, func_Token_Menge_1.GUID_Type_Menge

FROM         dbo.func_Token_Menge(@GUID_Type_Menge) AS func_Token_Menge_1 INNER JOIN

                      semtbl_Token_Token AS Menge_To_Einheit ON func_Token_Menge_1.GUID_Menge = Menge_To_Einheit.GUID_Token_Left INNER JOIN

                      dbo.func_Token_Einheit(@GUID_Type_Einheit) AS func_Token_Einheit_1 ON Menge_To_Einheit.GUID_Token_Right = func_Token_Einheit_1.GUID_Einheit INNER JOIN

                      semtbl_Token_Attribute AS Menge__Menge ON func_Token_Menge_1.GUID_Menge = Menge__Menge.GUID_Token INNER JOIN

                      semtbl_Token_Attribute_Real AS Menge__Menge_Val ON Menge__Menge.GUID_TokenAttribute = Menge__Menge_Val.GUID_TokenAttribute

WHERE     (Menge_To_Einheit.GUID_RelationType = @GUID_RelationType_isOfType) AND (func_Token_Einheit_1.Name_Einheit = @Name_Einheit) AND 

                      (Menge__Menge.GUID_Attribute = @GUID_Attribute_Menge) AND (Menge__Menge_Val.val = @real_Menge)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Menge_By_GUID]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Menge_By_GUID] 

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_Menge			uniqueidentifier

	,@GUID_Type_Menge				uniqueidentifier

	,@GUID_Type_Einheit				uniqueidentifier

	,@GUID_RelationType_IsOfType	uniqueidentifier

	,@GUID_Menge					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM dbo.func_Menge_By_GUID(

		 @GUID_Attribute_Menge

		,@GUID_Type_Menge

		,@GUID_Type_Einheit

		,@GUID_RelationType_IsOfType

		,@GUID_Menge)

	

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[func_Flaechen]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE FUNCTION [dbo].[func_Flaechen] 

(	

	-- Add the parameters for the function here

	 @GUID_Attribute_Menge			uniqueidentifier

	,@GUID_Type_Menge				uniqueidentifier

	,@GUID_Type_Einheit				uniqueidentifier

	,@GUID_Type_Flaeche				uniqueidentifier

	,@GUID_RelationType_IsOfType	uniqueidentifier

	,@GUID_RelationType_X			uniqueidentifier

	,@GUID_RelationType_Y			uniqueidentifier

	,@GUID_Menge_X					uniqueidentifier = null

	,@GUID_Menge_Y					uniqueidentifier = null

)

RETURNS @tmp_Flaechen TABLE

(

	 GUID_Menge_X					uniqueidentifier

	,Name_Menge_X					varchar(255)

	,GUID_Type_Menge_X				uniqueidentifier

	,GUID_einheit_X					uniqueidentifier

	,Name_Einheit_X					varchar(255)

	,GUID_Type_Einhiet_X			uniqueidentifier

	,GUID_TokenAttribute_Menge_X	uniqueidentifier

	,Menge_X						real

	,GUID_Menge_Y					uniqueidentifier

	,Name_Menge_Y					varchar(255)

	,GUID_Type_Menge_Y				uniqueidentifier

	,GUID_einheit_Y					uniqueidentifier

	,Name_Einheit_Y					varchar(255)

	,GUID_Type_Einheit_Y			uniqueidentifier

	,GUID_TokenAttribute_Menge_Y	uniqueidentifier

	,Menge_Y						real

	,GUID_Flaeche					uniqueidentifier

	,Name_Flaeche					varchar(255)

	,GUID_Type_Flaeche				uniqueidentifier

	,Flaeche						numeric(25,4)

) 

AS

BEGIN

	-- Add the SELECT statement with parameter references here

	IF @GUID_Menge_X IS NULL

	BEGIN

		INSERT INTO @tmp_Flaechen

		SELECT     func_Menge_By_GUID_X.GUID_Menge AS GUID_Menge_X, 

					func_Menge_By_GUID_X.Name_Menge AS Name_Menge_X, 

					func_Menge_By_GUID_X.GUID_Type_Menge AS GUID_Type_Menge_X, 

					func_Menge_By_GUID_X.GUID_Einheit AS GUID_Einheit_X, 

					func_Menge_By_GUID_X.Name_Einheit AS Name_Einheit_X, 

					func_Menge_By_GUID_X.GUID_Type_Einheit AS GUID_Type_Einheit_X, 

					func_Menge_By_GUID_X.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_X, 

					func_Menge_By_GUID_X.Menge AS Menge_X, 

					func_Menge_By_GUID_Y.GUID_Menge AS GUID_Menge_Y, 

					func_Menge_By_GUID_Y.Name_Menge AS Name_Menge_Y, 

					func_Menge_By_GUID_Y.GUID_Type_Menge AS GUID_Type_Menge_Y, 

					func_Menge_By_GUID_Y.GUID_Einheit AS GUID_Einheit_Y, 

					func_Menge_By_GUID_Y.Name_Einheit AS Name_Einheit_Y, 

					func_Menge_By_GUID_Y.GUID_Type_Einheit AS GUID_Type_Einheit_Y, 

					func_Menge_By_GUID_Y.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_Y, 

					func_Menge_By_GUID_Y.Menge AS Menge_Y, 

					func_Token_Fl_che_1.GUID_Fl_che, 

					func_Token_Fl_che_1.Name_Fl_che, 

					func_Token_Fl_che_1.GUID_Type_Fl_che, 

					CAST(func_Menge_By_GUID_X.Menge * func_Menge_By_GUID_Y.Menge AS NUMERIC(25,4))AS Flaeche

			FROM         semtbl_Token_Token AS Flaeche_To_MengeY INNER JOIN

								  dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_x) 

								  AS func_Menge_By_GUID_X INNER JOIN

								  semtbl_Token_Token AS Flaeche_To_MengeX INNER JOIN

								  dbo.func_Token_Fl_che(@GUID_Type_Flaeche) AS func_Token_Fl_che_1 ON Flaeche_To_MengeX.GUID_Token_Left = func_Token_Fl_che_1.GUID_Fl_che ON 

								  func_Menge_By_GUID_X.GUID_Menge = Flaeche_To_MengeX.GUID_Token_Right ON 

								  Flaeche_To_MengeY.GUID_Token_Left = func_Token_Fl_che_1.GUID_Fl_che INNER JOIN

								  dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_Y) 

								  AS func_Menge_By_GUID_Y ON Flaeche_To_MengeY.GUID_Token_Right = func_Menge_By_GUID_Y.GUID_Menge

			WHERE     (Flaeche_To_MengeX.GUID_RelationType = @GUID_RelationType_X) AND (Flaeche_To_MengeY.GUID_RelationType = @GUID_RelationType_Y)

	END

	ELSE

	BEGIN

		INSERT INTO @tmp_Flaechen

		SELECT     func_Menge_By_GUID_X.GUID_Menge AS GUID_Menge_X, 

					func_Menge_By_GUID_X.Name_Menge AS Name_Menge_X, 

					func_Menge_By_GUID_X.GUID_Type_Menge AS GUID_Type_Menge_X, 

					func_Menge_By_GUID_X.GUID_Einheit AS GUID_Einheit_X, 

					func_Menge_By_GUID_X.Name_Einheit AS Name_Einheit_X, 

					func_Menge_By_GUID_X.GUID_Type_Einheit AS GUID_Type_Einheit_X, 

					func_Menge_By_GUID_X.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_X, 

					func_Menge_By_GUID_X.Menge AS Menge_X, 

					func_Menge_By_GUID_Y.GUID_Menge AS GUID_Menge_Y, 

					func_Menge_By_GUID_Y.Name_Menge AS Name_Menge_Y, 

					func_Menge_By_GUID_Y.GUID_Type_Menge AS GUID_Type_Menge_Y, 

					func_Menge_By_GUID_Y.GUID_Einheit AS GUID_Einheit_Y, 

					func_Menge_By_GUID_Y.Name_Einheit AS Name_Einheit_Y, 

					func_Menge_By_GUID_Y.GUID_Type_Einheit AS GUID_Type_Einheit_Y, 

					func_Menge_By_GUID_Y.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_Y, 

					func_Menge_By_GUID_Y.Menge AS Menge_Y, 

					func_Token_Fl_che_1.GUID_Fl_che, 

					func_Token_Fl_che_1.Name_Fl_che, 

					func_Token_Fl_che_1.GUID_Type_Fl_che, 

					CAST(func_Menge_By_GUID_X.Menge * func_Menge_By_GUID_Y.Menge AS NUMERIC(25,4))AS Flaeche

			FROM         semtbl_Token_Token AS Flaeche_To_MengeY INNER JOIN

								  dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_x) 

								  AS func_Menge_By_GUID_X INNER JOIN

								  semtbl_Token_Token AS Flaeche_To_MengeX INNER JOIN

								  dbo.func_Token_Fl_che(@GUID_Type_Flaeche) AS func_Token_Fl_che_1 ON Flaeche_To_MengeX.GUID_Token_Left = func_Token_Fl_che_1.GUID_Fl_che ON 

								  func_Menge_By_GUID_X.GUID_Menge = Flaeche_To_MengeX.GUID_Token_Right ON 

								  Flaeche_To_MengeY.GUID_Token_Left = func_Token_Fl_che_1.GUID_Fl_che INNER JOIN

								  dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_Y) 

								  AS func_Menge_By_GUID_Y ON Flaeche_To_MengeY.GUID_Token_Right = func_Menge_By_GUID_Y.GUID_Menge

			WHERE     (Flaeche_To_MengeX.GUID_RelationType = @GUID_RelationType_X) AND (Flaeche_To_MengeY.GUID_RelationType = @GUID_RelationType_Y) AND 

								  (func_Menge_By_GUID_X.GUID_Menge = @GUID_Menge_x) AND (func_Menge_By_GUID_Y.GUID_Menge = @GUID_Menge_Y)

	END

	

	

	RETURN

END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Menge]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Menge] 

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_Menge			uniqueidentifier

	,@GUID_Type_Menge				uniqueidentifier

	,@GUID_Type_Einheit				uniqueidentifier

	,@GUID_RelationType_IsOfType	uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM dbo.func_Menge_By_GUID(

		 @GUID_Attribute_Menge

		,@GUID_Type_Menge

		,@GUID_Type_Einheit

		,@GUID_RelationType_IsOfType

		,DEFAULT)

		ORDER BY Menge

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Volumen_By_Mengen]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Volumen_By_Mengen] 

	-- Add the parameters for the stored procedure here

	 

	 @GUID_Menge_X					uniqueidentifier

	,@GUID_Menge_Y					uniqueidentifier

	,@GUID_Menge_Z					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

	DECLARE @GUID_Attribute_Menge			uniqueidentifier

	DECLARE @GUID_Type_Menge				uniqueidentifier

	DECLARE @GUID_Type_Einheit				uniqueidentifier

	DECLARE @GUID_Type_Volumen				uniqueidentifier

	DECLARE @GUID_RelationType_IsOfType		uniqueidentifier

	DECLARE @GUID_RelationType_X			uniqueidentifier

	DECLARE @GUID_RelationType_Y			uniqueidentifier

	DECLARE @GUID_RelationType_Z			uniqueidentifier

	

	SET @GUID_Attribute_Menge			= dbo.dbg_AttributeType_Menge()

	SET @GUID_Type_Menge				= dbo.dbg_Type_Menge()

	SET @GUID_Type_Einheit				= dbo.dbg_Type_Einheit()

	SET @GUID_Type_Volumen				= dbo.dbg_Type_Volumen()

	SET @GUID_RelationType_IsOfType		= dbo.dbg_RelationType_is_of_Type()

	SET @GUID_RelationType_X			= dbo.dbg_RelationType_x()

	SET @GUID_RelationType_Y			= dbo.dbg_RelationType_y()

	SET @GUID_RelationType_Z			= dbo.dbg_RelationType_Z()

	

	PRINT @GUID_Attribute_Menge			

	PRINT @GUID_Type_Menge				

	PRINT @GUID_Type_Einheit			

	PRINT @GUID_Type_Volumen			

	PRINT @GUID_RelationType_IsOfType		

	PRINT @GUID_RelationType_X			

	PRINT @GUID_RelationType_Y			

	PRINT @GUID_RelationType_Z			



    -- Insert statements for procedure here

	SELECT     func_Menge_By_GUID_X.GUID_Menge AS GUID_Menge_X, func_Menge_By_GUID_X.Name_Menge AS Name_Menge_X, 

                      func_Menge_By_GUID_X.GUID_Type_Menge AS GUID_Type_Menge_X, func_Menge_By_GUID_X.GUID_Einheit AS GUID_Einheit_X, 

                      func_Menge_By_GUID_X.Name_Einheit AS Name_Einheit_X, func_Menge_By_GUID_X.GUID_Type_Einheit AS GUID_Type_Einheit_X, 

                      func_Menge_By_GUID_X.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_X, func_Menge_By_GUID_X.Menge AS Menge_X, 

                      func_Menge_By_GUID_Y.GUID_Menge AS GUID_Menge_Y, func_Menge_By_GUID_Y.Name_Menge AS Name_Menge_Y, 

                      func_Menge_By_GUID_Y.GUID_Type_Menge AS GUID_Type_Menge_Y, func_Menge_By_GUID_Y.GUID_Einheit AS GUID_Einheit_Y, 

                      func_Menge_By_GUID_Y.Name_Einheit AS Name_Einheit_Y, func_Menge_By_GUID_Y.GUID_Type_Einheit AS GUID_Type_Einheit_Y, 

                      func_Menge_By_GUID_Y.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_Y, func_Menge_By_GUID_Y.Menge AS Menge_Y, 

                      func_Menge_By_GUID_Z.GUID_Menge AS GUID_Menge_Z, func_Menge_By_GUID_Z.Name_Menge AS Name_Menge_Z, 

                      func_Menge_By_GUID_Z.GUID_Type_Menge AS GUID_Type_Menge_Z, func_Menge_By_GUID_Z.GUID_Einheit AS GUID_Einheit_Z, 

                      func_Menge_By_GUID_Z.Name_Einheit AS Name_Einheit_Z, func_Menge_By_GUID_Z.GUID_Type_Einheit AS GUID_Type_Einheit_Z, 

                      func_Menge_By_GUID_Z.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_Z, func_Menge_By_GUID_Z.Menge AS Menge_Z, 

                      func_Token_Volumen_1.GUID_Volumen, func_Token_Volumen_1.Name_Volumen, func_Token_Volumen_1.GUID_Type_Volumen, 

                      func_Menge_By_GUID_X.Menge * func_Menge_By_GUID_Y.Menge * func_Menge_By_GUID_Z.Menge AS Volumen

FROM         semtbl_Token_Token AS Volumen_To_Menge_Z INNER JOIN

                      dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_Z) 

                      AS func_Menge_By_GUID_Z ON Volumen_To_Menge_Z.GUID_Token_Right = func_Menge_By_GUID_Z.GUID_Menge INNER JOIN

                      dbo.func_Token_Volumen(@GUID_Type_Volumen) AS func_Token_Volumen_1 INNER JOIN

                      dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_x) 

                      AS func_Menge_By_GUID_X INNER JOIN

                      semtbl_Token_Token AS Volumen_To_MengeX ON func_Menge_By_GUID_X.GUID_Menge = Volumen_To_MengeX.GUID_Token_Right ON 

                      func_Token_Volumen_1.GUID_Volumen = Volumen_To_MengeX.GUID_Token_Left INNER JOIN

                      semtbl_Token_Token AS Volumen_To_MengeY INNER JOIN

                      dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_Y) 

                      AS func_Menge_By_GUID_Y ON Volumen_To_MengeY.GUID_Token_Right = func_Menge_By_GUID_Y.GUID_Menge ON 

                      func_Token_Volumen_1.GUID_Volumen = Volumen_To_MengeY.GUID_Token_Left ON 

                      Volumen_To_Menge_Z.GUID_Token_Left = func_Token_Volumen_1.GUID_Volumen

WHERE     (Volumen_To_MengeX.GUID_RelationType = @GUID_RelationType_X) AND (Volumen_To_MengeY.GUID_RelationType = @GUID_RelationType_Y) AND 

                      (func_Menge_By_GUID_X.GUID_Menge = @GUID_Menge_x) AND (func_Menge_By_GUID_Y.GUID_Menge = @GUID_Menge_Y) AND 

                      (Volumen_To_Menge_Z.GUID_RelationType = @GUID_RelationType_Z)

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Volumen_By_Mengen]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'

-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Volumen_By_Mengen] 

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_Menge			uniqueidentifier

	,@GUID_Type_Menge				uniqueidentifier

	,@GUID_Type_Einheit				uniqueidentifier

	,@GUID_Type_Volumen				uniqueidentifier

	,@GUID_RelationType_IsOfType	uniqueidentifier

	,@GUID_RelationType_X			uniqueidentifier

	,@GUID_RelationType_Y			uniqueidentifier

	,@GUID_RelationType_Z			uniqueidentifier

	,@GUID_Menge_X					uniqueidentifier

	,@GUID_Menge_Y					uniqueidentifier

	,@GUID_Menge_Z					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

    -- Insert statements for procedure here

	SELECT     func_Menge_By_GUID_X.GUID_Menge AS GUID_Menge_X, func_Menge_By_GUID_X.Name_Menge AS Name_Menge_X, 

                      func_Menge_By_GUID_X.GUID_Type_Menge AS GUID_Type_Menge_X, func_Menge_By_GUID_X.GUID_Einheit AS GUID_Einheit_X, 

                      func_Menge_By_GUID_X.Name_Einheit AS Name_Einheit_X, func_Menge_By_GUID_X.GUID_Type_Einheit AS GUID_Type_Einheit_X, 

                      func_Menge_By_GUID_X.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_X, func_Menge_By_GUID_X.Menge AS Menge_X, 

                      func_Menge_By_GUID_Y.GUID_Menge AS GUID_Menge_Y, func_Menge_By_GUID_Y.Name_Menge AS Name_Menge_Y, 

                      func_Menge_By_GUID_Y.GUID_Type_Menge AS GUID_Type_Menge_Y, func_Menge_By_GUID_Y.GUID_Einheit AS GUID_Einheit_Y, 

                      func_Menge_By_GUID_Y.Name_Einheit AS Name_Einheit_Y, func_Menge_By_GUID_Y.GUID_Type_Einheit AS GUID_Type_Einheit_Y, 

                      func_Menge_By_GUID_Y.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_Y, func_Menge_By_GUID_Y.Menge AS Menge_Y, 

                      func_Menge_By_GUID_Z.GUID_Menge AS GUID_Menge_Z, func_Menge_By_GUID_Z.Name_Menge AS Name_Menge_Z, 

                      func_Menge_By_GUID_Z.GUID_Type_Menge AS GUID_Type_Menge_Z, func_Menge_By_GUID_Z.GUID_Einheit AS GUID_Einheit_Z, 

                      func_Menge_By_GUID_Z.Name_Einheit AS Name_Einheit_Z, func_Menge_By_GUID_Z.GUID_Type_Einheit AS GUID_Type_Einheit_Z, 

                      func_Menge_By_GUID_Z.GUID_TokenAttribute_Menge AS GUID_TokenAttribute_Menge_Z, func_Menge_By_GUID_Z.Menge AS Menge_Z, 

                      func_Token_Volumen_1.GUID_Volumen, func_Token_Volumen_1.Name_Volumen, func_Token_Volumen_1.GUID_Type_Volumen, 

                      func_Menge_By_GUID_X.Menge * func_Menge_By_GUID_Y.Menge * func_Menge_By_GUID_Z.Menge AS Volumen

FROM         semtbl_Token_Token AS Volumen_To_Menge_Z INNER JOIN

                      dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_Z) 

                      AS func_Menge_By_GUID_Z ON Volumen_To_Menge_Z.GUID_Token_Right = func_Menge_By_GUID_Z.GUID_Menge INNER JOIN

                      dbo.func_Token_Volumen(@GUID_Type_Volumen) AS func_Token_Volumen_1 INNER JOIN

                      dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_x) 

                      AS func_Menge_By_GUID_X INNER JOIN

                      semtbl_Token_Token AS Volumen_To_MengeX ON func_Menge_By_GUID_X.GUID_Menge = Volumen_To_MengeX.GUID_Token_Right ON 

                      func_Token_Volumen_1.GUID_Volumen = Volumen_To_MengeX.GUID_Token_Left INNER JOIN

                      semtbl_Token_Token AS Volumen_To_MengeY INNER JOIN

                      dbo.func_Menge_By_GUID(@GUID_Attribute_Menge, @GUID_Type_Menge, @GUID_Type_Einheit, @GUID_RelationType_IsOfType, @GUID_Menge_Y) 

                      AS func_Menge_By_GUID_Y ON Volumen_To_MengeY.GUID_Token_Right = func_Menge_By_GUID_Y.GUID_Menge ON 

                      func_Token_Volumen_1.GUID_Volumen = Volumen_To_MengeY.GUID_Token_Left ON 

                      Volumen_To_Menge_Z.GUID_Token_Left = func_Token_Volumen_1.GUID_Volumen

WHERE     (Volumen_To_MengeX.GUID_RelationType = @GUID_RelationType_X) AND (Volumen_To_MengeY.GUID_RelationType = @GUID_RelationType_Y) AND 

                      (func_Menge_By_GUID_X.GUID_Menge = @GUID_Menge_x) AND (func_Menge_By_GUID_Y.GUID_Menge = @GUID_Menge_Y) AND 

                      (Volumen_To_Menge_Z.GUID_RelationType = @GUID_RelationType_Z)

END


'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Menge]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Menge] 

	-- Add the parameters for the stored procedure here

	 

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Attribute_Menge			uniqueidentifier

	DECLARE @GUID_Type_Menge				uniqueidentifier

	DECLARE @GUID_Type_Einheit				uniqueidentifier

	DECLARE @GUID_RelationType_IsOfType	uniqueidentifier

	

	SET @GUID_Attribute_Menge			= dbo.dbg_AttributeType_Menge()

	SET @GUID_Type_Menge				= dbo.dbg_Type_Menge()

	SET @GUID_Type_Einheit				= dbo.dbg_Type_Einheit()

	SET @GUID_RelationType_IsOfType		= dbo.dbg_RelationType_is_of_Type()

	

	PRINT @GUID_Attribute_Menge			

	PRINT @GUID_Type_Menge				

	PRINT @GUID_Type_Einheit			

	PRINT @GUID_RelationType_IsOfType	

	

    -- Insert statements for procedure here

	SELECT * FROM dbo.func_Menge_By_GUID(

		 @GUID_Attribute_Menge

		,@GUID_Type_Menge

		,@GUID_Type_Einheit

		,@GUID_RelationType_IsOfType

		,DEFAULT)

		ORDER BY Name_Menge

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Menge_By_GUID]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Menge_By_GUID] 

	-- Add the parameters for the stored procedure here

	 

	@GUID_Menge					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Attribute_Menge			uniqueidentifier

	DECLARE @GUID_Type_Menge				uniqueidentifier

	DECLARE @GUID_Type_Einheit				uniqueidentifier

	DECLARE @GUID_RelationType_IsOfType	uniqueidentifier

	

	SET @GUID_Attribute_Menge			= dbo.dbg_AttributeType_Menge()

	SET @GUID_Type_Menge				= dbo.dbg_Type_Menge()

	SET @GUID_Type_Einheit				= dbo.dbg_Type_Einheit()

	SET @GUID_RelationType_IsOfType		= dbo.dbg_RelationType_is_of_Type()

	

	PRINT @GUID_Attribute_Menge			

	PRINT @GUID_Type_Menge				

	PRINT @GUID_Type_Einheit			

	PRINT @GUID_RelationType_IsOfType	

    -- Insert statements for procedure here

	SELECT * FROM dbo.func_Menge_By_GUID(

		 @GUID_Attribute_Menge

		,@GUID_Type_Menge

		,@GUID_Type_Einheit

		,@GUID_RelationType_IsOfType

		,@GUID_Menge)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Flaeche_By_Mengen]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Flaeche_By_Mengen] 

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_Menge			uniqueidentifier

	,@GUID_Type_Menge				uniqueidentifier

	,@GUID_Type_Einheit				uniqueidentifier

	,@GUID_Type_Flaeche				uniqueidentifier

	,@GUID_RelationType_IsOfType	uniqueidentifier

	,@GUID_RelationType_X			uniqueidentifier

	,@GUID_RelationType_Y			uniqueidentifier

	,@GUID_Menge_X					uniqueidentifier

	,@GUID_Menge_Y					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM dbo.func_Flaechen(

		 @GUID_Attribute_Menge			

		,@GUID_Type_Menge				

		,@GUID_Type_Einheit				

		,@GUID_Type_Flaeche				

		,@GUID_RelationType_IsOfType	

		,@GUID_RelationType_X			

		,@GUID_RelationType_Y			

		,@GUID_Menge_X					

		,@GUID_Menge_Y)

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Flaechen]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Flaechen]

	-- Add the parameters for the stored procedure here

	 

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



	DECLARE @GUID_Attribute_Menge			uniqueidentifier

	DECLARE @GUID_Type_Menge				uniqueidentifier

	DECLARE @GUID_Type_Einheit				uniqueidentifier

	DECLARE @GUID_Type_Flaeche				uniqueidentifier

	DECLARE @GUID_RelationType_IsOfType	uniqueidentifier

	DECLARE @GUID_RelationType_X			uniqueidentifier

	DECLARE @GUID_RelationType_Y			uniqueidentifier

	

	SET @GUID_Attribute_Menge			= dbo.dbg_AttributeType_Menge()

	SET @GUID_Type_Menge				= dbo.dbg_Type_Menge()

	SET @GUID_Type_Einheit				= dbo.dbg_Type_Einheit()

	SET @GUID_Type_Flaeche				= dbo.dbg_Type_Fl_che()

	SET @GUID_RelationType_IsOfType		= dbo.dbg_RelationType_is_of_Type()

	SET @GUID_RelationType_X			= dbo.dbg_RelationType_x()

	SET @GUID_RelationType_Y			= dbo.dbg_RelationType_y()

	

	PRINT @GUID_Attribute_Menge			

	PRINT @GUID_Type_Menge				

	PRINT @GUID_Type_Einheit			

	PRINT @GUID_Type_Flaeche			

	PRINT @GUID_RelationType_IsOfType	

	PRINT @GUID_RelationType_X			

	PRINT @GUID_RelationType_Y			



    -- Insert statements for procedure here

	SELECT * FROM dbo.func_Flaechen(

		 @GUID_Attribute_Menge			

		,@GUID_Type_Menge				

		,@GUID_Type_Einheit				

		,@GUID_Type_Flaeche				

		,@GUID_RelationType_IsOfType	

		,@GUID_RelationType_X			

		,@GUID_RelationType_Y			

		,DEFAULT					

		,DEFAULT)

		ORDER BY Name_Flaeche

END
'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dbg_Flaeche_By_Mengen]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[dbg_Flaeche_By_Mengen] 

	-- Add the parameters for the stored procedure here

	 

	 @GUID_Menge_X					uniqueidentifier

	,@GUID_Menge_Y					uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	

	DECLARE @GUID_Attribute_Menge			uniqueidentifier

	DECLARE @GUID_Type_Menge				uniqueidentifier

	DECLARE @GUID_Type_Einheit				uniqueidentifier

	DECLARE @GUID_Type_Flaeche				uniqueidentifier

	DECLARE @GUID_RelationType_IsOfType	uniqueidentifier

	DECLARE @GUID_RelationType_X			uniqueidentifier

	DECLARE @GUID_RelationType_Y			uniqueidentifier

	

	SET @GUID_Attribute_Menge			= dbo.dbg_AttributeType_Menge()

	SET @GUID_Type_Menge				= dbo.dbg_Type_Menge()

	SET @GUID_Type_Einheit				= dbo.dbg_Type_Einheit()

	SET @GUID_Type_Flaeche				= dbo.dbg_Type_Fl_che()

	SET @GUID_RelationType_IsOfType		= dbo.dbg_RelationType_is_of_Type()

	SET @GUID_RelationType_X			= dbo.dbg_RelationType_x()

	SET @GUID_RelationType_Y			= dbo.dbg_RelationType_y()

	

	PRINT @GUID_Attribute_Menge			

	PRINT @GUID_Type_Menge				

	PRINT @GUID_Type_Einheit			

	PRINT @GUID_Type_Flaeche			

	PRINT @GUID_RelationType_IsOfType		

	PRINT @GUID_RelationType_X			

	PRINT @GUID_RelationType_Y			



    -- Insert statements for procedure here

	SELECT * FROM dbo.func_Flaechen(

		 @GUID_Attribute_Menge			

		,@GUID_Type_Menge				

		,@GUID_Type_Einheit				

		,@GUID_Type_Flaeche				

		,@GUID_RelationType_IsOfType	

		,@GUID_RelationType_X			

		,@GUID_RelationType_Y			

		,@GUID_Menge_X					

		,@GUID_Menge_Y)

END'
END
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[proc_Flaechen]') AND type in (N'P', N'PC'))
BEGIN
execute dbo.sp_executesql @statement = N'-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE [dbo].[proc_Flaechen]

	-- Add the parameters for the stored procedure here

	 @GUID_Attribute_Menge			uniqueidentifier

	,@GUID_Type_Menge				uniqueidentifier

	,@GUID_Type_Einheit				uniqueidentifier

	,@GUID_Type_Flaeche				uniqueidentifier

	,@GUID_RelationType_IsOfType	uniqueidentifier

	,@GUID_RelationType_X			uniqueidentifier

	,@GUID_RelationType_Y			uniqueidentifier

AS

BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from

	-- interfering with SELECT statements.

	SET NOCOUNT ON;



    -- Insert statements for procedure here

	SELECT * FROM dbo.func_Flaechen(

		 @GUID_Attribute_Menge			

		,@GUID_Type_Menge				

		,@GUID_Type_Einheit				

		,@GUID_Type_Flaeche				

		,@GUID_RelationType_IsOfType	

		,@GUID_RelationType_X			

		,@GUID_RelationType_Y			

		,DEFAULT					

		,DEFAULT)

		ORDER BY Name_Flaeche

END
'
END
GO
EXEC sp_addextendedproperty 
		@name = SchemaVersion, @value = '0.0.0.4';
GO
EXEC sp_addextendedproperty 
		@name = SemDB, @value = 'Yes';
GO
