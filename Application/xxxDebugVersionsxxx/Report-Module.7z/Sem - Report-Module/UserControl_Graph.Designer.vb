﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl_Graph
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.ToolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
        Me.VScrollBar_Pic = New System.Windows.Forms.VScrollBar()
        Me.HScrollBar_Pic = New System.Windows.Forms.HScrollBar()
        Me.PictureBox_Report = New System.Windows.Forms.PictureBox()
        Me.ToolStrip3 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton_Add_Type = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton_RemoveType = New System.Windows.Forms.ToolStripButton()
        Me.DataGridView_Token = New System.Windows.Forms.DataGridView()
        Me.BindingSource_Token = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.ToolStripContainer1.ContentPanel.SuspendLayout()
        Me.ToolStripContainer1.RightToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.SuspendLayout()
        CType(Me.PictureBox_Report, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip3.SuspendLayout()
        CType(Me.DataGridView_Token, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource_Token, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.ToolStripContainer1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.DataGridView_Token)
        Me.SplitContainer1.Size = New System.Drawing.Size(545, 499)
        Me.SplitContainer1.SplitterDistance = 340
        Me.SplitContainer1.TabIndex = 0
        '
        'ToolStripContainer1
        '
        Me.ToolStripContainer1.BottomToolStripPanelVisible = False
        '
        'ToolStripContainer1.ContentPanel
        '
        Me.ToolStripContainer1.ContentPanel.Controls.Add(Me.VScrollBar_Pic)
        Me.ToolStripContainer1.ContentPanel.Controls.Add(Me.HScrollBar_Pic)
        Me.ToolStripContainer1.ContentPanel.Controls.Add(Me.PictureBox_Report)
        Me.ToolStripContainer1.ContentPanel.Size = New System.Drawing.Size(509, 336)
        Me.ToolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ToolStripContainer1.LeftToolStripPanelVisible = False
        Me.ToolStripContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripContainer1.Name = "ToolStripContainer1"
        '
        'ToolStripContainer1.RightToolStripPanel
        '
        Me.ToolStripContainer1.RightToolStripPanel.Controls.Add(Me.ToolStrip3)
        Me.ToolStripContainer1.Size = New System.Drawing.Size(541, 336)
        Me.ToolStripContainer1.TabIndex = 0
        Me.ToolStripContainer1.Text = "ToolStripContainer1"
        Me.ToolStripContainer1.TopToolStripPanelVisible = False
        '
        'VScrollBar_Pic
        '
        Me.VScrollBar_Pic.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.VScrollBar_Pic.Location = New System.Drawing.Point(489, 1)
        Me.VScrollBar_Pic.Name = "VScrollBar_Pic"
        Me.VScrollBar_Pic.Size = New System.Drawing.Size(20, 335)
        Me.VScrollBar_Pic.TabIndex = 4
        '
        'HScrollBar_Pic
        '
        Me.HScrollBar_Pic.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.HScrollBar_Pic.Location = New System.Drawing.Point(-2, 316)
        Me.HScrollBar_Pic.Name = "HScrollBar_Pic"
        Me.HScrollBar_Pic.Size = New System.Drawing.Size(491, 20)
        Me.HScrollBar_Pic.TabIndex = 3
        '
        'PictureBox_Report
        '
        Me.PictureBox_Report.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox_Report.BackColor = System.Drawing.SystemColors.Window
        Me.PictureBox_Report.Location = New System.Drawing.Point(1, 1)
        Me.PictureBox_Report.Name = "PictureBox_Report"
        Me.PictureBox_Report.Size = New System.Drawing.Size(485, 312)
        Me.PictureBox_Report.TabIndex = 1
        Me.PictureBox_Report.TabStop = False
        '
        'ToolStrip3
        '
        Me.ToolStrip3.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton_Add_Type, Me.ToolStripButton_RemoveType})
        Me.ToolStrip3.Location = New System.Drawing.Point(0, 4)
        Me.ToolStrip3.Name = "ToolStrip3"
        Me.ToolStrip3.Size = New System.Drawing.Size(32, 76)
        Me.ToolStrip3.TabIndex = 1
        '
        'ToolStripButton_Add_Type
        '
        Me.ToolStripButton_Add_Type.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton_Add_Type.Enabled = False
        Me.ToolStripButton_Add_Type.Image = Global.Reports_Module.My.Resources.Resources.b_plus
        Me.ToolStripButton_Add_Type.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_Add_Type.Name = "ToolStripButton_Add_Type"
        Me.ToolStripButton_Add_Type.Size = New System.Drawing.Size(30, 20)
        Me.ToolStripButton_Add_Type.Text = "ToolStripButton1"
        '
        'ToolStripButton_RemoveType
        '
        Me.ToolStripButton_RemoveType.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton_RemoveType.Enabled = False
        Me.ToolStripButton_RemoveType.Image = Global.Reports_Module.My.Resources.Resources.b_minus
        Me.ToolStripButton_RemoveType.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_RemoveType.Name = "ToolStripButton_RemoveType"
        Me.ToolStripButton_RemoveType.Size = New System.Drawing.Size(30, 20)
        Me.ToolStripButton_RemoveType.Text = "ToolStripButton2"
        '
        'DataGridView_Token
        '
        Me.DataGridView_Token.AllowUserToAddRows = False
        Me.DataGridView_Token.AllowUserToDeleteRows = False
        Me.DataGridView_Token.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_Token.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView_Token.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView_Token.Name = "DataGridView_Token"
        Me.DataGridView_Token.ReadOnly = True
        Me.DataGridView_Token.Size = New System.Drawing.Size(541, 151)
        Me.DataGridView_Token.TabIndex = 1
        '
        'UserControl_Graph
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "UserControl_Graph"
        Me.Size = New System.Drawing.Size(545, 499)
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.ContentPanel.ResumeLayout(False)
        Me.ToolStripContainer1.RightToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.RightToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.PerformLayout()
        CType(Me.PictureBox_Report, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip3.ResumeLayout(False)
        Me.ToolStrip3.PerformLayout()
        CType(Me.DataGridView_Token, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource_Token, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents DataGridView_Token As System.Windows.Forms.DataGridView
    Friend WithEvents ToolStripContainer1 As System.Windows.Forms.ToolStripContainer
    Friend WithEvents ToolStrip3 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton_Add_Type As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton_RemoveType As System.Windows.Forms.ToolStripButton
    Friend WithEvents PictureBox_Report As System.Windows.Forms.PictureBox
    Friend WithEvents HScrollBar_Pic As System.Windows.Forms.HScrollBar
    Friend WithEvents VScrollBar_Pic As System.Windows.Forms.VScrollBar
    Friend WithEvents BindingSource_Token As System.Windows.Forms.BindingSource

End Class
