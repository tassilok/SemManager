﻿Imports Sem_Manager
Public Class UserControl_Graph

    Private objLocalConfig As clsLocalConfig

    Private procA_TypeItems_Of_Reports As New ds_ReportsModuleTableAdapters.proc_TypeItems_Of_ReportsTableAdapter
    Private procT_TypeItems_Of_Reports As New ds_ReportsModule.proc_TypeItems_Of_ReportsDataTable

    Private procA_TypeRelations_Of_Report As New ds_ReportsModuleTableAdapters.proc_TypeRelations_Of_ReportTableAdapter
    Private procT_TypeRelations_Of_Report As New ds_ReportsModule.proc_TypeRelations_Of_ReportDataTable

    Private semprocA_DBWork_Save_TokenAttribute_VARCHAR255 As New ds_DBWorkTableAdapters.semproc_DBWork_Save_TokenAttribute_Varchar255TableAdapter

    Private semtblA_Token_With_Check As New ds_ReportsModuleTableAdapters.semtbl_Token_With_CheckTableAdapter
    Private semtblT_Token_With_Check As New ds_ReportsModule.semtbl_Token_With_CheckDataTable

    Private typefuncA_Types_Rel As New ds_TypeTableAdapters.typefunc_Types_RelTableAdapter
    Private typefuncT_Types_Rel As New ds_Type.typefunc_Types_RelDataTable

    Private procA_belongingToken_Of_TypeItem As New ds_ReportsModuleTableAdapters.proc_belongingToken_Of_TypeItemTableAdapter
    Private procT_belongingToken_Of_TypeItem As New ds_ReportsModule.proc_belongingToken_Of_TypeItemDataTable

    Private objFrmTypeSelect As frmTypeSelect
    Private objFrmRelationTypeSelection As frmSelect_Items

    Private objTransaction_TypeItem As clsTransaction_TypeItem
    Private objTransaction_TypeItemRelation As clsTransaction_TypeItemRelation

    Private objDR_Report As DataRowView

    Private objFont_Relation As Font
    Private objSemItem_Report As clsSemItem

    Private objTypeItem_Selected As clsTypeItem
    Private objTypeItems() As clsTypeItem
    Private objSemItem_TypeRelation_Selected As clsSemItem = Nothing
    Private objSemItem_Type_ToRelate As clsSemItem

    Private intOffset_X As Integer = 0
    Private intOffset_Y As Integer = 0

    Private boolMouseMove As Boolean

    Public Event mouse_moved(ByVal intX As Integer, ByVal intY As Integer)

    Private Sub get_Data()
        If Not objSemItem_Report Is Nothing Then
            procA_TypeItems_Of_Reports.Fill(procT_TypeItems_Of_Reports, _
                                        objLocalConfig.SemItem_Attribute_size__Graphic_.GUID, _
                                        objLocalConfig.SemItem_Attribute_Coords__Graphic_.GUID, _
                                      objLocalConfig.SemItem_Attribute_Show_GUID.GUID, _
                                      objLocalConfig.SemItem_Attribute_show_Name.GUID, _
                                      objLocalConfig.SemItem_Attribute_All_Token.GUID, _
                                      objLocalConfig.SemItem_Type_Type_Item.GUID, _
                                      objLocalConfig.SemItem_Type_Reports.GUID, _
                                      objLocalConfig.SemItem_RelationType_contains.GUID, _
                                      objLocalConfig.SemItem_RelationType_belonging_Type.GUID, _
                                      objSemItem_Report.GUID)
        Else
            procT_TypeItems_Of_Reports.Clear()
        End If


    End Sub

    Private Sub draw_Relation(ByVal objGraphics As Graphics)

        Dim objTypeItem As clsTypeItem
        Dim objTypeItem_Left As clsTypeItem = Nothing
        Dim objTypeItem_Right As clsTypeItem = Nothing
        Dim objDR_Relation As DataRow
        Dim objDRC_LogState As DataRowCollection
        Dim objSemItem_Result As clsSemItem
        Dim objRect_Relation As New Rectangle
        Dim objRect_Graph As New Rectangle
        Dim objRect_Arrow As New Rectangle
        Dim objPosition_Rects As clsPosition_Rects
        Dim strRelationType As String
        Dim intXL_L As Integer
        Dim intXL_R As Integer
        Dim intXR_L As Integer
        Dim intXR_R As Integer
        Dim intYL_T As Integer
        Dim intYL_B As Integer
        Dim intYR_T As Integer
        Dim intYR_B As Integer
        Dim intX1 As Integer
        Dim intX2 As Integer
        Dim intY1 As Integer
        Dim intY2 As Integer
        Dim objSizeF As SizeF
        Dim strSize As String
        Dim strCoords As String
        Dim strCoords_DB As String
        Dim objPen_Arrow As New Pen(Brushes.Black, 3)
        Dim boolItemLeft_In_ItemRight As Boolean
        Dim boolItemRight_In_ItemLeft As Boolean

        For Each objDR_Relation In procT_TypeRelations_Of_Report.Rows
            objTypeItem_Left = Nothing
            objTypeItem_Right = Nothing
            strRelationType = objDR_Relation.Item("Name_RelationType")
            If Not IsDBNull(objDR_Relation.Item("Include")) Then

                If objDR_Relation.Item("Include") = True Then
                    strRelationType = strRelationType & " (I)"
                Else
                    strRelationType = strRelationType & " (E)"
                End If
            Else
                strRelationType = strRelationType & " (E)"
            End If


            For Each objTypeItem In objTypeItems
                If objTypeItem.TypeItem_Item.GUID = objDR_Relation.Item("GUID_Type_Item_Left") Then
                    objTypeItem_Left = objTypeItem
                    If Not objTypeItem_Right Is Nothing Then
                        Exit For
                    End If
                End If
                If objTypeItem.TypeItem_Item.GUID = objDR_Relation.Item("GUID_Type_Item_Right") Then
                    objTypeItem_Right = objTypeItem
                    If Not objTypeItem_Left Is Nothing Then
                        Exit For
                    End If
                End If
            Next

            If Not objTypeItem_Left Is Nothing And Not objTypeItem_Right Is Nothing Then
                objSizeF = objGraphics.MeasureString(objDR_Relation.Item("Name_RelationType"), objFont_Relation)
                intXL_L = objTypeItem_Left.Rect_TypeHeader.X - intOffset_X
                intXL_R = objTypeItem_Left.Rect_TypeHeader.X + objTypeItem_Left.Rect_TypeHeader.Width - intOffset_X
                intYL_T = objTypeItem_Left.Rect_TypeHeader.Y - intOffset_Y
                intYL_B = objTypeItem_Left.Rect_Attributes.Y + objTypeItem_Left.Rect_Attributes.Height - intOffset_Y

                intXR_L = objTypeItem_Right.Rect_TypeHeader.X - intOffset_X
                intXR_R = objTypeItem_Right.Rect_TypeHeader.X + objTypeItem_Right.Rect_TypeHeader.Width - intOffset_X
                intYR_T = objTypeItem_Right.Rect_TypeHeader.Y - intOffset_Y
                intYR_B = objTypeItem_Right.Rect_Attributes.Y + objTypeItem_Right.Rect_Attributes.Height - intOffset_Y


                objPosition_Rects = New clsPosition_Rects(intXL_L, _
                                                          intYL_T, _
                                                          intXL_R, _
                                                          intYL_B, _
                                                          intXR_L, _
                                                          intYR_T, _
                                                          intXR_R, _
                                                          intYR_B, _
                                                          strRelationType, _
                                                          objGraphics, _
                                                          objFont_Relation)

                strCoords_DB = objDR_Relation.Item("Coords")

                strSize = objPosition_Rects.Rect_Relation.Width & "," & objPosition_Rects.Rect_Relation.Height
                strCoords = objPosition_Rects.Rect_Relation.X & "," & objPosition_Rects.Rect_Relation.Y & "," & strCoords_DB.Substring(strCoords_DB.LastIndexOf(",") + 1)
                objSemItem_Result = objLocalConfig.Globals.LogState_Success
                If Not strCoords_DB = strCoords Then
                    objDRC_LogState = semprocA_DBWork_Save_TokenAttribute_VARCHAR255.GetData(objDR_Relation.Item("GUID_TypeRelation"), _
                                                                                             objLocalConfig.SemItem_Attribute_Coords__Graphic_.GUID, _
                                                                                             objDR_Relation.Item("GUID_TokenAttribute_Coords"), _
                                                                                             strCoords, 0).Rows
                    If objDRC_LogState(0).Item("GUID_Token") = objLocalConfig.Globals.LogState_Error.GUID Then
                        objSemItem_Result = objLocalConfig.Globals.LogState_Error
                    Else
                        objDR_Relation.Item("Coords") = strCoords

                    End If
                End If
                If Not strSize = objDR_Relation.Item("size") Then
                    objDRC_LogState = semprocA_DBWork_Save_TokenAttribute_VARCHAR255.GetData(objDR_Relation.Item("GUID_TypeRelation"), _
                                                                                             objLocalConfig.SemItem_Attribute_size__Graphic_.GUID, _
                                                                                             objDR_Relation.Item("GUID_TokenAttribute_Size"), _
                                                                                             strSize, 0).Rows
                    If objDRC_LogState(0).Item("GUID_Token") = objLocalConfig.Globals.LogState_Error.GUID Then
                        objSemItem_Result = objLocalConfig.Globals.LogState_Error
                    Else
                        objDR_Relation.Item("Size") = strSize

                    End If
                End If
                'Prüfung, ob Rects überlappen und wo welches Rect sich befindet. Anschließend Erzeugung des Rects für die Beziehung, evtl. die Linie zwischen beiden und den 
                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                    If Not objPosition_Rects.x1_Graph = 0 And _
                    Not objPosition_Rects.x2_Graph = 0 And _
                    Not objPosition_Rects.y1_Graph = 0 And _
                    Not objPosition_Rects.y2_Graph = 0 Then

                        objGraphics.DrawLine(Pens.Black, _
                                             objPosition_Rects.x1_Graph, _
                                             objPosition_Rects.y1_Graph, _
                                             objPosition_Rects.x2_Graph, _
                                             objPosition_Rects.y2_Graph)
                    End If
                    If objDR_Relation.Item("Selected") = True Then
                        objGraphics.FillRectangle(Brushes.Violet, objPosition_Rects.Rect_Relation)
                    Else
                        objGraphics.FillRectangle(Brushes.SandyBrown, objPosition_Rects.Rect_Relation)
                    End If

                    objGraphics.DrawString(strRelationType, objFont_Relation, Brushes.Black, objPosition_Rects.Rect_Relation.X + 2, objPosition_Rects.Rect_Relation.Y + 2)
                    If objPosition_Rects.Arrow.Arm1_X1 > 0 Or _
                        objPosition_Rects.Arrow.Arm1_X2 > 0 Or _
                        objPosition_Rects.Arrow.Arm1_Y2 > 0 Or _
                        objPosition_Rects.Arrow.Arm1_Y2 > 0 Or _
                        objPosition_Rects.Arrow.Arm2_X1 > 0 Or _
                        objPosition_Rects.Arrow.Arm2_X2 > 0 Or _
                        objPosition_Rects.Arrow.Arm2_Y1 > 0 Or _
                        objPosition_Rects.Arrow.Arm2_Y2 > 0 Then
                        objGraphics.DrawLine(objPen_Arrow, _
                                             objPosition_Rects.Arrow.Arm1_X1, _
                                             objPosition_Rects.Arrow.Arm1_Y1, _
                                             objPosition_Rects.Arrow.Arm1_X2, _
                                             objPosition_Rects.Arrow.Arm1_Y2)


                        objGraphics.DrawLine(objPen_Arrow, _
                                             objPosition_Rects.Arrow.Arm2_X1, _
                                             objPosition_Rects.Arrow.Arm2_Y1, _
                                             objPosition_Rects.Arrow.Arm2_X2, _
                                             objPosition_Rects.Arrow.Arm2_Y2)


                    End If
                Else
                    MsgBox("Die Beziehung " & objDR_Relation.Item("Name_Type_Item_Left") & _
                           " -> " & objDR_Relation.Item("Name_RelationType") & _
                           " -> " & objDR_Relation.Item("Name_Type_Item_Right") & " kann nicht dargestellt werden!", MsgBoxStyle.Exclamation)
                End If

            End If
        Next


    End Sub

    Private Sub set_Scrollbar()
        Dim objTypeItem As clsTypeItem
        Dim intX As Integer = 0
        Dim intY As Integer = 0

        For Each objTypeItem In objTypeItems
            If objTypeItem.TypeItem_Item.X > intX Then
                intX = objTypeItem.TypeItem_Item.X
            End If
            If objTypeItem.TypeItem_Item.Y > intY Then
                intY = objTypeItem.TypeItem_Item.Y
            End If
        Next

        intX = intX + 50
        intY = intY + 50

        If intX > PictureBox_Report.Width Then
            HScrollBar_Pic.Minimum = 0
            HScrollBar_Pic.Maximum = intX
            HScrollBar_Pic.Value = 0
            HScrollBar_Pic.SmallChange = 50
        End If

        If intY > PictureBox_Report.Height Then
            VScrollBar_Pic.Minimum = 0
            VScrollBar_Pic.Maximum = intY
            VScrollBar_Pic.Value = 0
            VScrollBar_Pic.LargeChange = 50
        End If
    End Sub

    Private Sub selected_Report(Optional ByVal DR_Report As DataRowView = Nothing)
        'Dim objDRC_TypeItems As DataRowCollection
        Dim objDR_TypeItem As DataRow
        Dim objGraphics As Graphics
        Dim objFont As New Font("Arial", 12)
        Dim objFont_GUIDName As New Font("Arial", 10)
        Dim objRect_PictureBox As Rectangle
        Dim i As Integer

        objDR_Report = DR_Report
        objFont_Relation = New Font("Arial", 8)
        If objDR_Report Is Nothing Then
            objSemItem_Report = Nothing
            objGraphics = PictureBox_Report.CreateGraphics
            objGraphics.FillRectangle(Brushes.White, New Rectangle(0, 0, PictureBox_Report.Width, PictureBox_Report.Height))
            ToolStripButton_Add_Type.Enabled = False
        Else

            If objDR_Report.Item("GUID_Token") = objLocalConfig.SemItem_Token_Empty_Items_Empty_Item.GUID Then
                objGraphics = PictureBox_Report.CreateGraphics
                objGraphics.FillRectangle(Brushes.White, New Rectangle(0, 0, PictureBox_Report.Width, PictureBox_Report.Height))
                ToolStripButton_Add_Type.Enabled = False
            Else
                ToolStripButton_Add_Type.Enabled = True
                objSemItem_Report = New clsSemItem
                objSemItem_Report.GUID = objDR_Report.Item("GUID_token")
                objSemItem_Report.Name = objDR_Report.Item("Name_Token")
                objSemItem_Report.GUID_Parent = objLocalConfig.SemItem_Type_Reports.GUID
                objSemItem_Report.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID

                get_Data()
                get_Relations()
                objGraphics = PictureBox_Report.CreateGraphics
                objRect_PictureBox = New Rectangle(0, 0, PictureBox_Report.Width, PictureBox_Report.Height)
                objGraphics.FillRectangle(Brushes.White, objRect_PictureBox)
                If procT_TypeItems_Of_Reports.Rows.Count > 0 Then
                    ReDim Preserve objTypeItems(procT_TypeItems_Of_Reports.Rows.Count - 1)
                    i = 0
                    For Each objDR_TypeItem In procT_TypeItems_Of_Reports.Rows
                        objTypeItems(i) = New clsTypeItem(objDR_TypeItem, objGraphics, objLocalConfig, objRect_PictureBox)
                        objTypeItems(i).draw_Type()
                        i = i + 1
                    Next
                    draw_Relation(objGraphics)
                    get_Data()
                    get_Relations()
                    set_Scrollbar()
                End If

            End If
        End If

    End Sub
    Private Sub get_Relations()
        procA_TypeRelations_Of_Report.Fill(procT_TypeRelations_Of_Report, _
                                           objLocalConfig.SemItem_Attribute_Include.GUID, _
                                           objLocalConfig.SemItem_Attribute_Coords__Graphic_.GUID, _
                                           objLocalConfig.SemItem_Attribute_size__Graphic_.GUID, _
                                           objLocalConfig.SemItem_Type_Reports.GUID, _
                                           objLocalConfig.SemItem_Type_TypeRelation.GUID, _
                                           objLocalConfig.SemItem_Type_Type_Item.GUID, _
                                           objLocalConfig.SemItem_RelationType_Type_Left.GUID, _
                                           objLocalConfig.SemItem_RelationType_Type_Right.GUID, _
                                           objLocalConfig.SemItem_RelationType_contains.GUID, _
                                           objLocalConfig.SemItem_RelationType_RelationType.GUID, _
                                           objSemItem_Report.GUID)
    End Sub

    Private Sub remove_TypeRelation()
        Dim objDRs_Relations() As DataRow
        Dim objTypeItem As clsTypeItem
        Dim objSemItem_Left As clsSemItem = Nothing
        Dim objSemItem_Right As clsSemItem = Nothing
        Dim objSemItem_RelationType As New clsSemItem
        Dim objSemItem_Result As clsSemItem
        Dim objSemItem_TypeRelation As New clsSemItem

        Dim GUID_TokenAttribute_Include As Guid = Nothing
        Dim GUID_TokenAttribute_Coords As Guid = Nothing
        Dim GUID_TokenAttribute_Size As Guid = Nothing
        Dim objDRC_LogState As DataRowCollection

        Dim boolInclude As Boolean



        objDRs_Relations = procT_TypeRelations_Of_Report.Select("Selected=True")
        If objDRs_Relations.Count > 0 Then
            objSemItem_TypeRelation.GUID = objDRs_Relations(0).Item("GUID_TypeRelation")
            objSemItem_TypeRelation.Name = objDRs_Relations(0).Item("Name_TypeRelation")
            objSemItem_TypeRelation.GUID_Parent = objLocalConfig.SemItem_Type_TypeRelation.GUID
            objSemItem_TypeRelation.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID

            For Each objTypeItem In objTypeItems
                If objDRs_Relations(0).Item("GUID_Type_Item_Left") = objTypeItem.TypeItem_Item.GUID Then
                    objSemItem_Left = New clsSemItem
                    objSemItem_Left.GUID = objTypeItem.TypeItem_Item.GUID
                    objSemItem_Left.Name = objTypeItem.TypeItem_Item.Name
                    objSemItem_Left.GUID_Parent = objTypeItem.TypeItem_Item.GUID_Parent
                    objSemItem_Left.GUID_Type = objTypeItem.TypeItem_Item.GUID_Type
                End If
                If objDRs_Relations(0).Item("GUID_Type_Item_Right") = objTypeItem.TypeItem_Item.GUID Then
                    objSemItem_Right = New clsSemItem
                    objSemItem_Right.GUID = objTypeItem.TypeItem_Item.GUID
                    objSemItem_Right.Name = objTypeItem.TypeItem_Item.Name
                    objSemItem_Right.GUID_Parent = objTypeItem.TypeItem_Item.GUID_Parent
                    objSemItem_Right.GUID_Type = objTypeItem.TypeItem_Item.GUID_Type
                End If
                If Not objSemItem_Left Is Nothing And Not objSemItem_Right Is Nothing Then
                    objSemItem_RelationType.GUID = objDRs_Relations(0).Item("GUID_RelationType")
                    objSemItem_RelationType.Name = objDRs_Relations(0).Item("Name_RelationType")
                    objSemItem_RelationType.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_RelationType.GUID
                    boolInclude = objDRs_Relations(0).Item("Include")
                    GUID_TokenAttribute_Include = objDRs_Relations(0).Item("GUID_TokenAttribute_include")
                    GUID_TokenAttribute_Coords = objDRs_Relations(0).Item("GUID_TokenAttribute_Coords")
                    GUID_TokenAttribute_Size = objDRs_Relations(0).Item("GUID_TokenAttribute_Size")
                    Exit For
                End If
            Next
            If Not objSemItem_Left Is Nothing And Not objSemItem_Left Is Nothing Then
                If MsgBox("Wollen Sie die Beziehung wirklich löschen?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                    objTransaction_TypeItemRelation = New clsTransaction_TypeItemRelation(objLocalConfig, _
                                                                                            objSemItem_Left, objSemItem_Right, _
                                                                                            objSemItem_RelationType, _
                                                                                            boolInclude)
                    objTransaction_TypeItemRelation.GUID_TokenAttribute_Coords = GUID_TokenAttribute_Coords
                    objTransaction_TypeItemRelation.GUID_TokenAttribute_Include = GUID_TokenAttribute_Include
                    objTransaction_TypeItemRelation.GUID_TokenAttribute_Size = GUID_TokenAttribute_Size
                    objTransaction_TypeItemRelation.SemItem_TypeRelation = objSemItem_TypeRelation
                    objTransaction_TypeItemRelation.SemItem_RelationType = objSemItem_RelationType

                    objSemItem_Result = objTransaction_TypeItemRelation.del_006_Coords()
                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                        objSemItem_Result = objTransaction_TypeItemRelation.del_005_Size()
                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                            objSemItem_Result = objTransaction_TypeItemRelation.del_004_Include()
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objSemItem_Result = objTransaction_TypeItemRelation.del_003_TypeRelation_to_RelationType()
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(True)
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(False)
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                                                MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                            End If
                                        Else
                                            MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                        End If
                                    Else
                                        MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                    End If
                                Else
                                    MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                End If
                            Else
                                MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                            End If
                        Else
                            MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                        End If
                    Else
                        MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                    End If

                End If

            End If

        End If


        get_Relations()
        draw_Items(PictureBox_Report.CreateGraphics, True)


    End Sub

    Private Sub show_Token(ByVal objTypeItem_Selected As clsTypeItem)
        Dim objDR_Token As DataRow
        Dim objDRs_Selected() As DataRow
        DataGridView_Token.DataSource = Nothing
        If objTypeItem_Selected.Checkbox_AllToken.Checked = False Then


            If Not objTypeItem_Selected Is Nothing Then
                semtblA_Token_With_Check.Fill_By_GUID_Type(semtblT_Token_With_Check, objTypeItem_Selected.TypeItem_Item.SemItem_Type_of_TypeItem.GUID)

                procA_belongingToken_Of_TypeItem.Fill(procT_belongingToken_Of_TypeItem, _
                                                      objLocalConfig.SemItem_Type_Type_Item.GUID, _
                                                      objLocalConfig.SemItem_RelationType_belonging_Token.GUID)

                For Each objDR_Token In semtblT_Token_With_Check.Rows

                    objDRs_Selected = procT_belongingToken_Of_TypeItem.Select("GUID_Token='" & objDR_Token.Item("GUID_Token").ToString & "'")
                    If objDRs_Selected.Count > 0 Then
                        objDR_Token.Item("Check") = True
                    End If

                Next

                BindingSource_Token.DataSource = semtblT_Token_With_Check
                DataGridView_Token.DataSource = BindingSource_Token

                DataGridView_Token.Columns(0).Visible = False
                DataGridView_Token.Columns(2).Visible = False
            End If
        Else

        End If


    End Sub

    Private Sub draw_Items(ByVal objGraphics As Graphics, ByVal boolClear As Boolean)
        Dim objTypeItem As clsTypeItem
        If boolClear = True Then
            objGraphics.Clear(Color.White)
        End If
        If Not objTypeItems Is Nothing Then
            For Each objTypeItem In objTypeItems
                objTypeItem._Graphics = objGraphics

                objTypeItem.draw_Type()
                draw_Relation(objGraphics)
            Next
        End If
    End Sub
    Private Sub HScrollBar_Pic_Scroll(ByVal sender As Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles HScrollBar_Pic.Scroll
        Dim objTypeItem As clsTypeItem
        intOffset_X = e.NewValue

        If Not objTypeItems Is Nothing Then
            For Each objTypeItem In objTypeItems
                objTypeItem.Offset_X = intOffset_X
            Next

            draw_Items(PictureBox_Report.CreateGraphics, True)
        End If
        
    End Sub

    Private Sub VScrollBar_Pic_Scroll(ByVal sender As Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles VScrollBar_Pic.Scroll
        Dim objTypeItem As clsTypeItem
        intOffset_Y = e.NewValue

        If Not objTypeItems Is Nothing Then
            For Each objTypeItem In objTypeItems
                objTypeItem.Offset_Y = intOffset_Y
            Next

            draw_Items(PictureBox_Report.CreateGraphics, True)
        End If
        
    End Sub

    Private Sub PictureBox_Report_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox_Report.MouseClick
        Dim objTypeItem As clsTypeItem
        Dim objTypeItem_Selected As clsTypeItem = Nothing

        Dim objCheckBox As clsCheckbox
        Dim objDRs_TypeItems() As DataRow
        Dim objDR_TypeRelation As DataRow
        Dim objRect_Relation As New Rectangle
        Dim objSemItem_Result As clsSemItem
        Dim objGraphics As Graphics
        Dim strCoords As String
        Dim strSize As String
        Dim intX As Integer
        Dim intY As Integer
        Dim intWidth As Integer
        Dim intHeight As Integer

        objSemItem_TypeRelation_Selected = Nothing
        objGraphics = PictureBox_Report.CreateGraphics
        If Not objTypeItems Is Nothing Then
            For Each objTypeItem In objTypeItems
                objTypeItem._Graphics = objGraphics
                'objTypeItem.Mark_Type = False
                If e.X + intOffset_X >= objTypeItem.Checkbox_GUID.Rect_CheckBox.X And _
                    e.X + intOffset_X <= objTypeItem.Checkbox_GUID.Rect_CheckBox.X + objTypeItem.Checkbox_GUID.Rect_CheckBox.Width And _
                    e.Y + intOffset_Y >= objTypeItem.Checkbox_GUID.Rect_CheckBox.Y And _
                    e.Y + intOffset_Y <= objTypeItem.Checkbox_GUID.Rect_CheckBox.Y + objTypeItem.Checkbox_GUID.Rect_CheckBox.Height Then

                    objTypeItem_Selected = objTypeItem
                    objCheckBox = objTypeItem_Selected.Checkbox_GUID
                    objTypeItem_Selected.Mark_Type = True
                    Exit For

                ElseIf e.X + intOffset_X >= objTypeItem.Checkbox_Name.Rect_CheckBox.X And _
                    e.X + intOffset_X <= objTypeItem.Checkbox_Name.Rect_CheckBox.X + objTypeItem.Checkbox_Name.Rect_CheckBox.Width And _
                    e.Y + intOffset_Y >= objTypeItem.Checkbox_Name.Rect_CheckBox.Y And _
                    e.Y + intOffset_Y <= objTypeItem.Checkbox_Name.Rect_CheckBox.Y + objTypeItem.Checkbox_Name.Rect_CheckBox.Height Then

                    objTypeItem_Selected = objTypeItem
                    objCheckBox = objTypeItem_Selected.Checkbox_Name
                    objTypeItem_Selected.Mark_Type = True
                    Exit For

                ElseIf e.X + intOffset_X >= objTypeItem.Checkbox_AllToken.Rect_CheckBox.X And _
                    e.X + intOffset_X <= objTypeItem.Checkbox_AllToken.Rect_CheckBox.X + objTypeItem.Checkbox_AllToken.Rect_CheckBox.Width And _
                    e.Y + intOffset_Y >= objTypeItem.Checkbox_AllToken.Rect_CheckBox.Y And _
                    e.Y + intOffset_Y <= objTypeItem.Checkbox_AllToken.Rect_CheckBox.Y + objTypeItem.Checkbox_AllToken.Rect_CheckBox.Height Then

                    objTypeItem_Selected = objTypeItem
                    objCheckBox = objTypeItem_Selected.Checkbox_AllToken
                    objTypeItem_Selected.Mark_Type = True
                    Exit For

                Else
                    If Not objTypeItem.Checkboxes_Attributes Is Nothing Then
                        For Each objCheckBox In objTypeItem.Checkboxes_Attributes
                            If e.X + intOffset_X >= objCheckBox.Rect_CheckBox.X And _
                                e.X + intOffset_X <= objCheckBox.Rect_CheckBox.X + objCheckBox.Rect_CheckBox.Width And _
                                e.Y + intOffset_Y >= objCheckBox.Rect_CheckBox.Y And _
                                e.Y + intOffset_Y <= objCheckBox.Rect_CheckBox.Y + objCheckBox.Rect_CheckBox.Height Then

                                objTypeItem_Selected = objTypeItem
                                objTypeItem_Selected.Mark_Type = True
                                Exit For

                            End If
                        Next
                    End If

                    If Not objTypeItem_Selected Is Nothing Then
                        If objTypeItem_Selected.Mark_Type = True Then
                            Exit For
                        End If
                    Else
                        For Each objDR_TypeRelation In procT_TypeRelations_Of_Report.Rows
                            strCoords = objDR_TypeRelation.Item("Coords")
                            intX = Integer.Parse(strCoords.Substring(0, strCoords.IndexOf(",")))
                            strCoords = strCoords.Substring(strCoords.IndexOf(",") + 1)
                            intY = Integer.Parse(strCoords.Substring(0, strCoords.IndexOf(",")))
                            strSize = objDR_TypeRelation.Item("Size")
                            intWidth = Integer.Parse(strSize.Substring(0, strSize.IndexOf(",")))
                            intHeight = Integer.Parse(strSize.Substring(strSize.IndexOf(",") + 1))

                            If e.X + intOffset_X >= intX And _
                                e.X + intOffset_X <= intX + intWidth And _
                                e.Y + intOffset_Y >= intY And _
                                e.Y + intOffset_Y <= intY + intHeight Then
                                objSemItem_TypeRelation_Selected = New clsSemItem
                                objSemItem_TypeRelation_Selected.GUID = objDR_TypeRelation.Item("GUID_TypeRelation")
                                objSemItem_TypeRelation_Selected.Name = objDR_TypeRelation.Item("Name_TypeRelation")
                                objSemItem_TypeRelation_Selected.GUID_Parent = objLocalConfig.SemItem_Type_TypeRelation.GUID
                                objSemItem_TypeRelation_Selected.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID
                                objDR_TypeRelation.Item("Selected") = True
                                Exit For
                            End If
                        Next
                        If Not objSemItem_TypeRelation_Selected Is Nothing Then
                            objSemItem_Type_ToRelate = Nothing
                            ToolStripButton_RemoveType.Enabled = True
                            Exit For
                        End If
                    End If

                End If
            Next
        End If


        If Not objTypeItem_Selected Is Nothing Then
            For Each objDR_TypeRelation In procT_TypeRelations_Of_Report.Rows
                objDR_TypeRelation.Item("Selected") = False
            Next
            get_Data()
            objDRs_TypeItems = procT_TypeItems_Of_Reports.Select("GUID_Type_Item='" & objTypeItem_Selected.TypeItem_Item.GUID.ToString & "'")
            If objDRs_TypeItems.Count > 0 Then
                Select Case objCheckBox.SemItem.GUID
                    Case objLocalConfig.SemItem_Token_Checkboxes_GUID.GUID
                        If objCheckBox.Checked = objDRs_TypeItems(0).Item("showGUID") Then
                            objSemItem_Result = objCheckBox.change_CheckState
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                                MsgBox("Die Status der Checkbox hat sich geändert!", MsgBoxStyle.Exclamation)
                            End If
                            selected_Report()
                        Else
                            MsgBox("Die Status der Checkbox hat sich geändert!", MsgBoxStyle.Exclamation)
                            objCheckBox.Checked = objDRs_TypeItems(0).Item("showGUID")
                            objCheckBox.draw_Checkbox(objGraphics, intOffset_X, intOffset_Y)
                        End If
                    Case objLocalConfig.SemItem_Token_Checkboxes_Name.GUID
                        If objCheckBox.Checked = objDRs_TypeItems(0).Item("showName") Then
                            objSemItem_Result = objCheckBox.change_CheckState
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                                MsgBox("Die Status der Checkbox hat sich geändert!", MsgBoxStyle.Exclamation)
                            End If
                            selected_Report()
                        Else
                            MsgBox("Die Status der Checkbox hat sich geändert!", MsgBoxStyle.Exclamation)
                            objCheckBox.Checked = objDRs_TypeItems(0).Item("showName")
                            objCheckBox.draw_Checkbox(objGraphics, intOffset_X, intOffset_Y)
                        End If
                    Case objLocalConfig.SemItem_Token_Checkboxes_AllToken.GUID
                        If objCheckBox.Checked = objDRs_TypeItems(0).Item("AllToken") Then
                            objSemItem_Result = objCheckBox.change_CheckState
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                                MsgBox("Die Status der Checkbox hat sich geändert!", MsgBoxStyle.Exclamation)
                            End If
                            selected_Report()
                        Else
                            MsgBox("Die Status der Checkbox hat sich geändert!", MsgBoxStyle.Exclamation)
                            objCheckBox.Checked = objDRs_TypeItems(0).Item("showAllToken")
                            objCheckBox.draw_Checkbox(objGraphics, intOffset_X, intOffset_Y)

                        End If
                    Case Else
                        objSemItem_Result = objCheckBox.change_CheckState()
                        selected_Report()
                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                            MsgBox("Die Status der Checkbox hat sich geändert!", MsgBoxStyle.Exclamation)
                        End If
                        selected_Report()
                End Select
            Else
                MsgBox("Leider konnte die Type nicht ermittelt werden!", MsgBoxStyle.Exclamation)
                selected_Report()
            End If

        ElseIf Not objSemItem_TypeRelation_Selected Is Nothing Then
            draw_Relation(objGraphics)
        Else
            For Each objDR_TypeRelation In procT_TypeRelations_Of_Report.Rows
                objDR_TypeRelation.Item("Selected") = False
            Next
            objGraphics.FillRectangle(Brushes.White, New Rectangle(0, 0, _
                                                                  PictureBox_Report.Width, _
                                                                  PictureBox_Report.Height))
            draw_Relation(objGraphics)
            objTypeItem_Selected = Nothing
            For Each objTypeItem In objTypeItems
                objTypeItem.Mark_Type = False
                objTypeItem.draw_Type()
            Next
        End If
    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        
    End Sub
    Public Sub initialize(ByVal LocalConfig As clsLocalConfig, ByVal DR_Reports As DataRowView)
        objLocalConfig = LocalConfig

        set_DBConnection()
        objDR_Report = DR_Reports
        selected_Report(objDR_Report)
    End Sub

    Private Sub PictureBox_Report_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox_Report.MouseDown
        Dim objGraphics As Graphics
        Dim objTypeItem As clsTypeItem
        Dim objRect_TypeHeader As Rectangle
        Dim objSemItem_Result As clsSemItem
        Dim objDR_TypeRelation As DataRow
        Dim intZ As Integer = -1

        ToolStripButton_RemoveType.Enabled = False
        objGraphics = PictureBox_Report.CreateGraphics
        boolMouseMove = False
        If Not objTypeItem_Selected Is Nothing Then
            objTypeItem_Selected = Nothing
        End If
        If Not objTypeItems Is Nothing Then
            For Each objTypeItem In objTypeItems
                objTypeItem._Graphics = objGraphics
                objTypeItem.Mark_Type = False
                objTypeItem.draw_Type()
                objRect_TypeHeader = objTypeItem.Rect_TypeHeader
                If e.X >= objRect_TypeHeader.X And e.X <= objRect_TypeHeader.X + objRect_TypeHeader.Width And _
                    e.Y >= objRect_TypeHeader.Y And e.Y <= objRect_TypeHeader.Y + objRect_TypeHeader.Height Then
                    If objTypeItem.Z > intZ Then
                        objTypeItem_Selected = objTypeItem
                        objTypeItem.Mark_Type = True

                    End If
                End If
            Next
            If Not objTypeItem_Selected Is Nothing Then
                For Each objDR_TypeRelation In procT_TypeRelations_Of_Report.Rows
                    objDR_TypeRelation.Item("Selected") = False
                Next
                show_Token(objTypeItem_Selected)
                objTypeItem_Selected.draw_Type()
                objSemItem_Result = objTypeItem_Selected.set_Level_Highest
                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                    objTypeItem_Selected.clear_Graphics(Brushes.White)
                Else
                    ToolStripButton_RemoveType.Enabled = True
                End If
                draw_Relation(objGraphics)
            End If
            If Not objSemItem_TypeRelation_Selected Is Nothing Then
                ToolStripButton_RemoveType.Enabled = True
            End If
        End If
    End Sub

    Private Sub PictureBox_Report_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox_Report.MouseMove
        boolMouseMove = False
        If Not objTypeItem_Selected Is Nothing Then
            boolMouseMove = True
        End If
        RaiseEvent mouse_moved(e.X, e.Y)

    End Sub

    Private Sub PictureBox_Report_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox_Report.MouseUp
        Dim objSemItem_Result As clsSemItem
        Dim objTypeItem As clsTypeItem
        Dim objGraphics As Graphics

        objGraphics = PictureBox_Report.CreateGraphics

        If boolMouseMove = True Then
            If Not objTypeItem_Selected Is Nothing Then
                objTypeItem_Selected._Graphics = objGraphics
                objSemItem_Result = objTypeItem_Selected.set_XY(e.X, e.Y, intOffset_X, intOffset_Y)
                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then

                    selected_Report()

                Else
                    objTypeItem_Selected.clear_Graphics(Brushes.White)
                End If

            End If
        End If


        boolMouseMove = False
    End Sub

    Private Sub add_Type(ByVal objSemItem_TypeItem_Left As clsSemItem, Optional ByVal objSemItem_RelationType As clsSemItem = Nothing, Optional ByVal boolInclude As Boolean = False)
        Dim objSemItem_Result As clsSemItem
        objTransaction_TypeItem = New clsTransaction_TypeItem(objLocalConfig, objSemItem_Report, objSemItem_Type_ToRelate)
        objSemItem_Result = objTransaction_TypeItem.save_001_TypeItem
        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
            objSemItem_Result = objTransaction_TypeItem.save_002_showGUID(False)
            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                objSemItem_Result = objTransaction_TypeItem.save_003_showName(False)
                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                    objSemItem_Result = objTransaction_TypeItem.save_004_showAllToken(False)
                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                        objSemItem_Result = objTransaction_TypeItem.save_005_Coords(0, 0, 0)

                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                            objSemItem_Result = objTransaction_TypeItem.save_006_Size(0, 0)
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objSemItem_Result = objTransaction_TypeItem.save_007_Report_To_TypeItem
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItem.save_008_TypeItem_To_Type
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        If Not objSemItem_RelationType Is Nothing Then
                                            objSemItem_Result = save_TypeRelation(objSemItem_TypeItem_Left, _
                                                                          objTransaction_TypeItem.SemItem_TypeItem, _
                                                                          objSemItem_RelationType, _
                                                                          boolInclude)
                                            If Not objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                                                selected_Report()
                                            Else

                                                MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)
                                                objSemItem_Result = objTransaction_TypeItem.del_008_TypeItem_To_Type()
                                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                    objSemItem_Result = objTransaction_TypeItem.del_007_Report_To_TypeItem()
                                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                        objSemItem_Result = objTransaction_TypeItem.del_006_Size
                                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                            objSemItem_Result = objTransaction_TypeItem.del_005_Coords
                                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                                objSemItem_Result = objTransaction_TypeItem.del_004_showAllToken
                                                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                                    objSemItem_Result = objTransaction_TypeItem.del_003_showName
                                                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                                        objSemItem_Result = objTransaction_TypeItem.del_002_showGUID
                                                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                                            objTransaction_TypeItem.del_001_TypeItem()
                                                                        End If
                                                                    End If
                                                                End If
                                                            End If
                                                        End If

                                                    End If
                                                End If
                                            End If
                                        End If

                                    Else
                                        MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)
                                        objSemItem_Result = objTransaction_TypeItem.del_007_Report_To_TypeItem()
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItem.del_006_Size
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                objSemItem_Result = objTransaction_TypeItem.del_005_Coords
                                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                    objSemItem_Result = objTransaction_TypeItem.del_004_showAllToken
                                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                        objSemItem_Result = objTransaction_TypeItem.del_003_showName
                                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                            objSemItem_Result = objTransaction_TypeItem.del_002_showGUID
                                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                                objTransaction_TypeItem.del_001_TypeItem()
                                                            End If
                                                        End If
                                                    End If
                                                End If
                                            End If

                                        End If
                                    End If

                                Else
                                    MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)

                                    objSemItem_Result = objTransaction_TypeItem.del_006_Size
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objSemItem_Result = objTransaction_TypeItem.del_005_Coords
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItem.del_004_showAllToken
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                objSemItem_Result = objTransaction_TypeItem.del_003_showName
                                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                    objSemItem_Result = objTransaction_TypeItem.del_002_showGUID
                                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                        objTransaction_TypeItem.del_001_TypeItem()
                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If





                                End If
                            Else
                                MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)
                                objSemItem_Result = objTransaction_TypeItem.del_005_Coords
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItem.del_004_showAllToken
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objSemItem_Result = objTransaction_TypeItem.del_003_showName
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItem.del_002_showGUID
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                objTransaction_TypeItem.del_001_TypeItem()
                                            End If
                                        End If
                                    End If
                                End If

                            End If
                        Else
                            MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)
                            objSemItem_Result = objTransaction_TypeItem.del_004_showAllToken
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objSemItem_Result = objTransaction_TypeItem.del_003_showName
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItem.del_002_showGUID
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objTransaction_TypeItem.del_001_TypeItem()
                                    End If
                                End If
                            End If

                        End If
                    Else
                        MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)
                        objSemItem_Result = objTransaction_TypeItem.del_003_showName
                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                            objSemItem_Result = objTransaction_TypeItem.del_002_showGUID
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objTransaction_TypeItem.del_001_TypeItem()
                            End If
                        End If

                    End If
                Else
                    MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)
                    objSemItem_Result = objTransaction_TypeItem.del_002_showGUID
                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                        objTransaction_TypeItem.del_001_TypeItem()
                    End If

                End If
            Else
                MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)
                objTransaction_TypeItem.del_001_TypeItem()
            End If
        Else
            MsgBox("Die Type kann dem Bericht nicht hinzugefügt werden!", MsgBoxStyle.Exclamation)
        End If
    End Sub
    Private Function save_TypeRelation(ByVal objSemItem_TypeItemLeft As clsSemItem, _
                                       ByVal objSemItem_TypeItemRight As clsSemItem, _
                                       ByVal objSemItem_RelationType As clsSemItem, _
                                       ByVal boolInclude As Boolean) As clsSemItem
        Dim objSemItem_Result As clsSemItem

        objTransaction_TypeItemRelation = New clsTransaction_TypeItemRelation(objLocalConfig, _
                                                                          objSemItem_TypeItemLeft, _
                                                                          objSemItem_TypeItemRight, _
                                                                          objSemItem_RelationType, _
                                                                          boolInclude)
        objSemItem_Result = objTransaction_TypeItemRelation.save_001_TypeItem_Relation()
        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
            objSemItem_Result = objTransaction_TypeItemRelation.save_002_TypeRelation_To_TypeItemLeftRight(True)
            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                objSemItem_Result = objTransaction_TypeItemRelation.save_002_TypeRelation_To_TypeItemLeftRight(False)
                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                    objSemItem_Result = objTransaction_TypeItemRelation.save_003_TypeRelation_to_RelationType
                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                        objSemItem_Result = objTransaction_TypeItemRelation.save_004_Include
                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                            objSemItem_Result = objTransaction_TypeItemRelation.save_005_Size(0, 0)
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objSemItem_Result = objTransaction_TypeItemRelation.save_006_Coords(0, 0, 0)
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objLocalConfig.Globals.LogState_Success
                                Else
                                    objSemItem_Result = objTransaction_TypeItemRelation.del_005_Size
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objSemItem_Result = objTransaction_TypeItemRelation.del_004_Include
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItemRelation.del_003_TypeRelation_to_RelationType
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(False)
                                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                    objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(True)
                                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                        objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If

                                    objSemItem_Result = objLocalConfig.Globals.LogState_Error
                                End If



                            Else
                                objSemItem_Result = objTransaction_TypeItemRelation.del_004_Include
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItemRelation.del_003_TypeRelation_to_RelationType
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(False)
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(True)
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                                            End If
                                        End If
                                    End If
                                End If



                                objSemItem_Result = objLocalConfig.Globals.LogState_Error
                            End If

                        Else
                            objSemItem_Result = objTransaction_TypeItemRelation.del_003_TypeRelation_to_RelationType
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(False)
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(True)
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                                    End If
                                End If
                            End If


                            objSemItem_Result = objLocalConfig.Globals.LogState_Error
                        End If
                    Else
                        objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(False)
                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                            objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(True)
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                            End If
                        End If

                        objSemItem_Result = objLocalConfig.Globals.LogState_Error
                    End If

                Else
                    objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(True)
                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                        objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                    End If
                    objSemItem_Result = objLocalConfig.Globals.LogState_Error
                End If
            Else
                objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                objSemItem_Result = objLocalConfig.Globals.LogState_Error
            End If

        End If
        Return objSemItem_Result
    End Function

    Private Sub remove_TypeItem()
        Dim objSemItem_TypeItem As New clsSemItem
        Dim objSemItem_Result As clsSemItem
        Dim objSemItem_Left As clsSemItem = Nothing
        Dim objSemItem_Right As clsSemItem = Nothing
        Dim objSemItem_RelationType As New clsSemItem
        Dim objSemItem_TypeRelation As New clsSemItem
        Dim GUID_TokenAttribute_Include As Guid
        Dim GUID_TokenAttribute_Coords As Guid
        Dim GUID_TokenAttribute_Size As Guid
        Dim objDRs_TypeItem() As DataRow
        Dim objDRs_TypeRelation() As DataRow
        Dim objDR_TypeRelation As DataRow
        Dim boolInclude As Boolean

        objTransaction_TypeItem = New clsTransaction_TypeItem(objLocalConfig, objSemItem_Report, objTypeItem_Selected.TypeItem_Item.SemItem_Type_of_TypeItem)

        objSemItem_TypeItem.GUID = objTypeItem_Selected.TypeItem_Item.GUID
        objSemItem_TypeItem.Name = objTypeItem_Selected.TypeItem_Item.Name
        objSemItem_TypeItem.GUID_Parent = objLocalConfig.SemItem_Type_Type_Item.GUID
        objSemItem_TypeItem.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID

        get_Data()
        get_Relations()
        objDRs_TypeItem = procT_TypeItems_Of_Reports.Select("GUID_Type_Item='" & objSemItem_TypeItem.GUID.ToString & "'")
        If objDRs_TypeItem.Count > 0 Then
            objTransaction_TypeItem._GUID_TokenAttribute_Coords = objDRs_TypeItem(0).Item("GUID_TokenAttribute_Coords")
            objTransaction_TypeItem._GUID_TokenAttribute_Size = objDRs_TypeItem(0).Item("GUID_TokenAttribute_Size")
            objTransaction_TypeItem._GUID_TokenAttribute_ShowGUID = objDRs_TypeItem(0).Item("GUID_TokenAttribute_showGUID")
            objTransaction_TypeItem._GUID_TokenAttribute_ShowName = objDRs_TypeItem(0).Item("GUID_TokenAttribute_showName")
            objTransaction_TypeItem._GUID_TokenAttribute_showAllToken = objDRs_TypeItem(0).Item("GUID_TokenAttribute_AllToken")
            objTransaction_TypeItem.SemItem_TypeItem = objSemItem_TypeItem
            objDRs_TypeRelation = procT_TypeRelations_Of_Report.Select("GUID_Type_Item_Left='" & objSemItem_TypeItem.GUID.ToString & "'")

            If objDRs_TypeRelation.Count > 0 Then
                For Each objDR_TypeRelation In objDRs_TypeRelation

                    objSemItem_Left = New clsSemItem
                    objSemItem_Left.GUID = objDRs_TypeRelation(0).Item("GUID_TypeItem_Left")
                    objSemItem_Left.Name = objDRs_TypeRelation(0).Item("Name_TypeItem_Left")
                    objSemItem_Left.GUID_Parent = objLocalConfig.SemItem_Type_Type_Item.GUID
                    objSemItem_Left.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID

                    objSemItem_Right = New clsSemItem
                    objSemItem_Right.GUID = objDRs_TypeRelation(0).Item("GUID_TypeItem_Left")
                    objSemItem_Right.Name = objDRs_TypeRelation(0).Item("Name_TypeItem_Left")
                    objSemItem_Right.GUID_Parent = objLocalConfig.SemItem_Type_Type_Item.GUID
                    objSemItem_Right.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID

                    objSemItem_RelationType.GUID = objDRs_TypeRelation(0).Item("GUID_RelationType")
                    objSemItem_RelationType.Name = objDRs_TypeRelation(0).Item("Name_RelationType")
                    objSemItem_RelationType.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_RelationType.GUID

                    GUID_TokenAttribute_Include = objDRs_TypeRelation(0).Item("GUID_TokenAttribute_Include")
                    boolInclude = objDRs_TypeRelation(0).Item("Include")

                    objSemItem_TypeRelation.GUID = objDRs_TypeRelation(0).Item("GUID_TypeRelation")
                    objSemItem_TypeRelation.Name = objDRs_TypeRelation(0).Item("Name_TypeRelation")
                    objSemItem_TypeRelation.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_RelationType.GUID

                    GUID_TokenAttribute_Size = objDRs_TypeRelation(0).Item("GUID_TokenAttribute_Size")

                    objTransaction_TypeItemRelation = New clsTransaction_TypeItemRelation(objLocalConfig, _
                                                                                            objSemItem_Left, objSemItem_Right, _
                                                                                            objSemItem_RelationType, _
                                                                                            boolInclude)
                    objTransaction_TypeItemRelation.GUID_TokenAttribute_Coords = GUID_TokenAttribute_Coords
                    objTransaction_TypeItemRelation.GUID_TokenAttribute_Include = GUID_TokenAttribute_Include
                    objTransaction_TypeItemRelation.GUID_TokenAttribute_Size = GUID_TokenAttribute_Size
                    objTransaction_TypeItemRelation.SemItem_TypeRelation = objSemItem_TypeRelation
                    objTransaction_TypeItemRelation.SemItem_RelationType = objSemItem_RelationType

                    objSemItem_Result = objTransaction_TypeItemRelation.del_006_Coords()
                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                        objSemItem_Result = objTransaction_TypeItemRelation.del_005_Size()
                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                            objSemItem_Result = objTransaction_TypeItemRelation.del_004_Include()
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objSemItem_Result = objTransaction_TypeItemRelation.del_003_TypeRelation_to_RelationType()
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(True)
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(False)
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                                                MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                            End If
                                        Else
                                            MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                        End If
                                    Else
                                        MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                    End If
                                Else
                                    MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                End If
                            Else
                                MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                            End If
                        Else
                            MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                        End If
                    Else
                        MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                    End If
                Next

            Else
                objDRs_TypeRelation = procT_TypeRelations_Of_Report.Select("GUID_Type_Item_Right='" & objSemItem_TypeItem.GUID.ToString & "'")
                If objDRs_TypeRelation.Count > 0 Then
                    For Each objDR_TypeRelation In objDRs_TypeRelation


                        objSemItem_Left = New clsSemItem
                        objSemItem_Left.GUID = objDRs_TypeRelation(0).Item("GUID_TypeItem_Left")
                        objSemItem_Left.Name = objDRs_TypeRelation(0).Item("Name_TypeItem_Left")
                        objSemItem_Left.GUID_Parent = objLocalConfig.SemItem_Type_Type_Item.GUID
                        objSemItem_Left.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID

                        objSemItem_Right = New clsSemItem
                        objSemItem_Right.GUID = objDRs_TypeRelation(0).Item("GUID_TypeItem_Left")
                        objSemItem_Right.Name = objDRs_TypeRelation(0).Item("Name_TypeItem_Left")
                        objSemItem_Right.GUID_Parent = objLocalConfig.SemItem_Type_Type_Item.GUID
                        objSemItem_Right.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID

                        objSemItem_RelationType.GUID = objDRs_TypeRelation(0).Item("GUID_RelationType")
                        objSemItem_RelationType.Name = objDRs_TypeRelation(0).Item("Name_RelationType")
                        objSemItem_RelationType.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_RelationType.GUID

                        GUID_TokenAttribute_Include = objDRs_TypeRelation(0).Item("GUID_TokenAttribute_Include")
                        boolInclude = objDRs_TypeRelation(0).Item("Include")

                        objSemItem_TypeRelation.GUID = objDRs_TypeRelation(0).Item("GUID_TypeRelation")
                        objSemItem_TypeRelation.Name = objDRs_TypeRelation(0).Item("Name_TypeRelation")
                        objSemItem_TypeRelation.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_RelationType.GUID

                        GUID_TokenAttribute_Size = objDRs_TypeRelation(0).Item("GUID_TokenAttribute_Size")

                        objTransaction_TypeItemRelation = New clsTransaction_TypeItemRelation(objLocalConfig, _
                                                                                            objSemItem_Left, objSemItem_Right, _
                                                                                            objSemItem_RelationType, _
                                                                                            boolInclude)
                        objTransaction_TypeItemRelation.GUID_TokenAttribute_Coords = GUID_TokenAttribute_Coords
                        objTransaction_TypeItemRelation.GUID_TokenAttribute_Include = GUID_TokenAttribute_Include
                        objTransaction_TypeItemRelation.GUID_TokenAttribute_Size = GUID_TokenAttribute_Size
                        objTransaction_TypeItemRelation.SemItem_TypeRelation = objSemItem_TypeRelation
                        objTransaction_TypeItemRelation.SemItem_RelationType = objSemItem_RelationType

                        objSemItem_Result = objTransaction_TypeItemRelation.del_006_Coords()
                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                            objSemItem_Result = objTransaction_TypeItemRelation.del_005_Size()
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objSemItem_Result = objTransaction_TypeItemRelation.del_004_Include()
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItemRelation.del_003_TypeRelation_to_RelationType()
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(True)
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItemRelation.del_002_TypeRelation_To_TypeItemLeftRight(False)
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                objSemItem_Result = objTransaction_TypeItemRelation.del_001_TypeItem_Relations()
                                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                                                    MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                                End If
                                            Else
                                                MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                            End If
                                        Else
                                            MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                        End If
                                    Else
                                        MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                    End If
                                Else
                                    MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                                End If
                            Else
                                MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                            End If
                        Else
                            MsgBox("Die Beziehung konnte nicht korrekt gelöscht werden!", MsgBoxStyle.Exclamation)
                        End If
                    Next

                End If
            End If
            objSemItem_Result = objTransaction_TypeItem.del_009_belongingAttributes
            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                objSemItem_Result = objTransaction_TypeItem.del_010_belongingToken
                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                    objSemItem_Result = objTransaction_TypeItem.del_008_TypeItem_To_Type
                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                        objSemItem_Result = objTransaction_TypeItem.del_007_Report_To_TypeItem
                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then

                            objSemItem_Result = objTransaction_TypeItem.del_006_Size
                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                objSemItem_Result = objTransaction_TypeItem.del_005_Coords
                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                    objSemItem_Result = objTransaction_TypeItem.del_004_showAllToken
                                    If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                        objSemItem_Result = objTransaction_TypeItem.del_003_showName
                                        If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                            objSemItem_Result = objTransaction_TypeItem.del_002_showGUID
                                            If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Success.GUID Then
                                                objSemItem_Result = objTransaction_TypeItem.del_001_TypeItem
                                                If objSemItem_Result.GUID = objLocalConfig.Globals.LogState_Error.GUID Then
                                                    MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                                                End If
                                            Else
                                                MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                                            End If
                                        Else
                                            MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                                        End If
                                    Else
                                        MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                                    End If
                                Else
                                    MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                                End If
                            Else
                                MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                            End If
                        Else
                            MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                        End If

                    Else
                        MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                    End If
                Else
                    MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
                End If
            Else
                MsgBox("Das Type-Item kann nicht gelöscht werden!", MsgBoxStyle.Exclamation)
            End If



        Else
            MsgBox("Das Type-Item existiert nicht mehr!", MsgBoxStyle.Exclamation)

        End If
        get_Data()
        get_Relations()
        draw_Items(PictureBox_Report.CreateGraphics, True)
    End Sub
    Private Sub PictureBox_Report_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PictureBox_Report.Paint
        draw_Items(e.Graphics, False)
    End Sub

    Private Sub ToolStripButton_Add_Type_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_Add_Type.Click
        Dim boolInclude As Boolean
        Dim objSemItem_Result As clsSemItem
        Dim objSemItem_RelationType As clsSemItem = Nothing
        Dim objSemItem_TypeItem_Left As clsSemItem
        Dim objDRs_RelationType() As DataRow
        Dim objDR_RelationType As DataRow
        Dim boolAdd As Boolean
        Dim boolRelate As Boolean

        boolAdd = True
        boolRelate = True
        If objTypeItem_Selected Is Nothing Then
            boolRelate = False
            If Not objTypeItems Is Nothing Then
                If objTypeItems.Count > 0 Then
                    If MsgBox("Wollen Sie wirklich eine Type ohne Beziehung zu den enthaltenen einfügen?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                        boolAdd = False
                    End If
                End If
            Else
                If MsgBox("Wollen Sie wirklich eine Type ohne Beziehung zu den enthaltenen einfügen?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then
                    boolAdd = False
                End If
            End If
        End If

        If boolAdd = True Then
            If boolRelate = True Then
                objFrmTypeSelect = New frmTypeSelect(objLocalConfig, objTypeItem_Selected.TypeItem_Item.SemItem_Type_of_TypeItem)
            Else
                objFrmTypeSelect = New frmTypeSelect(objLocalConfig)
            End If

            objFrmTypeSelect.ShowDialog(Me)
            If objFrmTypeSelect.DialogResult = Windows.Forms.DialogResult.OK Then
                objSemItem_Type_ToRelate = objFrmTypeSelect.SemItem_Type

                objSemItem_RelationType = Nothing
                If Not objTypeItem_Selected Is Nothing Then
                    objSemItem_TypeItem_Left = New clsSemItem
                    objSemItem_TypeItem_Left.GUID = objTypeItem_Selected.TypeItem_Item.GUID
                    objSemItem_TypeItem_Left.Name = objTypeItem_Selected.TypeItem_Item.Name
                    objSemItem_TypeItem_Left.GUID_Parent = objLocalConfig.SemItem_Type_Type_Item.GUID
                    objSemItem_TypeItem_Left.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_Token.GUID
                Else
                    objSemItem_TypeItem_Left = Nothing
                End If


                If boolRelate = True Then
                    typefuncA_Types_Rel.Fill_By_GUID_Type_Left(typefuncT_Types_Rel, objTypeItem_Selected.TypeItem_Item.SemItem_Type_of_TypeItem.GUID)
                    objDRs_RelationType = typefuncT_Types_Rel.Select("GUID_Type_Right='" & objSemItem_Type_ToRelate.GUID.ToString & "'")
                    objSemItem_RelationType = New clsSemItem
                    If objDRs_RelationType.Count > 0 Then
                        objFrmRelationTypeSelection = New frmSelect_Items("Relation-Type")
                        For Each objDR_RelationType In objDRs_RelationType
                            objSemItem_RelationType.GUID = objDR_RelationType.Item("GUID_RelationType")
                            objSemItem_RelationType.Name = objDR_RelationType.Item("Name_RelationType")
                            objSemItem_RelationType.GUID_Type = objLocalConfig.Globals.ObjectReferenceType_RelationType.GUID
                            objFrmRelationTypeSelection.add_Item(objSemItem_RelationType)
                        Next
                        objFrmRelationTypeSelection.ShowDialog(Me)
                    End If


                End If




                boolInclude = objFrmTypeSelect.Include

                add_Type(objSemItem_TypeItem_Left, objSemItem_RelationType, boolRelate)

            End If
        End If
    End Sub

    Private Sub set_DBConnection()
        procA_TypeRelations_Of_Report.Connection = objLocalConfig.Connection_Plugin
        procA_TypeItems_Of_Reports.Connection = objLocalConfig.Connection_Plugin
        semtblA_Token_With_Check.Connection = objLocalConfig.Connection_Plugin
        procA_belongingToken_Of_TypeItem.Connection = objLocalConfig.Connection_Plugin

        typefuncA_Types_Rel.Connection = objLocalConfig.Connection_DB

        semprocA_DBWork_Save_TokenAttribute_VARCHAR255.Connection = objLocalConfig.Connection_DB
    End Sub

    Private Sub ToolStripButton_RemoveType_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton_RemoveType.Click
        If Not objTypeItem_Selected Is Nothing Then
            remove_TypeItem()
        ElseIf Not objSemItem_TypeRelation_Selected Is Nothing Then
            remove_TypeRelation()
        End If
    End Sub
End Class
